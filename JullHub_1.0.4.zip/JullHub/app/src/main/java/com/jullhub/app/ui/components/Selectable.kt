package com.jullhub.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.jullhub.app.ui.theme.JullMotion

/**
 * Estado de selección de JullHub: al recibir foco (mando, teclado) o pulsación (táctil) el elemento
 * se amplía, gana elevación y un borde luminoso. Usa `clickable`, que ya es enfocable, por lo que la
 * navegación futura por mando/teclado funciona sin rehacer la UI.
 * La animación se lee dentro de `graphicsLayer`: no provoca recomposiciones.
 */
@Composable
fun Modifier.consoleSelectable(
    shape: Shape,
    onClickLabel: String? = null,
    onClick: () -> Unit
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (focused || pressed) JullMotion.FOCUS_SCALE else 1f,
        tween(JullMotion.FAST), label = "selectScale"
    )
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(JullMotion.FAST), label = "selectGlow")
    val primary = MaterialTheme.colorScheme.primary
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
            shadowElevation = glow * 24f
            this.shape = shape
            clip = false
        }
        .drawBehind {
            // Brillo exterior + borde nítido, dibujados con Canvas y leídos solo en la fase de dibujo.
            if (glow > 0.01f) {
                val outline = shape.createOutline(size, layoutDirection, this)
                strokeOutline(outline, primary.copy(alpha = 0.28f * glow), 12.dp.toPx())
                strokeOutline(outline, primary.copy(alpha = glow), 2.dp.toPx())
            }
        }
        .clip(shape)
        .clickable(
            interactionSource = interaction,
            indication = LocalIndication.current,
            onClickLabel = onClickLabel,
            onClick = onClick
        )
}

/** Traza el contorno de cualquier [Outline] usando solo primitivas de DrawScope. */
private fun DrawScope.strokeOutline(outline: Outline, color: Color, width: Float) {
    val stroke = Stroke(width = width)
    when (outline) {
        is Outline.Generic -> drawPath(outline.path, color, style = stroke)
        is Outline.Rectangle -> drawRect(
            color, outline.rect.topLeft,
            androidx.compose.ui.geometry.Size(outline.rect.width, outline.rect.height), style = stroke
        )
        is Outline.Rounded -> drawRoundRect(
            color, androidx.compose.ui.geometry.Offset(outline.roundRect.left, outline.roundRect.top),
            androidx.compose.ui.geometry.Size(outline.roundRect.width, outline.roundRect.height),
            CornerRadius(outline.roundRect.topLeftCornerRadius.x, outline.roundRect.topLeftCornerRadius.y),
            style = stroke
        )
    }
}
