package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/**
 * Contrato que cada emulador implementa. Toda la lógica específica de un emulador
 * (paquete, Activity, extras, formato de URI, Title ID) vive en su adapter; la UI y
 * la biblioteca solo conocen esta interfaz.
 */
interface EmulatorAdapter {
    val id: String
    val displayName: String
    val packageNames: List<String>
    val supportedPlatforms: Set<Platform>

    /** `true` si JullHub tiene un método de lanzamiento verificado para este emulador. */
    val hasLaunchMethod: Boolean

    /** Primer paquete de [packageNames] instalado en el dispositivo, o `null`. */
    fun installedPackage(context: Context): String?

    fun isInstalled(context: Context): Boolean = installedPackage(context) != null

    /** La plataforma del juego es una de las del emulador (no implica que sepa lanzarlo). */
    fun supports(game: Game): Boolean = game.platform in supportedPlatforms

    /** Sin efectos secundarios: ¿puede este adapter abrir este juego por lanzamiento externo? */
    fun canLaunch(game: Game): Boolean

    /** Prepara el lanzamiento sin ejecutarlo. Nunca lanza excepciones en el flujo normal. */
    fun buildLaunchRequest(context: Context, game: Game): LaunchBuild
}

/** Detecta qué paquetes hay instalados. Separado para que el resto sea independiente de Android. */
fun interface PackageResolver {
    fun firstInstalled(context: Context, packages: List<String>): String?
}

/**
 * Qué parte de la lógica de un emulador es pura: qué juegos acepta y qué [LaunchRequest] construye.
 */
interface LaunchSpec {
    /** `null` si el juego es lanzable; si no, el motivo (no soportado / juego inválido). */
    fun check(game: Game): LaunchResult?

    /** Solo se llama si [check] devolvió `null`. */
    fun request(game: Game, installedPackage: String): LaunchRequest
}

/** Adapter genérico: declara datos y delega el método de lanzamiento en un [LaunchSpec] (o ninguno). */
class SpecEmulatorAdapter(
    override val id: String,
    override val displayName: String,
    override val packageNames: List<String>,
    override val supportedPlatforms: Set<Platform>,
    private val spec: LaunchSpec?,
    private val packages: PackageResolver
) : EmulatorAdapter {

    override val hasLaunchMethod: Boolean get() = spec != null

    override fun installedPackage(context: Context): String? = packages.firstInstalled(context, packageNames)

    override fun canLaunch(game: Game): Boolean =
        supports(game) && spec != null && spec.check(game) == null

    override fun buildLaunchRequest(context: Context, game: Game): LaunchBuild {
        val pkg = installedPackage(context)
            ?: return LaunchBuild.Rejected(LaunchResult.EmulatorNotInstalled)
        if (!supports(game)) {
            return LaunchBuild.Rejected(
                LaunchResult.Unsupported("$displayName no es compatible con ${game.platform.displayName}.")
            )
        }
        if (spec == null) {
            return LaunchBuild.Rejected(
                LaunchResult.Unsupported("JullHub todavía no puede abrir juegos en $displayName de forma automática.")
            )
        }
        spec.check(game)?.let { return LaunchBuild.Rejected(it) }
        return LaunchBuild.Ready(spec.request(game, pkg))
    }
}
