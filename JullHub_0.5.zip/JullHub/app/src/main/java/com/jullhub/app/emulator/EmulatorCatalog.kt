package com.jullhub.app.emulator

import com.jullhub.app.core.model.Platform

/**
 * Emuladores conocidos. Añadir uno = nueva entrada aquí + sus paquetes en `<queries>` de
 * AndroidManifest.xml (sin eso Android 11+ oculta el paquete y se vería "No instalado").
 *
 * `spec = null` significa "detectado pero sin método de lanzamiento verificado": el emulador
 * aparece en la lista, pero JullHub no intenta abrir juegos con él. Para activarlo, escribir su
 * [LaunchSpec] (en LaunchSpecs.kt) citando una fuente y pasarlo aquí.
 */
object EmulatorCatalog {

    fun adapters(packages: PackageResolver): List<EmulatorAdapter> {
        fun emu(
            id: String,
            displayName: String,
            packageNames: List<String>,
            supportedPlatforms: Set<Platform>,
            spec: LaunchSpec? = null
        ): EmulatorAdapter =
            SpecEmulatorAdapter(id, displayName, packageNames, supportedPlatforms, spec, packages)

        return listOf(
            // --- Con lanzamiento verificado ---
            emu(
                id = "ppsspp",
                displayName = "PPSSPP",
                packageNames = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold"),
                supportedPlatforms = setOf(Platform.PSP),
                spec = PpssppSpec()
            ),
            emu(
                id = "duckstation",
                displayName = "DuckStation",
                packageNames = listOf("com.github.stenzek.duckstation"),
                supportedPlatforms = setOf(Platform.PS1),
                spec = DuckStationSpec()
            ),
            emu(
                id = "nethersx2",
                displayName = "NetherSX2 / AetherSX2",
                packageNames = listOf("xyz.aethersx2.android"),
                supportedPlatforms = setOf(Platform.PS2),
                spec = NetherSx2Spec()
            ),
            emu(
                id = "dolphin",
                displayName = "Dolphin",
                packageNames = listOf("org.dolphinemu.dolphinemu"),
                supportedPlatforms = setOf(Platform.GAMECUBE, Platform.WII),
                spec = DolphinSpec()
            ),
            emu(
                id = "vita3k",
                displayName = "Vita3K",
                packageNames = listOf("org.vita3k.emulator"),
                supportedPlatforms = setOf(Platform.PS_VITA),
                spec = Vita3kSpec()
            ),
            emu(
                id = "melonds",
                displayName = "melonDS",
                packageNames = listOf("me.magnum.melonds"),
                supportedPlatforms = setOf(Platform.NDS),
                spec = MelonDsSpec()
            ),

            // --- Solo detección: método de lanzamiento aún sin verificar ---
            emu(
                id = "drastic",
                displayName = "DraStic",
                packageNames = listOf("com.dsemu.drastic"),
                supportedPlatforms = setOf(Platform.NDS)
            ),
            emu(
                id = "azahar",
                displayName = "Azahar",
                packageNames = listOf("org.azahar_emu.azahar"),
                supportedPlatforms = setOf(Platform.N3DS)
            ),
            emu(
                id = "m64plusfz",
                displayName = "M64Plus FZ",
                packageNames = listOf("org.mupen64plusae.v3.fzurita", "org.mupen64plusae.v3.fzurita.pro"),
                supportedPlatforms = setOf(Platform.N64)
            ),
            emu(
                id = "flycast",
                displayName = "Flycast",
                packageNames = listOf("com.flycast.emulator"),
                supportedPlatforms = setOf(Platform.DREAMCAST)
            ),
            emu(
                id = "redream",
                displayName = "Redream",
                packageNames = listOf("io.recompiled.redream"),
                supportedPlatforms = setOf(Platform.DREAMCAST)
            ),
            emu(
                id = "retroarch",
                displayName = "RetroArch",
                packageNames = listOf("com.retroarch", "com.retroarch.aarch64", "com.retroarch.ra32"),
                supportedPlatforms = setOf(
                    Platform.PS1, Platform.PSP, Platform.NDS, Platform.N3DS, Platform.N64,
                    Platform.GB_GBC, Platform.GBA, Platform.NES, Platform.SNES, Platform.MEGA_DRIVE,
                    Platform.DREAMCAST, Platform.GAMECUBE, Platform.WII, Platform.ARCADE
                )
            )
        )
    }
}
