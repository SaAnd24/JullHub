# JullHub

Launcher y gestor de juegos para Android (Kotlin, Jetpack Compose, Material 3). **No es un emulador.**
Estado: v0.5 (lanzamiento de juegos en emuladores). Sin metadata, portadas ni estadísticas.

## Abrir y compilar
1. Android Studio (Ladybug 2024.2 o superior) → *Open* → carpeta `JullHub`.
2. Esperar el *Gradle sync* (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, JDK 17).
3. Ejecutar la configuración `app`. minSdk 26, targetSdk 35.

## Arquitectura (`app/src/main/java/com/jullhub/app`)
- `core/model` — `Game`, `Platform`, `GameFolder`.
- `emulator` — `EmulatorAdapter`, `BaseEmulatorAdapter`, `EmulatorRegistry`, `GameLauncher`.
  Añadir un emulador = crear su adapter y registrarlo en `di/AppContainer.kt`.
- `data` — DataStore, `FolderRepository` (SAF + permisos persistentes), `SettingsRepository`, `GameRepository` (Room).
- `data/db` — Room: `JullDatabase`, `GameDao`, `GameEntity` (+ conversiones `Game ↔ GameEntity`).
- `data/scanner` — `GameScanner` (recorrido SAF), `PlatformDetector` (carpetas -> plataforma), `GameFileFilter` (extensiones), `ScanManager` (orquesta el escaneo).
- `di` — `AppContainer` (inyección manual).
- `ui` — tema, componentes, navegación y pantallas (Inicio, Biblioteca, Emuladores, Configuración).

## Escáner (v0.2)
Flujo implementado: Carpetas SAF → `GameScanner` → `Game` → Biblioteca.
- Ampliar formatos: `GameFileFilter.DEFAULT_EXTENSIONS`. Ampliar nombres de carpeta: `PlatformDetector.DEFAULT_ALIASES`.
- La plataforma se decide por el contexto de carpetas; si no hay confianza suficiente, `Platform.UNKNOWN`.
- Los juegos se guardan en Room (`jullhub.db`): no hace falta re-escanear al abrir la app. El escaneo solo detecta cambios (altas, bajas, cambios).
- Identidad: el `id` del juego es la URI SAF del documento, así que re-escanear nunca duplica.
- Carpetas inaccesibles o leídas en parte: sus juegos no se borran de Room.
- Favoritos: corazón en la tarjeta de la Biblioteca, persistido en Room.

## Biblioteca por consolas y emuladores (v0.4)
- La Biblioteca navega por consolas con juegos (swipe horizontal o vertical, ajustable en Configuración → Biblioteca → Navegación, guardado en DataStore). Todos/Favoritos/Recientes son accesos secundarios.
- `PlatformEmblem` (ui/components) es la representación visual de cada consola; sustituirla por assets propios solo requiere cambiar ese componente.
- `emulator/EmulatorCatalog.kt` lista los emuladores (id, nombre, paquetes, plataformas). Añadir uno = nueva entrada + sus paquetes en `<queries>` del manifest (necesario en Android 11+).
- `EmulatorRegistry.installedCompatibleWith(context, game)`: juego → plataforma → emuladores compatibles instalados. En 0.4 solo se detecta; no se lanza nada.

## Lanzamiento de juegos (v0.5)
Flujo: `Game → Platform → emuladores compatibles instalados → los que pueden lanzarlo → (elección) → LaunchRequest → Intent → emulador`.
- `emulator/LaunchRequest.kt`: tipos puros (`LaunchRequest`, `LaunchResult`, `LaunchBuild`). `EmulatorAdapter.canLaunch(game)` y `buildLaunchRequest(context, game)`.
- `emulator/LaunchSpecs.kt`: un método de lanzamiento por emulador, **cada uno con su fuente citada**. Sin método verificado = sin spec = no se intenta lanzar.
- `emulator/GameLauncher.kt`: `plan(...)` decide emulador (automático si hay uno, `RequiresSelection` si hay varios) y comprueba que la URI SAF siga disponible.
- `emulator/AndroidLaunchSupport.kt`: lo único que toca Android (detección de paquetes, comprobación SAF, `IntentLaunchExecutor`).
- UI: `ui/play/PlayViewModel` + `rememberPlayAction`; la UI nunca conoce un emulador. Tras un lanzamiento aceptado se actualizan `lastPlayedAt` y `playCount` en Room.
- Los juegos se pasan siempre como URI `content://` con concesión de lectura (flag + `ClipData`). No hay rutas absolutas ni copias de ROMs.

| Emulador | Método | Fuente |
|---|---|---|
| PPSSPP | `ACTION_VIEW` + URI en `data`, `org.ppsspp.ppsspp.PpssppActivity` | ppsspp.org (docs oficiales) |
| DuckStation | extra `bootPath`=URI, `...duckstation.EmulationActivity` | Daijishō, NeoStation, LaunchBox |
| NetherSX2/AetherSX2 | extra `bootPath`=URI, `xyz.aethersx2.android.EmulationActivity` | LaunchBox, ES-DE/EmuBridge |
| Dolphin | `ACTION_MAIN` + extra `AutoStartFile`=URI, `.ui.main.MainActivity` | Daijishō (con VIEW falla: Pegasus #1096) |
| melonDS | extra `uri`, `me.magnum.melonds.ui.emulator.EmulatorActivity` | README del proyecto (la ROM debe estar escaneada en melonDS) |
| Vita3K | extra array `AppStartParameters`=[`-r`, TitleID], `org.vita3k.emulator.Emulator` | Vita3K-Android #505, ES-DE |
Sin método verificado (solo detección): DraStic, Azahar, M64Plus FZ, Flycast, Redream, RetroArch.

Flujo futuro: Carpetas SAF → Escáner → Juegos → Plataforma → Emulador → EmulatorAdapter → Intent → Juego iniciado.

## Notas
- Sin `MANAGE_EXTERNAL_STORAGE`; solo `ACTION_OPEN_DOCUMENT_TREE` con permiso de lectura persistente.
- `gradlew` no se incluye; Android Studio descarga Gradle según `gradle/wrapper/gradle-wrapper.properties`.
