package com.jullhub.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games")
    fun observeAll(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE folderUri = :folderUri")
    suspend fun getByFolder(folderUri: String): List<GameEntity>

    /** Inserta o reemplaza por id. Quien llama aporta la fila completa (ya fusionada). */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(games: List<GameEntity>)

    @Query("DELETE FROM games WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("DELETE FROM games WHERE folderUri = :folderUri")
    suspend fun deleteByFolder(folderUri: String)

    /** Elimina juegos cuya carpeta ya no está configurada. Solo toca filas de Room. */
    @Query("DELETE FROM games WHERE folderUri NOT IN (:folderUris)")
    suspend fun deleteOutsideFolders(folderUris: List<String>)

    @Query("UPDATE games SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: String, favorite: Boolean)
}
