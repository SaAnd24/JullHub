package com.jullhub.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

/** Base de datos de la biblioteca. Al cambiar el esquema, subir `version` y añadir una migración. */
@Database(entities = [GameEntity::class], version = 1, exportSchema = false)
abstract class JullDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
}
