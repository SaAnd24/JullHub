package com.jullhub.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.data.settings.LibraryNavigation
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.data.settings.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val repository: SettingsRepository) : ViewModel() {
    val themeMode: StateFlow<ThemeMode> = repository.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.DARK)

    val libraryNavigation: StateFlow<LibraryNavigation> = repository.libraryNavigation
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibraryNavigation.HORIZONTAL)

    fun setLibraryNavigation(navigation: LibraryNavigation) {
        viewModelScope.launch { repository.setLibraryNavigation(navigation) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }
}
