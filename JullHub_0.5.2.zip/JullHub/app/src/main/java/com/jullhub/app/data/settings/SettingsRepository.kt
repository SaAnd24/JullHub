package com.jullhub.app.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/** Dirección del gesto para cambiar de consola en la Biblioteca. */
enum class LibraryNavigation { HORIZONTAL, VERTICAL }

interface SettingsRepository {
    val themeMode: Flow<ThemeMode>
    suspend fun setThemeMode(mode: ThemeMode)

    val libraryNavigation: Flow<LibraryNavigation>
    suspend fun setLibraryNavigation(navigation: LibraryNavigation)
}

class DataStoreSettingsRepository(
    private val dataStore: DataStore<Preferences>
) : SettingsRepository {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val navigationKey = stringPreferencesKey("library_navigation")

    override val themeMode: Flow<ThemeMode> = dataStore.data.map { prefs ->
        prefs[themeKey]?.let { saved -> ThemeMode.entries.firstOrNull { it.name == saved } }
            ?: ThemeMode.DARK
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[themeKey] = mode.name }
    }

    override val libraryNavigation: Flow<LibraryNavigation> = dataStore.data.map { prefs ->
        prefs[navigationKey]?.let { saved -> LibraryNavigation.entries.firstOrNull { it.name == saved } }
            ?: LibraryNavigation.HORIZONTAL
    }

    override suspend fun setLibraryNavigation(navigation: LibraryNavigation) {
        dataStore.edit { it[navigationKey] = navigation.name }
    }
}
