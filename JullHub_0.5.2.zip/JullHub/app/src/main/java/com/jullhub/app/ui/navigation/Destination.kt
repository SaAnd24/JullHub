package com.jullhub.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector

enum class Destination(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Inicio", Icons.Rounded.Home),
    Library("library", "Biblioteca", Icons.Rounded.VideoLibrary),
    Emulators("emulators", "Emuladores", Icons.Rounded.SportsEsports),
    Settings("settings", "Configuración", Icons.Rounded.Settings)
}
