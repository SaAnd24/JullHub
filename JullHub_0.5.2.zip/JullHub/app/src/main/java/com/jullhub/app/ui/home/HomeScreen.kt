package com.jullhub.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.Game
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.MutedText
import com.jullhub.app.ui.components.SectionHeader
import com.jullhub.app.ui.play.PlayViewModel
import com.jullhub.app.ui.play.rememberPlayAction
import androidx.compose.material3.SnackbarHostState

@Composable
fun HomeScreen(
    factory: ViewModelProvider.Factory,
    onOpenLibrary: () -> Unit,
    snackbarHostState: SnackbarHostState,
    vm: HomeViewModel = viewModel(factory = factory),
    playVm: PlayViewModel = viewModel(factory = factory)
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val play = rememberPlayAction(playVm, snackbarHostState)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Text(
                text = "JullHub",
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
        if (!state.isLoading) {
            if (!state.hasGames) {
                item {
                    EmptyState(
                        icon = Icons.Rounded.VideoLibrary,
                        title = "Tu colección empieza aquí",
                        body = "Añade la carpeta donde guardas tus juegos. JullHub no los copia ni los mueve.",
                        actionLabel = "Añadir carpeta de juegos",
                        onAction = onOpenLibrary
                    )
                }
            }
            gameSection("Continuar jugando", listOfNotNull(state.continuePlaying), play)
            gameSection("Recientes", state.recent, play)
            gameSection("Favoritos", state.favorites, play)
            gameSection("Añadidos recientemente", state.recentlyAdded, play)
            item(key = "platforms") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader("Plataformas")
                    if (state.platforms.isEmpty()) {
                        MutedText("Aparecerán cuando haya juegos.", Modifier.padding(horizontal = 16.dp))
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(state.platforms, key = { it.platform.name }) { entry ->
                                AssistChip(
                                    onClick = onOpenLibrary,
                                    label = { Text("${entry.platform.displayName} (${entry.count})") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun LazyListScope.gameSection(title: String, games: List<Game>, onPlay: (Game) -> Unit) {
    item(key = title) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeader(title)
            if (games.isEmpty()) {
                MutedText("Aún no hay juegos aquí.", Modifier.padding(horizontal = 16.dp))
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(games, key = { it.id }) { game ->
                        GameCard(game, modifier = Modifier.width(140.dp), onClick = { onPlay(game) }, onPlayClick = { onPlay(game) })
                    }
                }
            }
        }
    }
}
