package com.jullhub.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jullhub.app.data.settings.ThemeMode
import com.jullhub.app.ui.emulators.EmulatorsScreen
import com.jullhub.app.ui.home.HomeScreen
import com.jullhub.app.ui.library.LibraryScreen
import com.jullhub.app.ui.navigation.Destination
import com.jullhub.app.ui.settings.SettingsScreen
import com.jullhub.app.ui.settings.SettingsViewModel
import com.jullhub.app.ui.theme.JullHubTheme

@Composable
fun JullHubApp() {
    val factory = rememberViewModelFactory()
    val settingsVm: SettingsViewModel = viewModel(factory = factory)
    val themeMode by settingsVm.themeMode.collectAsStateWithLifecycle()
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    JullHubTheme(darkTheme = dark) {
        val navController = rememberNavController()
        val snackbarHostState = remember { SnackbarHostState() }
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = backStackEntry?.destination

        fun navigateTo(destination: Destination) {
            navController.navigate(destination.route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar {
                    Destination.entries.forEach { destination ->
                        NavigationBarItem(
                            selected = currentDestination?.hierarchy
                                ?.any { it.route == destination.route } == true,
                            onClick = { navigateTo(destination) },
                            icon = { Icon(destination.icon, contentDescription = null) },
                            label = { Text(destination.label) }
                        )
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = Destination.Home.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(Destination.Home.route) {
                    HomeScreen(factory, onOpenLibrary = { navigateTo(Destination.Library) }, snackbarHostState = snackbarHostState)
                }
                composable(Destination.Library.route) {
                    LibraryScreen(factory, snackbarHostState)
                }
                composable(Destination.Emulators.route) {
                    EmulatorsScreen(factory)
                }
                composable(Destination.Settings.route) {
                    SettingsScreen(factory, snackbarHostState)
                }
            }
        }
    }
}
