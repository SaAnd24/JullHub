package com.jullhub.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.games.GameRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class PlatformCount(val platform: Platform, val count: Int)

data class HomeUiState(
    val isLoading: Boolean = true,
    val hasGames: Boolean = false,
    val continuePlaying: Game? = null,
    val recent: List<Game> = emptyList(),
    val favorites: List<Game> = emptyList(),
    val recentlyAdded: List<Game> = emptyList(),
    val platforms: List<PlatformCount> = emptyList()
)

class HomeViewModel(games: GameRepository) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = games.observeGames()
        .map { list ->
            val played = list.filter { it.lastPlayedAt != null }.sortedByDescending { it.lastPlayedAt }
            HomeUiState(
                isLoading = false,
                hasGames = list.isNotEmpty(),
                continuePlaying = played.firstOrNull(),
                recent = played.take(10),
                favorites = list.filter { it.isFavorite }.take(10),
                recentlyAdded = list.sortedByDescending { it.addedAt }.take(10),
                platforms = list.groupingBy { it.platform }.eachCount()
                    .map { PlatformCount(it.key, it.value) }
                    .sortedBy { it.platform.displayName }
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())
}
