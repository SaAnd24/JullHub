package com.jullhub.app.ui.library

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.GameFolder
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.folders.AddFolderResult
import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.data.settings.LibraryNavigation
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.emulator.EmulatorRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Vista principal de la Biblioteca. Las consolas son la navegación; el resto son accesos secundarios. */
enum class LibraryMode(val label: String) {
    CONSOLES("Consolas"),
    ALL("Todos"),
    FAVORITES("Favoritos"),
    RECENT("Recientes")
}

/** Una consola que tiene juegos: una "sección" de la Biblioteca. */
data class PlatformSection(
    val platform: Platform,
    /** Juegos de la consola en la biblioteca. */
    val total: Int,
    /** Juegos que cumplen la búsqueda actual (igual a [total] sin búsqueda). */
    val matching: Int,
    /** Nombres de los emuladores compatibles que están instalados. */
    val installedEmulators: List<String>
)

data class LibraryUiState(
    /** `true` hasta que Room emite por primera vez; evita mostrar el estado vacío por error. */
    val isLoading: Boolean = true,
    val mode: LibraryMode = LibraryMode.CONSOLES,
    val navigation: LibraryNavigation = LibraryNavigation.HORIZONTAL,
    /** Solo consolas con juegos, en orden fijo. */
    val sections: List<PlatformSection> = emptyList(),
    val selectedPlatform: Platform? = null,
    /** Juegos a mostrar según el modo (y la consola, en [LibraryMode.CONSOLES]) y la búsqueda. */
    val games: List<Game> = emptyList(),
    val totalCount: Int = 0
)

private data class Selection(val mode: LibraryMode = LibraryMode.CONSOLES, val platform: Platform? = null)

/** Orden fijo de las consolas en la Biblioteca; lo no listado va al final. */
private val PLATFORM_ORDER: List<Platform> = (listOf(
    Platform.PSP, Platform.PS2, Platform.PS1, Platform.PS_VITA,
    Platform.NDS, Platform.N3DS, Platform.GAMECUBE, Platform.WII, Platform.N64,
    Platform.GBA, Platform.GB_GBC, Platform.SNES, Platform.NES,
    Platform.DREAMCAST, Platform.MEGA_DRIVE, Platform.ARCADE,
    Platform.OTHER, Platform.UNKNOWN
) + Platform.entries).distinct()

class LibraryViewModel(
    private val games: GameRepository,
    settings: SettingsRepository,
    private val emulators: EmulatorRegistry,
    private val context: Context
) : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private val selection = MutableStateFlow(Selection())
    private val installedEmulatorIds = MutableStateFlow<Set<String>>(emptySet())

    val uiState: StateFlow<LibraryUiState> = combine(
        games.observeGames(), _query, selection, settings.libraryNavigation, installedEmulatorIds
    ) { all, q, sel, navigation, installed ->
        val term = q.trim()
        fun matches(game: Game) = game.title.contains(term, ignoreCase = true)

        val byPlatform = all.groupBy { it.platform }
        val sections = PLATFORM_ORDER.filter { it in byPlatform }.map { platform ->
            val list = byPlatform.getValue(platform)
            PlatformSection(
                platform = platform,
                total = list.size,
                matching = list.count(::matches),
                installedEmulators = emulators.forPlatform(platform)
                    .filter { it.id in installed }
                    .map { it.displayName }
            )
        }
        // Si la consola elegida ya no tiene juegos (p. ej. tras re-escanear), se usa la primera.
        val selected = sel.platform?.takeIf { p -> sections.any { it.platform == p } }
            ?: sections.firstOrNull()?.platform

        val shown = when (sel.mode) {
            LibraryMode.CONSOLES -> all.filter { it.platform == selected && matches(it) }
            LibraryMode.ALL -> all.filter(::matches)
            LibraryMode.FAVORITES -> all.filter { it.isFavorite && matches(it) }
            LibraryMode.RECENT -> all.filter { it.lastPlayedAt != null && matches(it) }
                .sortedByDescending { it.lastPlayedAt }
        }.let { list ->
            if (sel.mode == LibraryMode.RECENT) list else list.sortedBy { it.title.lowercase() }
        }

        LibraryUiState(
            isLoading = false,
            mode = sel.mode,
            navigation = navigation,
            sections = sections,
            selectedPlatform = selected,
            games = shown,
            totalCount = all.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    init { refreshEmulators() }

    fun onQueryChange(value: String) { _query.value = value }
    fun onModeSelected(mode: LibraryMode) { selection.value = selection.value.copy(mode = mode) }
    fun onPlatformSelected(platform: Platform) { selection.value = selection.value.copy(platform = platform) }

    fun onFavoriteToggle(game: Game) {
        viewModelScope.launch { games.setFavorite(game.id, !game.isFavorite) }
    }

    /** Vuelve a comprobar qué emuladores hay instalados (al volver a la pantalla). */
    fun refreshEmulators() {
        viewModelScope.launch(Dispatchers.Default) {
            installedEmulatorIds.value = emulators.all()
                .filter { it.isInstalled(context) }
                .map { it.id }
                .toSet()
        }
    }
}

/** Gestión de carpetas SAF; compartido por Biblioteca y Configuración. */
class FoldersViewModel(
    private val repository: FolderRepository,
    private val games: GameRepository
) : ViewModel() {
    val folders: StateFlow<List<GameFolder>> = repository.folders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    fun addFolder(uri: Uri) {
        viewModelScope.launch {
            val text = when (repository.addFolder(uri)) {
                AddFolderResult.Added -> "Carpeta añadida"
                AddFolderResult.AlreadyExists -> "Esa carpeta ya está configurada"
                AddFolderResult.PermissionFailed -> "No se pudo guardar el permiso de acceso a la carpeta"
            }
            _messages.emit(text)
        }
    }

    fun removeFolder(uri: String) {
        viewModelScope.launch {
            // Solo se elimina la referencia: ningún archivo del usuario se toca.
            repository.removeFolder(uri)
            games.removeByFolder(uri)
            _messages.emit("Carpeta eliminada de JullHub. Tus archivos no se han tocado")
        }
    }
}
