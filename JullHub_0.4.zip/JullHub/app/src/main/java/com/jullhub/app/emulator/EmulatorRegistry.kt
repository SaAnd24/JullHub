package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/** Catálogo de adapters. Registrar un emulador nuevo = añadir su adapter a esta lista. */
class EmulatorRegistry(private val adapters: List<EmulatorAdapter> = emptyList()) {
    fun all(): List<EmulatorAdapter> = adapters
    fun byId(id: String): EmulatorAdapter? = adapters.firstOrNull { it.id == id }
    fun forPlatform(platform: Platform): List<EmulatorAdapter> =
        adapters.filter { platform in it.supportedPlatforms }
    fun compatibleWith(game: Game): List<EmulatorAdapter> = adapters.filter { it.supports(game) }

    /** Emuladores de [platform] que están instalados ahora mismo. */
    fun installedForPlatform(context: Context, platform: Platform): List<EmulatorAdapter> =
        forPlatform(platform).filter { it.isInstalled(context) }

    /** Juego -> plataforma -> emuladores compatibles instalados (sin lanzar nada). */
    fun installedCompatibleWith(context: Context, game: Game): List<EmulatorAdapter> =
        compatibleWith(game).filter { it.isInstalled(context) }
}
