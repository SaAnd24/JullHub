package com.jullhub.app.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridItemScope
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.scanner.ScanState
import com.jullhub.app.data.settings.LibraryNavigation
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.MutedText
import com.jullhub.app.ui.components.PlatformEmblem
import com.jullhub.app.ui.components.accentColor

@Composable
fun LibraryScreen(
    factory: ViewModelProvider.Factory,
    snackbarHostState: SnackbarHostState,
    vm: LibraryViewModel = viewModel(factory = factory),
    foldersVm: FoldersViewModel = viewModel(factory = factory),
    scanVm: ScanViewModel = viewModel(factory = factory)
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val folders by foldersVm.folders.collectAsStateWithLifecycle()
    val scanState by scanVm.state.collectAsStateWithLifecycle()
    val scanning = scanState is ScanState.Scanning
    val pickFolder = rememberFolderPicker { foldersVm.addFolder(it) }
    CollectFolderMessages(foldersVm, snackbarHostState)
    // Al volver desde la tienda o los ajustes, se refresca qué emuladores hay instalados.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshEmulators() }

    // El estado del pager vive aquí (no dentro de un item) para conservar la consola al hacer scroll.
    val sectionsState = rememberUpdatedState(state.sections)
    val pagerState = rememberPagerState { sectionsState.value.size }

    // Pager -> ViewModel: al cambiar de consola, los juegos se actualizan al instante.
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { index ->
            sectionsState.value.getOrNull(index)?.let { vm.onPlatformSelected(it.platform) }
        }
    }
    // ViewModel -> pager: si la lista de consolas cambia (re-escaneo), se mantiene la seleccionada.
    val selectedIndex = state.sections.indexOfFirst { it.platform == state.selectedPlatform }
    LaunchedEffect(selectedIndex, state.sections.size) {
        if (selectedIndex >= 0 && pagerState.currentPage != selectedIndex) {
            pagerState.scrollToPage(selectedIndex)
        }
    }

    val hasGames = state.totalCount > 0
    val showActions = hasGames || folders.isNotEmpty()

    LazyVerticalGrid(
        columns = GridCells.Adaptive(130.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        fullSpanItem { Text("Biblioteca", style = MaterialTheme.typography.headlineLarge) }

        if (hasGames) {
            fullSpanItem {
                OutlinedTextField(
                    value = query,
                    onValueChange = vm::onQueryChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Buscar juegos") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
                )
            }
        }

        if (showActions) {
            fullSpanItem {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = pickFolder, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(Modifier.size(6.dp))
                            Text("Añadir carpeta", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Button(
                            onClick = scanVm::scan,
                            enabled = folders.isNotEmpty() && !scanning,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (scanning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            } else {
                                Icon(Icons.Rounded.Refresh, contentDescription = null)
                            }
                            Spacer(Modifier.size(6.dp))
                            Text(
                                if (scanning) "Escaneando..." else "Escanear",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    if (scanning) {
                        Spacer(Modifier.height(8.dp))
                        MutedText("Escaneando biblioteca...")
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    } else {
                        scanState.statusText()?.let { MutedText(it, modifier = Modifier.padding(top = 8.dp)) }
                    }
                }
            }
        }

        when {
            state.isLoading -> Unit // Esperando a Room: ni lista ni estado vacío.

            !hasGames -> fullSpanItem {
                EmptyState(
                    icon = Icons.Rounded.VideoLibrary,
                    title = "No tienes juegos todavía",
                    body = when {
                        folders.isEmpty() ->
                            "Añade una carpeta con tus juegos para empezar. JullHub no los copia ni los mueve."
                        scanning -> "Buscando juegos en tus carpetas..."
                        scanState is ScanState.Finished ->
                            "No se encontraron juegos compatibles en tus carpetas. Revisa su contenido y vuelve a escanear."
                        else ->
                            "Tienes ${folders.size} carpeta(s) guardada(s). Pulsa «Escanear» para buscar tus juegos."
                    },
                    actionLabel = if (folders.isEmpty()) "Añadir carpeta" else null,
                    onAction = if (folders.isEmpty()) pickFolder else null
                )
            }

            else -> {
                fullSpanItem { ModeRow(selected = state.mode, onSelected = vm::onModeSelected) }

                if (state.mode == LibraryMode.CONSOLES) {
                    fullSpanItem {
                        ConsolePager(
                            sections = state.sections,
                            pagerState = pagerState,
                            navigation = state.navigation,
                            searching = query.isNotBlank()
                        )
                    }
                }

                if (state.games.isEmpty()) {
                    fullSpanItem { MutedText(emptyListMessage(state.mode, query.isNotBlank())) }
                } else {
                    items(state.games, key = { it.id }) { game ->
                        GameCard(game, onFavoriteClick = { vm.onFavoriteToggle(game) })
                    }
                }
            }
        }
    }
}

private fun LazyGridScope.fullSpanItem(content: @Composable LazyGridItemScope.() -> Unit) {
    item(span = { GridItemSpan(maxLineSpan) }, content = content)
}

private fun emptyListMessage(mode: LibraryMode, searching: Boolean): String = when {
    searching -> "Ningún juego coincide con la búsqueda."
    mode == LibraryMode.FAVORITES -> "Todavía no tienes favoritos. Toca el corazón de un juego para añadirlo."
    mode == LibraryMode.RECENT -> "Aún no has jugado a nada."
    else -> "No hay juegos aquí."
}

/** Accesos secundarios (Consolas / Todos / Favoritos / Recientes), deliberadamente discretos. */
@Composable
private fun ModeRow(selected: LibraryMode, onSelected: (LibraryMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        LibraryMode.entries.forEach { mode ->
            val isSelected = mode == selected
            TextButton(onClick = { onSelected(mode) }) {
                Text(
                    text = mode.label,
                    color = if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

/**
 * Consola seleccionada como elemento principal. Un swipe cambia de consola (horizontal o vertical
 * según Configuración) y la lista de juegos de debajo cambia con ella.
 */
@Composable
private fun ConsolePager(
    sections: List<PlatformSection>,
    pagerState: PagerState,
    navigation: LibraryNavigation,
    searching: Boolean
) {
    val vertical = navigation == LibraryNavigation.VERTICAL
    Box(modifier = Modifier.fillMaxWidth().height(230.dp)) {
        if (vertical) {
            VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize(), pageSpacing = 12.dp) { page ->
                sections.getOrNull(page)?.let { ConsoleHero(it, searching) }
            }
        } else {
            HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize(), pageSpacing = 12.dp) { page ->
                sections.getOrNull(page)?.let { ConsoleHero(it, searching) }
            }
        }
        PagerIndicator(
            count = sections.size,
            current = pagerState.currentPage,
            vertical = vertical,
            modifier = Modifier
                .align(if (vertical) Alignment.CenterEnd else Alignment.BottomCenter)
                .padding(if (vertical) 12.dp else 10.dp)
        )
    }
}

@Composable
private fun ConsoleHero(section: PlatformSection, searching: Boolean) {
    val accent = section.platform.accentColor()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(
                Brush.linearGradient(
                    listOf(accent.copy(alpha = 0.40f), MaterialTheme.colorScheme.surfaceContainerHigh)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            PlatformEmblem(section.platform, size = 84.dp)
            Spacer(Modifier.height(6.dp))
            Text(section.platform.displayName, style = MaterialTheme.typography.titleLarge)
            MutedText(
                if (searching) "${section.matching} de ${gamesLabel(section.total)}" else gamesLabel(section.total)
            )
            emulatorLine(section)?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun gamesLabel(count: Int): String = if (count == 1) "1 juego" else "$count juegos"

private fun emulatorLine(section: PlatformSection): String? = when {
    section.platform == Platform.UNKNOWN || section.platform == Platform.OTHER -> null
    section.installedEmulators.isEmpty() -> "Sin emulador instalado"
    else -> "Emulador: " + section.installedEmulators.joinToString(", ")
}

@Composable
private fun PagerIndicator(count: Int, current: Int, vertical: Boolean, modifier: Modifier) {
    if (count <= 1) return
    if (count > 8) {
        Text(
            text = "${current + 1} / $count",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = modifier
        )
        return
    }
    if (vertical) {
        Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { Dot(it == current) }
        }
    } else {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { Dot(it == current) }
        }
    }
}

@Composable
private fun Dot(active: Boolean) {
    Box(
        modifier = Modifier
            .size(if (active) 8.dp else 6.dp)
            .clip(CircleShape)
            .background(
                if (active) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
            )
    )
}
