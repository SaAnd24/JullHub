package com.jullhub.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.jullhub.app.JullHubApplication
import com.jullhub.app.di.AppContainer
import com.jullhub.app.ui.emulators.EmulatorsViewModel
import com.jullhub.app.ui.home.HomeViewModel
import com.jullhub.app.ui.library.FoldersViewModel
import com.jullhub.app.ui.library.LibraryViewModel
import com.jullhub.app.ui.library.ScanViewModel
import com.jullhub.app.ui.settings.SettingsViewModel

class ViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val vm: ViewModel = when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) ->
                HomeViewModel(container.gameRepository)
            modelClass.isAssignableFrom(LibraryViewModel::class.java) ->
                LibraryViewModel(
                    container.gameRepository,
                    container.settingsRepository,
                    container.emulatorRegistry,
                    container.applicationContext
                )
            modelClass.isAssignableFrom(FoldersViewModel::class.java) ->
                FoldersViewModel(container.folderRepository, container.gameRepository)
            modelClass.isAssignableFrom(ScanViewModel::class.java) ->
                ScanViewModel(container.scanManager)
            modelClass.isAssignableFrom(EmulatorsViewModel::class.java) ->
                EmulatorsViewModel(container.emulatorRegistry, container.applicationContext)
            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(container.settingsRepository)
            else -> throw IllegalArgumentException("ViewModel desconocido: ${modelClass.name}")
        }
        return vm as T
    }
}

@Composable
fun rememberViewModelFactory(): ViewModelProvider.Factory {
    val app = LocalContext.current.applicationContext as JullHubApplication
    return remember(app) { ViewModelFactory(app.container) }
}
