package com.jullhub.app.emulator

import com.jullhub.app.core.model.Platform

/**
 * Emuladores conocidos. Añadir uno = nueva entrada aquí + sus paquetes en `<queries>` de
 * AndroidManifest.xml (sin eso Android 11+ oculta el paquete y se vería "No instalado").
 *
 * Los paquetes son los identificadores públicos de cada aplicación; solo se usan para detectar
 * si está instalada. Un paquete no listado (otra build/fork) simplemente aparece como no instalado.
 */
object EmulatorCatalog {

    fun adapters(): List<EmulatorAdapter> = listOf(
        PackageEmulatorAdapter(
            id = "ppsspp",
            displayName = "PPSSPP",
            packageNames = listOf("org.ppsspp.ppsspp", "org.ppsspp.ppssppgold"),
            supportedPlatforms = setOf(Platform.PSP)
        ),
        PackageEmulatorAdapter(
            id = "duckstation",
            displayName = "DuckStation",
            packageNames = listOf("com.github.stenzek.duckstation"),
            supportedPlatforms = setOf(Platform.PS1)
        ),
        PackageEmulatorAdapter(
            id = "nethersx2",
            displayName = "NetherSX2 / AetherSX2",
            packageNames = listOf("xyz.aethersx2.android"),
            supportedPlatforms = setOf(Platform.PS2)
        ),
        PackageEmulatorAdapter(
            id = "dolphin",
            displayName = "Dolphin",
            packageNames = listOf("org.dolphinemu.dolphinemu"),
            supportedPlatforms = setOf(Platform.GAMECUBE, Platform.WII)
        ),
        PackageEmulatorAdapter(
            id = "vita3k",
            displayName = "Vita3K",
            packageNames = listOf("org.vita3k.emulator"),
            supportedPlatforms = setOf(Platform.PS_VITA)
        ),
        PackageEmulatorAdapter(
            id = "melonds",
            displayName = "melonDS",
            packageNames = listOf("me.magnum.melonds"),
            supportedPlatforms = setOf(Platform.NDS)
        ),
        PackageEmulatorAdapter(
            id = "drastic",
            displayName = "DraStic",
            packageNames = listOf("com.dsemu.drastic"),
            supportedPlatforms = setOf(Platform.NDS)
        ),
        PackageEmulatorAdapter(
            id = "azahar",
            displayName = "Azahar",
            packageNames = listOf("org.azahar_emu.azahar"),
            supportedPlatforms = setOf(Platform.N3DS)
        ),
        PackageEmulatorAdapter(
            id = "m64plusfz",
            displayName = "M64Plus FZ",
            packageNames = listOf("org.mupen64plusae.v3.fzurita", "org.mupen64plusae.v3.fzurita.pro"),
            supportedPlatforms = setOf(Platform.N64)
        ),
        PackageEmulatorAdapter(
            id = "flycast",
            displayName = "Flycast",
            packageNames = listOf("com.flycast.emulator"),
            supportedPlatforms = setOf(Platform.DREAMCAST)
        ),
        PackageEmulatorAdapter(
            id = "redream",
            displayName = "Redream",
            packageNames = listOf("io.recompiled.redream"),
            supportedPlatforms = setOf(Platform.DREAMCAST)
        ),
        PackageEmulatorAdapter(
            id = "retroarch",
            displayName = "RetroArch",
            packageNames = listOf("com.retroarch", "com.retroarch.aarch64", "com.retroarch.ra32"),
            supportedPlatforms = setOf(
                Platform.PS1, Platform.PSP, Platform.NDS, Platform.N3DS, Platform.N64,
                Platform.GB_GBC, Platform.GBA, Platform.NES, Platform.SNES, Platform.MEGA_DRIVE,
                Platform.DREAMCAST, Platform.GAMECUBE, Platform.WII, Platform.ARCADE
            )
        )
    )
}
