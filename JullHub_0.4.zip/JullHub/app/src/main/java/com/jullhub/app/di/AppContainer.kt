package com.jullhub.app.di

import android.content.Context
import androidx.room.Room
import com.jullhub.app.data.db.JullDatabase
import com.jullhub.app.data.folders.DataStoreFolderRepository
import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.folders.SafPermissions
import com.jullhub.app.data.games.RoomGameRepository
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.data.jullDataStore
import com.jullhub.app.data.scanner.GameScanner
import com.jullhub.app.data.scanner.ScanManager
import com.jullhub.app.data.settings.DataStoreSettingsRepository
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.emulator.EmulatorCatalog
import com.jullhub.app.emulator.EmulatorRegistry
import com.jullhub.app.emulator.GameLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Inyección manual de dependencias (suficiente para esta fase). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val applicationContext: Context get() = appContext

    val settingsRepository: SettingsRepository =
        DataStoreSettingsRepository(appContext.jullDataStore)

    val folderRepository: FolderRepository = DataStoreFolderRepository(
        context = appContext,
        dataStore = appContext.jullDataStore,
        permissions = SafPermissions(appContext.contentResolver)
    )

    /** Room es la fuente de verdad de la biblioteca; se abre de forma perezosa en la primera consulta. */
    private val database: JullDatabase =
        Room.databaseBuilder(appContext, JullDatabase::class.java, "jullhub.db").build()

    val gameRepository: GameRepository = RoomGameRepository(database)

    val gameScanner = GameScanner(appContext.contentResolver)
    val scanManager = ScanManager(
        folders = folderRepository,
        scanner = gameScanner,
        games = gameRepository,
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    )

    /** Catálogo de emuladores (solo detección en 0.4); ver [EmulatorCatalog]. */
    val emulatorRegistry = EmulatorRegistry(adapters = EmulatorCatalog.adapters())
    val gameLauncher = GameLauncher(emulatorRegistry)
}
