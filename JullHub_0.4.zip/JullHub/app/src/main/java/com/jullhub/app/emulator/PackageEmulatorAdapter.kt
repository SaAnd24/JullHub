package com.jullhub.app.emulator

import android.content.Context
import android.content.Intent
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/**
 * Adapter basado en datos: declara paquete(s) y plataformas, y solo sabe detectar si está instalado.
 *
 * En 0.4 no se lanza ningún juego, por eso [buildLaunchIntent] devuelve `null`. En 0.5, cada
 * emulador que necesite un Intent propio tendrá su subclase de [BaseEmulatorAdapter] y
 * sustituirá a su entrada en [EmulatorCatalog].
 */
class PackageEmulatorAdapter(
    override val id: String,
    override val displayName: String,
    override val packageNames: List<String>,
    override val supportedPlatforms: Set<Platform>
) : BaseEmulatorAdapter() {
    override fun buildLaunchIntent(context: Context, game: Game): Intent? = null
}
