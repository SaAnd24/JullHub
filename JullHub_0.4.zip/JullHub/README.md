# JullHub

Launcher y gestor de juegos para Android (Kotlin, Jetpack Compose, Material 3). **No es un emulador.**
Estado: v0.4 (Biblioteca por consolas + detección de emuladores). Sin lanzamiento real de emuladores.

## Abrir y compilar
1. Android Studio (Ladybug 2024.2 o superior) → *Open* → carpeta `JullHub`.
2. Esperar el *Gradle sync* (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, JDK 17).
3. Ejecutar la configuración `app`. minSdk 26, targetSdk 35.

## Arquitectura (`app/src/main/java/com/jullhub/app`)
- `core/model` — `Game`, `Platform`, `GameFolder`.
- `emulator` — `EmulatorAdapter`, `BaseEmulatorAdapter`, `EmulatorRegistry`, `GameLauncher`.
  Añadir un emulador = crear su adapter y registrarlo en `di/AppContainer.kt`.
- `data` — DataStore, `FolderRepository` (SAF + permisos persistentes), `SettingsRepository`, `GameRepository` (Room).
- `data/db` — Room: `JullDatabase`, `GameDao`, `GameEntity` (+ conversiones `Game ↔ GameEntity`).
- `data/scanner` — `GameScanner` (recorrido SAF), `PlatformDetector` (carpetas -> plataforma), `GameFileFilter` (extensiones), `ScanManager` (orquesta el escaneo).
- `di` — `AppContainer` (inyección manual).
- `ui` — tema, componentes, navegación y pantallas (Inicio, Biblioteca, Emuladores, Configuración).

## Escáner (v0.2)
Flujo implementado: Carpetas SAF → `GameScanner` → `Game` → Biblioteca.
- Ampliar formatos: `GameFileFilter.DEFAULT_EXTENSIONS`. Ampliar nombres de carpeta: `PlatformDetector.DEFAULT_ALIASES`.
- La plataforma se decide por el contexto de carpetas; si no hay confianza suficiente, `Platform.UNKNOWN`.
- Los juegos se guardan en Room (`jullhub.db`): no hace falta re-escanear al abrir la app. El escaneo solo detecta cambios (altas, bajas, cambios).
- Identidad: el `id` del juego es la URI SAF del documento, así que re-escanear nunca duplica.
- Carpetas inaccesibles o leídas en parte: sus juegos no se borran de Room.
- Favoritos: corazón en la tarjeta de la Biblioteca, persistido en Room.

## Biblioteca por consolas y emuladores (v0.4)
- La Biblioteca navega por consolas con juegos (swipe horizontal o vertical, ajustable en Configuración → Biblioteca → Navegación, guardado en DataStore). Todos/Favoritos/Recientes son accesos secundarios.
- `PlatformEmblem` (ui/components) es la representación visual de cada consola; sustituirla por assets propios solo requiere cambiar ese componente.
- `emulator/EmulatorCatalog.kt` lista los emuladores (id, nombre, paquetes, plataformas). Añadir uno = nueva entrada + sus paquetes en `<queries>` del manifest (necesario en Android 11+).
- `EmulatorRegistry.installedCompatibleWith(context, game)`: juego → plataforma → emuladores compatibles instalados. En 0.4 solo se detecta; no se lanza nada.

Flujo futuro: Carpetas SAF → Escáner → Juegos → Plataforma → Emulador → EmulatorAdapter → Intent → Juego iniciado.

## Notas
- Sin `MANAGE_EXTERNAL_STORAGE`; solo `ACTION_OPEN_DOCUMENT_TREE` con permiso de lectura persistente.
- `gradlew` no se incluye; Android Studio descarga Gradle según `gradle/wrapper/gradle-wrapper.properties`.
