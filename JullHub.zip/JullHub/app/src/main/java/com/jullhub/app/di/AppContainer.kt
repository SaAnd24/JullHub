package com.jullhub.app.di

import android.content.Context
import com.jullhub.app.data.folders.DataStoreFolderRepository
import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.folders.SafPermissions
import com.jullhub.app.data.games.EmptyGameRepository
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.data.jullDataStore
import com.jullhub.app.data.settings.DataStoreSettingsRepository
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.emulator.EmulatorRegistry
import com.jullhub.app.emulator.GameLauncher

/** Inyección manual de dependencias (suficiente para esta fase). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val applicationContext: Context get() = appContext

    val settingsRepository: SettingsRepository =
        DataStoreSettingsRepository(appContext.jullDataStore)

    val folderRepository: FolderRepository = DataStoreFolderRepository(
        context = appContext,
        dataStore = appContext.jullDataStore,
        permissions = SafPermissions(appContext.contentResolver)
    )

    val gameRepository: GameRepository = EmptyGameRepository()

    /** Sin adapters todavía: cada emulador futuro se añade aquí. */
    val emulatorRegistry = EmulatorRegistry(adapters = emptyList())
    val gameLauncher = GameLauncher(emulatorRegistry)
}
