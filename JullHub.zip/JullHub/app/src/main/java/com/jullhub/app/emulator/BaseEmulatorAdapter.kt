package com.jullhub.app.emulator

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.jullhub.app.core.model.Game

/**
 * Plantilla común: detecta instalación, valida compatibilidad y lanza el Intent.
 * Un adapter concreto solo declara sus datos y implementa [buildLaunchIntent].
 *
 * Nota: desde Android 11 detectar paquetes requiere declararlos en `<queries>` del
 * manifest; cada adapter nuevo debe añadir los suyos.
 */
abstract class BaseEmulatorAdapter : EmulatorAdapter {

    /** Devuelve el Intent de lanzamiento, o `null` si faltan datos del juego (URI, Title ID...). */
    protected abstract fun buildLaunchIntent(context: Context, game: Game): Intent?

    override fun isInstalled(context: Context): Boolean = packageNames.any { pkg ->
        try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    override fun supports(game: Game): Boolean = game.platform in supportedPlatforms

    final override fun launch(context: Context, game: Game): LaunchResult {
        if (!isInstalled(context)) return LaunchResult.Failure(LaunchError.NOT_INSTALLED)
        if (!supports(game)) return LaunchResult.Failure(LaunchError.UNSUPPORTED_GAME)
        val intent = buildLaunchIntent(context, game)
            ?: return LaunchResult.Failure(LaunchError.MISSING_GAME_DATA)
        return try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            LaunchResult.Success
        } catch (e: ActivityNotFoundException) {
            LaunchResult.Failure(LaunchError.ACTIVITY_NOT_FOUND, e.message)
        } catch (e: SecurityException) {
            LaunchResult.Failure(LaunchError.PERMISSION_DENIED, e.message)
        } catch (e: Exception) {
            LaunchResult.Failure(LaunchError.UNKNOWN, e.message)
        }
    }
}
