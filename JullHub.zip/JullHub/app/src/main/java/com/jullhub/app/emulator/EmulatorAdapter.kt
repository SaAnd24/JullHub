package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/**
 * Contrato que cada emulador implementa. Toda la lógica específica de un emulador
 * (paquete, Intent, URI/Title ID/core) vive en su adapter; la UI y la biblioteca
 * solo conocen esta interfaz.
 */
interface EmulatorAdapter {
    val id: String
    val displayName: String
    val packageNames: List<String>
    val supportedPlatforms: Set<Platform>

    fun isInstalled(context: Context): Boolean
    fun supports(game: Game): Boolean
    fun launch(context: Context, game: Game): LaunchResult
}

sealed interface LaunchResult {
    data object Success : LaunchResult
    data class Failure(val error: LaunchError, val message: String? = null) : LaunchResult
}

enum class LaunchError {
    NO_EMULATOR,
    NOT_INSTALLED,
    UNSUPPORTED_GAME,
    MISSING_GAME_DATA,
    PERMISSION_DENIED,
    ACTIVITY_NOT_FOUND,
    UNKNOWN
}
