package com.jullhub.app.data.games

import com.jullhub.app.core.model.Game
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Fuente de juegos. La implementación con Room llegará cuando exista el escáner. */
interface GameRepository {
    fun observeGames(): Flow<List<Game>>
}

/** Implementación inicial: biblioteca vacía hasta que exista el escaneo. */
class EmptyGameRepository : GameRepository {
    private val games = MutableStateFlow<List<Game>>(emptyList())
    override fun observeGames(): Flow<List<Game>> = games.asStateFlow()
}
