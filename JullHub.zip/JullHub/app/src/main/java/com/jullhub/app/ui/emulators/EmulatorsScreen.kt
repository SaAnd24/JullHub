package com.jullhub.app.ui.emulators

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.ui.components.EmptyState

@Composable
fun EmulatorsScreen(
    factory: ViewModelProvider.Factory,
    vm: EmulatorsViewModel = viewModel(factory = factory)
) {
    val items by vm.items.collectAsStateWithLifecycle()
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    Column(modifier = Modifier.fillMaxSize().padding(top = 16.dp)) {
        Text(
            text = "Emuladores",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(16.dp))
        if (items.isEmpty()) {
            EmptyState(
                icon = Icons.Rounded.SportsEsports,
                title = "Aún no hay emuladores",
                body = "Aquí aparecerán los emuladores compatibles que tengas instalados."
            )
        } else {
            LazyColumn {
                items(items, key = { it.id }) { emulator ->
                    ListItem(
                        headlineContent = { Text(emulator.name) },
                        supportingContent = {
                            Text(emulator.platforms.joinToString(", ") { it.displayName })
                        },
                        trailingContent = {
                            Text(if (emulator.installed) "Instalado" else "No instalado")
                        }
                    )
                }
            }
        }
    }
}
