package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game

/** Juego → adapter → Intent. Aún no está conectado a la UI (no hay juegos ni adapters). */
class GameLauncher(private val registry: EmulatorRegistry) {

    fun resolveAdapter(context: Context, game: Game): EmulatorAdapter? =
        game.emulatorId?.let { registry.byId(it) }
            ?: registry.compatibleWith(game).firstOrNull { it.isInstalled(context) }

    fun launch(context: Context, game: Game): LaunchResult {
        val adapter = resolveAdapter(context, game)
            ?: return LaunchResult.Failure(LaunchError.NO_EMULATOR)
        return adapter.launch(context, game)
    }
}
