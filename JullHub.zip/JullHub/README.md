# JullHub

Launcher y gestor de juegos para Android (Kotlin, Jetpack Compose, Material 3). **No es un emulador.**
Estado: Fase 1 (base funcional). Sin escaneo de ROMs ni lanzamiento real de emuladores.

## Abrir y compilar
1. Android Studio (Ladybug 2024.2 o superior) → *Open* → carpeta `JullHub`.
2. Esperar el *Gradle sync* (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, JDK 17).
3. Ejecutar la configuración `app`. minSdk 26, targetSdk 35.

## Arquitectura (`app/src/main/java/com/jullhub/app`)
- `core/model` — `Game`, `Platform`, `GameFolder`.
- `emulator` — `EmulatorAdapter`, `BaseEmulatorAdapter`, `EmulatorRegistry`, `GameLauncher`.
  Añadir un emulador = crear su adapter y registrarlo en `di/AppContainer.kt`.
- `data` — DataStore, `FolderRepository` (SAF + permisos persistentes), `SettingsRepository`, `GameRepository`.
- `di` — `AppContainer` (inyección manual).
- `ui` — tema, componentes, navegación y pantallas (Inicio, Biblioteca, Emuladores, Configuración).

Flujo futuro: Carpetas SAF → Escáner → Juegos → Plataforma → Emulador → EmulatorAdapter → Intent → Juego iniciado.

## Notas
- Sin `MANAGE_EXTERNAL_STORAGE`; solo `ACTION_OPEN_DOCUMENT_TREE` con permiso de lectura persistente.
- `gradlew` no se incluye; Android Studio descarga Gradle según `gradle/wrapper/gradle-wrapper.properties`.
