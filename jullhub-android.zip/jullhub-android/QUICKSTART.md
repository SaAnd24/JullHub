# Guía Rápida - JullHub

## ¿Qué necesitas?

- Android Studio 2023.1+
- JDK 17+
- API 34 (se descarga automáticamente)

## Primeros pasos

### 1. Extraer el proyecto
```bash
unzip jullhub-android.zip
cd jullhub-android
```

### 2. Abrir en Android Studio
- **File** → **Open**
- Selecciona la carpeta `jullhub-android`

### 3. Esperar a que sincronice
- Android Studio descargará dependencias automáticamente
- Primera sincronización puede tardar 2-3 minutos

### 4. Compilar
- **Build** → **Make Project** (Ctrl+F9)
- Debería compilar sin errores

### 5. Ejecutar
**Opción A: Emulador**
- Abre Android Studio Device Manager
- Crea un emulador Android 14+ (API 34+)
- **Run** → **Run 'app'** (Shift+F10)

**Opción B: Dispositivo físico**
- Conecta tu teléfono Android
- Activa Debug USB
- **Run** → **Run 'app'**

## ¿Qué esperar?

La aplicación abre con 4 pantallas:

1. **Inicio** 📱
   - Muestra "Continuar jugando" (vacío por ahora)
   - Lista de recientes, favoritos, añadidos

2. **Biblioteca** 🎮
   - "No hay juegos agregados"
   - Botón "+ Añadir carpeta" funcional

3. **Emuladores** 🕹️
   - Muestra PPSSPP como ejemplo
   - Indica si está instalado o no

4. **Configuración** ⚙️
   - Toggle para modo oscuro
   - Gestión de carpetas
   - Información de la app

## Funcionalidad en esta fase

✅ **Funcionando**
- Navegación entre pantallas
- Tema Material 3 con modo oscuro
- Búsqueda en biblioteca (sin datos, pero preparada)
- Gestor de carpetas en configuración
- Detección de PPSSPP (si está instalado)

❌ **Pendiente (Fases posteriores)**
- Lanzamiento real de emuladores
- Escaneo de ROMs
- Descarga de portadas
- Base de datos con juegos reales

## Estructura de carpetas clave

```
app/src/main/java/com/jullhub/app/
├── domain/            ← Lógica de emuladores + Modelos
├── data/              ← Persistencia + Repositorios
└── ui/                ← Pantallas + ViewModels + Tema
```

Para **agregar un nuevo emulador**:
1. Crear `domain/emulator/TuEmuladorAdapter.kt`
2. Heredar de `BaseEmulatorAdapter`
3. Implementar métodos abstractos
4. Registrar en `EmulatorRepository.init`
5. ¡Sin cambios en UI!

## Troubleshooting

### "Gradle sync failed"
- **Solución**: Invalidate Caches → Restart (File menu)

### "Could not find AGP dependency"
- **Solución**: Ve a Tools → SDK Manager → Descarga API 34

### "No emulator found"
- **Solución**: Android Studio Device Manager → Crea emulador

### APK no instala
- **Solución**: Asegúrate de que minSdk=28 coincide con tu dispositivo

## Próximas mejoras

Documento **NEXTPHASE.md** contiene detalles sobre:
- Cómo implementar escaneo de ROMs
- Cómo agregar más emuladores
- Cómo pasar a Room Database
- Cómo integrar SAF

## Versión

**JullHub v0.1.0** - Fase 1  
Compilación: ✅ Exitosa

---

¿Preguntas? Consulta **README.md** o **ARCHITECTURE.md** para más detalles.
