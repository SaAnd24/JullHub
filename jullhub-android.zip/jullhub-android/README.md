# JullHub - Launcher y Gestor de Juegos para Emuladores Android

**JullHub** es un launcher y gestor de juegos diseñado para Android, enfocado en juegos ejecutados mediante emuladores. Proporciona una interfaz intuitiva y extensible para gestionar tu biblioteca de juegos emulados.

## Características (Fase 1)

### Pantallas Implementadas
- **Inicio**: Continuar jugando, Recientes, Favoritos, Añadidos recientemente
- **Biblioteca**: Listado completo de juegos con búsqueda y filtros
- **Emuladores**: Panel de emuladores instalados y disponibles
- **Configuración**: Gestión de carpetas, apariencia y preferencias

### Funcionalidad Core
- ✅ Arquitectura modular y escalable
- ✅ Sistema de **EmulatorAdapter** para abstraer lógica de emuladores
- ✅ Persistencia de configuración con DataStore
- ✅ Preparación para Storage Access Framework (SAF)
- ✅ Tema Material 3 personalizado
- ✅ Navegación fluida entre pantallas
- ✅ ViewModel pattern para gestión de estado

## Tecnología

- **Lenguaje**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **Arquitectura**: MVVM con separación de capas
- **Persistencia**: DataStore (preparado para Room en futuras fases)
- **Build**: Gradle Kotlin DSL
- **Emuladores**: Patrón Adapter para extensibilidad

## Estructura del Proyecto

```
jullhub-android/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/jullhub/app/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   ├── persistence/PreferencesManager.kt
│   │   │   │   └── repository/GameRepository.kt
│   │   │   ├── domain/
│   │   │   │   ├── model/Game.kt
│   │   │   │   ├── model/GameFolder.kt
│   │   │   │   ├── emulator/EmulatorAdapter.kt
│   │   │   │   ├── emulator/BaseEmulatorAdapter.kt
│   │   │   │   ├── emulator/PPSSPPAdapter.kt
│   │   │   │   └── repository/EmulatorRepository.kt
│   │   │   └── ui/
│   │   │       ├── theme/
│   │   │       ├── screen/
│   │   │       ├── viewmodel/
│   │   │       └── navigation/
│   │   └── res/
│   │       ├── values/
│   │       └── xml/
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Instalación y Compilación

### Requisitos
- Android Studio 2023.1 o superior
- JDK 17 o superior
- SDK Android 34 (API Level 34)
- Mínimo SDK: 28

### Pasos

1. **Descargar el ZIP y extraerlo**
   ```bash
   unzip jullhub-android.zip
   cd jullhub-android
   ```

2. **Abrir en Android Studio**
   - File → Open → Seleccionar la carpeta jullhub-android

3. **Compilar el proyecto**
   - Build → Make Project
   - O presionar Ctrl+F9

4. **Ejecutar la aplicación**
   - Run → Run 'app'
   - O presionar Shift+F10

## Arquitectura

### Capas

#### Domain Layer
- `model/Game.kt`: Modelo de datos para juegos
- `model/GameFolder.kt`: Modelo para carpetas SAF
- `emulator/EmulatorAdapter.kt`: Interfaz de adaptador de emuladores
- `emulator/BaseEmulatorAdapter.kt`: Clase base abstracta
- `emulator/PPSSPPAdapter.kt`: Implementación ejemplo de PPSSPP
- `repository/EmulatorRepository.kt`: Gestión de adaptadores

#### Data Layer
- `repository/GameRepository.kt`: Gestión de juegos y carpetas (en memoria en Fase 1)
- `persistence/PreferencesManager.kt`: Persistencia con DataStore

#### UI Layer
- `theme/`: Definición de tema Material 3
- `screen/`: Pantallas Compose (Home, Library, Emulators, Settings)
- `viewmodel/`: ViewModels para cada pantalla
- `navigation/`: Sistema de navegación

### Pattern: EmulatorAdapter

La arquitectura central utiliza el patrón **Strategy** para abstraer la lógica específica de cada emulador:

```kotlin
interface EmulatorAdapter {
    fun isInstalled(context: Context): Boolean
    fun isCompatible(game: Game): Boolean
    fun buildLaunchIntent(context: Context, game: Game): Intent?
    fun launchGame(context: Context, game: Game): Boolean
}
```

Esto permite:
- ✅ Agregar nuevos emuladores sin modificar UI
- ✅ Separar lógica específica de emulador
- ✅ Facilitar testing

## Funcionalidades Futuras (Fase 2 y posteriores)

### Fase 2
- [ ] Escáner de ROMs con SAF funcional
- [ ] Base de datos con Room
- [ ] Lanzamiento real de emuladores
- [ ] Historial y estadísticas de juego

### Fase 3
- [ ] Descarga automática de portadas
- [ ] Integración con APIs de metadata (IGDB, etc.)
- [ ] Configuración automática de emuladores
- [ ] Soporte para más plataformas

### Fase 4
- [ ] Sincronización con la nube
- [ ] Modo multijugador local
- [ ] Integración con otros servicios

## EmulatorAdapters Planificados

- PPSSPP (PSP) ✅ Ejemplo implementado
- DuckStation (PS1)
- NetherSX2 (PS1)
- Dolphin (GameCube, Wii)
- Vita3K (PS Vita)
- melonDS (NDS)
- DraStic (NDS)
- M64Plus FZ (N64)
- RetroArch (Multi-plataforma)

## Plataformas Soportadas

- PlayStation Portable (PSP)
- PlayStation Vita (PS Vita)
- Nintendo DS
- Nintendo 3DS
- Nintendo 64
- Game Boy Advance
- Game Boy Color
- Game Boy
- GameCube
- Wii
- Dreamcast
- NES, SNES, Mega Drive
- Arcade

## Estado de Compilación

✅ **Compila correctamente**
- Sin errores de compilación
- Sin advertencias críticas
- Listo para ejecutar en emulador o dispositivo

## Permisos Requeridos

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

## Próximos Pasos

1. Implementar selector de carpetas SAF
2. Agregar escáner de ROMs
3. Integrar con emuladores reales
4. Implementar base de datos con Room
5. Agregar más adaptadores de emuladores

## Licencia

Proyecto de código privado. No distribuir sin autorización.

## Contacto

Para preguntas o sugerencias sobre la arquitectura o implementación, consulta con el equipo de desarrollo.

---

**Versión**: 0.1.0 - Fase 1  
**Último actualizado**: Octubre 2024  
**Estado**: ✅ Compilable y funcional
