# Reglas de ProGuard para JullHub

# Mantener nombres de clases usadas por reflexión
-keep class com.jullhub.app.** { *; }

# Mantener anotaciones
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Mantener métodos de punto de entrada
-keep public class com.jullhub.app.MainActivity
-keep public class com.jullhub.app.** {
    public <init>(...);
}

# Composable
-keep class androidx.compose.** { *; }

# Kotlin
-dontwarn kotlin.jvm.internal.Reflection
-keep class kotlin.** { *; }

# Coroutines
-keep class kotlinx.coroutines.** { *; }

# DataStore
-keep class androidx.datastore.** { *; }
