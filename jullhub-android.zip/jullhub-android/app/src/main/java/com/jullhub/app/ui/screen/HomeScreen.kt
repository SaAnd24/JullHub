package com.jullhub.app.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullhub.app.domain.model.Game
import com.jullhub.app.ui.viewmodel.HomeViewModel

/**
 * Pantalla de Inicio.
 * Muestra: Continuar jugando, Recientes, Favoritos, Añadidos recientemente.
 */
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onGameSelected: (Game) -> Unit = {},
    onPlayGame: (Game) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (uiState.isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Continuar jugando
                if (uiState.continuePlayingGame != null) {
                    item {
                        SectionTitle("Continuar jugando")
                    }
                    item {
                        GameCardContinue(
                            game = uiState.continuePlayingGame,
                            onPlayClick = { onPlayGame(uiState.continuePlayingGame) }
                        )
                    }
                }

                // Recientes
                if (uiState.recentGames.isNotEmpty()) {
                    item {
                        SectionTitle("Recientes")
                    }
                    items(uiState.recentGames) { game ->
                        GameCard(
                            game = game,
                            onCardClick = { onGameSelected(game) },
                            onPlayClick = { onPlayGame(game) }
                        )
                    }
                }

                // Favoritos
                if (uiState.favoriteGames.isNotEmpty()) {
                    item {
                        SectionTitle("Favoritos")
                    }
                    items(uiState.favoriteGames) { game ->
                        GameCard(
                            game = game,
                            onCardClick = { onGameSelected(game) },
                            onPlayClick = { onPlayGame(game) }
                        )
                    }
                }

                // Añadidos recientemente
                if (uiState.recentlyAddedGames.isNotEmpty()) {
                    item {
                        SectionTitle("Añadidos recientemente")
                    }
                    items(uiState.recentlyAddedGames) { game ->
                        GameCard(
                            game = game,
                            onCardClick = { onGameSelected(game) },
                            onPlayClick = { onPlayGame(game) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun GameCard(
    game: Game,
    onCardClick: () -> Unit,
    onPlayClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 16.dp)
            ) {
                Text(
                    text = game.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = game.platform.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onPlayClick) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Jugar",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun GameCardContinue(
    game: Game,
    onPlayClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = game.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = game.platform.displayName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier
                    .align(Alignment.End)
            ) {
                IconButton(onClick = onPlayClick) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Jugar",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
