package com.jullhub.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.data.repository.GameRepository
import com.jullhub.app.domain.model.Game
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel para la pantalla de Inicio.
 * Gestiona estado de: continuar jugando, recientes, favoritos, añadidos recientemente.
 */
class HomeViewModel(
    private val gameRepository: GameRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHomeData()
    }

    private fun loadHomeData() {
        viewModelScope.launch {
            val continueGame = gameRepository.getRecentGames(1).firstOrNull()
            val recentGames = gameRepository.getRecentGames(5)
            val favoriteGames = gameRepository.getFavoriteGames()
            val recentlyAddedGames = gameRepository.getRecentlyAddedGames(5)

            _uiState.value = _uiState.value.copy(
                continuePlayingGame = continueGame,
                recentGames = recentGames,
                favoriteGames = favoriteGames,
                recentlyAddedGames = recentlyAddedGames,
                isLoading = false
            )
        }
    }

    /**
     * Refresca los datos de inicio.
     */
    fun refresh() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        loadHomeData()
    }

    /**
     * Marca un juego como favorito.
     */
    fun toggleFavorite(gameId: String) {
        gameRepository.toggleFavorite(gameId)
        loadHomeData()
    }
}

/**
 * Estado de UI de la pantalla de Inicio.
 */
data class HomeUiState(
    val continuePlayingGame: Game? = null,
    val recentGames: List<Game> = emptyList(),
    val favoriteGames: List<Game> = emptyList(),
    val recentlyAddedGames: List<Game> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)
