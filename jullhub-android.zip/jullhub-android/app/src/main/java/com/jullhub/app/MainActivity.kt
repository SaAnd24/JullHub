package com.jullhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.jullhub.app.data.persistence.PreferencesManager
import com.jullhub.app.data.repository.GameRepository
import com.jullhub.app.domain.repository.EmulatorRepository
import com.jullhub.app.ui.navigation.BottomNavBar
import com.jullhub.app.ui.navigation.NavGraph
import com.jullhub.app.ui.theme.JullHubTheme
import com.jullhub.app.ui.viewmodel.EmulatorsViewModel
import com.jullhub.app.ui.viewmodel.HomeViewModel
import com.jullhub.app.ui.viewmodel.LibraryViewModel
import com.jullhub.app.ui.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    // Instancias de repositorios
    private val gameRepository = GameRepository()
    private val emulatorRepository = EmulatorRepository()

    // ViewModels
    private lateinit var homeViewModel: HomeViewModel
    private lateinit var libraryViewModel: LibraryViewModel
    private lateinit var emulatorsViewModel: EmulatorsViewModel
    private lateinit var settingsViewModel: SettingsViewModel

    // Preferences
    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar PreferencesManager
        preferencesManager = PreferencesManager(this)

        // Inicializar ViewModels
        homeViewModel = HomeViewModel(gameRepository)
        libraryViewModel = LibraryViewModel(gameRepository)
        emulatorsViewModel = EmulatorsViewModel(emulatorRepository)
        settingsViewModel = SettingsViewModel(preferencesManager, gameRepository)

        setContent {
            JullHubApp(
                homeViewModel = homeViewModel,
                libraryViewModel = libraryViewModel,
                emulatorsViewModel = emulatorsViewModel,
                settingsViewModel = settingsViewModel
            )
        }
    }

    @Composable
    private fun JullHubApp(
        homeViewModel: HomeViewModel,
        libraryViewModel: LibraryViewModel,
        emulatorsViewModel: EmulatorsViewModel,
        settingsViewModel: SettingsViewModel
    ) {
        // Observar el estado del modo oscuro
        val darkModeFlow = preferencesManager.darkModeFlow
        val isDarkMode by darkModeFlow.collectAsState(initial = false)

        JullHubTheme(darkTheme = isDarkMode) {
            val navController = rememberNavController()

            // Cargar emuladores al iniciar
            LaunchedEffect(Unit) {
                emulatorsViewModel.loadInstalledEmulators(this@MainActivity)
            }

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    BottomNavBar(navController = navController)
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    NavGraph(
                        navController = navController,
                        homeViewModel = homeViewModel,
                        libraryViewModel = libraryViewModel,
                        emulatorsViewModel = emulatorsViewModel,
                        settingsViewModel = settingsViewModel,
                        onAddFolderClick = {
                            // TODO: Implementar selector de carpetas SAF
                            navController.navigate("settings")
                        },
                        onGameSelected = { gameId ->
                            // TODO: Implementar pantalla de detalles del juego
                        },
                        onPlayGame = { gameId ->
                            // TODO: Implementar lanzamiento de juego
                        }
                    )
                }
            }
        }
    }
}
