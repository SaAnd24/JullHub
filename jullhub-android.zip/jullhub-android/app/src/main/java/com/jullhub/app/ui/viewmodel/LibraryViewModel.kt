package com.jullhub.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.data.repository.GameRepository
import com.jullhub.app.domain.model.Game
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel para la pantalla de Biblioteca.
 * Gestiona búsqueda, filtros y listado de juegos.
 */
class LibraryViewModel(
    private val gameRepository: GameRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    init {
        loadGames()
    }

    private fun loadGames() {
        viewModelScope.launch {
            val games = gameRepository.getAllGames()
            _uiState.value = _uiState.value.copy(
                allGames = games,
                displayedGames = games,
                isLoading = false
            )
        }
    }

    /**
     * Busca juegos por título.
     */
    fun searchGames(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)

        viewModelScope.launch {
            val results = if (query.isEmpty()) {
                gameRepository.getAllGames()
            } else {
                gameRepository.searchGames(query)
            }
            _uiState.value = _uiState.value.copy(displayedGames = results)
        }
    }

    /**
     * Marca un juego como favorito.
     */
    fun toggleFavorite(gameId: String) {
        gameRepository.toggleFavorite(gameId)
        loadGames()
    }

    /**
     * Elimina un juego de la biblioteca.
     */
    fun removeGame(gameId: String) {
        gameRepository.removeGame(gameId)
        loadGames()
    }

    /**
     * Refresca la lista de juegos.
     */
    fun refresh() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        loadGames()
    }
}

/**
 * Estado de UI de la pantalla de Biblioteca.
 */
data class LibraryUiState(
    val allGames: List<Game> = emptyList(),
    val displayedGames: List<Game> = emptyList(),
    val searchQuery: String = "",
    val selectedFilter: String? = null,
    val isLoading: Boolean = true,
    val error: String? = null,
    val isEmpty: Boolean = false
)
