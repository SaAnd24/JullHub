package com.jullhub.app.data.repository

import com.jullhub.app.domain.model.Game
import com.jullhub.app.domain.model.GameFolder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Repositorio para gestionar juegos y carpetas.
 * 
 * En la fase 1 usa datos en memoria.
 * Posteriormente será reemplazado con Room Database.
 */
class GameRepository {

    // Almacenamiento en memoria (será reemplazado con Room en fase posterior)
    private val _games = MutableStateFlow<List<Game>>(emptyList())
    val games: Flow<List<Game>> = _games.asStateFlow()

    private val _folders = MutableStateFlow<List<GameFolder>>(emptyList())
    val folders: Flow<List<GameFolder>> = _folders.asStateFlow()

    // Juegos favoritos
    private val _favorites = MutableStateFlow<Set<String>>(emptySet())
    val favorites: Flow<Set<String>> = _favorites.asStateFlow()

    // Últimos jugados
    private val _recentlyPlayed = MutableStateFlow<List<Game>>(emptyList())
    val recentlyPlayed: Flow<List<Game>> = _recentlyPlayed.asStateFlow()

    /**
     * Obtiene todos los juegos.
     */
    fun getAllGames(): List<Game> = _games.value

    /**
     * Obtiene todos los juegos favoritos.
     */
    fun getFavoriteGames(): List<Game> = _games.value.filter { it.isFavorite }

    /**
     * Obtiene los juegos recientes.
     */
    fun getRecentGames(limit: Int = 5): List<Game> {
        return _games.value
            .filter { it.lastPlayedAt != null }
            .sortedByDescending { it.lastPlayedAt }
            .take(limit)
    }

    /**
     * Obtiene los juegos agregados recientemente.
     */
    fun getRecentlyAddedGames(limit: Int = 5): List<Game> {
        return _games.value
            .sortedByDescending { it.addedAt }
            .take(limit)
    }

    /**
     * Agrega un juego a la biblioteca.
     */
    fun addGame(game: Game) {
        val currentGames = _games.value.toMutableList()
        if (!currentGames.any { it.id == game.id }) {
            currentGames.add(game)
            _games.value = currentGames
        }
    }

    /**
     * Actualiza un juego existente.
     */
    fun updateGame(game: Game) {
        val currentGames = _games.value.toMutableList()
        val index = currentGames.indexOfFirst { it.id == game.id }
        if (index >= 0) {
            currentGames[index] = game
            _games.value = currentGames
        }
    }

    /**
     * Elimina un juego de la biblioteca.
     */
    fun removeGame(gameId: String) {
        _games.value = _games.value.filter { it.id != gameId }
    }

    /**
     * Marca un juego como favorito o no.
     */
    fun toggleFavorite(gameId: String) {
        val game = _games.value.find { it.id == gameId } ?: return
        updateGame(game.copy(isFavorite = !game.isFavorite))
    }

    /**
     * Agrega una carpeta de juegos.
     */
    fun addFolder(folder: GameFolder) {
        val currentFolders = _folders.value.toMutableList()
        if (!currentFolders.any { it.id == folder.id }) {
            currentFolders.add(folder)
            _folders.value = currentFolders
        }
    }

    /**
     * Obtiene todas las carpetas configuradas.
     */
    fun getAllFolders(): List<GameFolder> = _folders.value

    /**
     * Elimina una carpeta.
     */
    fun removeFolder(folderId: String) {
        _folders.value = _folders.value.filter { it.id != folderId }
    }

    /**
     * Actualiza una carpeta.
     */
    fun updateFolder(folder: GameFolder) {
        val currentFolders = _folders.value.toMutableList()
        val index = currentFolders.indexOfFirst { it.id == folder.id }
        if (index >= 0) {
            currentFolders[index] = folder
            _folders.value = currentFolders
        }
    }

    /**
     * Busca juegos por título.
     */
    fun searchGames(query: String): List<Game> {
        return _games.value.filter {
            it.title.contains(query, ignoreCase = true)
        }
    }

    /**
     * Obtiene juegos por plataforma.
     */
    fun getGamesByPlatform(platformId: String): List<Game> {
        return _games.value.filter { it.platform.name == platformId }
    }
}
