package com.jullhub.app.domain.repository

import android.content.Context
import com.jullhub.app.domain.emulator.EmulatorAdapter
import com.jullhub.app.domain.emulator.PPSSPPAdapter
import com.jullhub.app.domain.model.Game
import com.jullhub.app.domain.model.Platform

/**
 * Repositorio que gestiona todos los adaptadores de emuladores.
 * 
 * Responsabilidades:
 * - Mantener registro de emuladores disponibles
 * - Detectar emuladores instalados
 * - Encontrar adaptador compatible para un juego
 * - Gestionar el ciclo de vida de los adaptadores
 */
class EmulatorRepository {

    private val adapters: MutableList<EmulatorAdapter> = mutableListOf()

    init {
        // Registrar adaptadores disponibles (fase 1)
        // Más adelante se agregarán: DuckStation, Dolphin, Vita3K, melonDS, etc.
        adapters.add(PPSSPPAdapter())
    }

    /**
     * Obtiene todos los adaptadores registrados.
     */
    fun getAllAdapters(): List<EmulatorAdapter> = adapters.toList()

    /**
     * Obtiene todos los adaptadores instalados.
     */
    fun getInstalledAdapters(context: Context): List<EmulatorAdapter> {
        return adapters.filter { it.isInstalled(context) }
    }

    /**
     * Obtiene los adaptadores que pueden ejecutar un juego específico.
     */
    fun getCompatibleAdapters(context: Context, game: Game): List<EmulatorAdapter> {
        return adapters.filter { it.isInstalled(context) && it.isCompatible(game) }
    }

    /**
     * Obtiene el mejor adaptador para un juego.
     * Primero intenta el emulador asociado, luego busca uno compatible.
     */
    fun findAdapterForGame(context: Context, game: Game): EmulatorAdapter? {
        // Si el juego tiene un emulador específico asociado, intentar usarlo
        if (!game.associatedEmulator.isNullOrEmpty()) {
            val adapter = adapters.find { it.emulatorId == game.associatedEmulator }
            if (adapter?.isInstalled(context) == true && adapter.isCompatible(game)) {
                return adapter
            }
        }

        // Fallback: buscar cualquier adaptador compatible
        return getCompatibleAdapters(context, game).firstOrNull()
    }

    /**
     * Obtiene un adaptador específico por ID.
     */
    fun getAdapterById(emulatorId: String): EmulatorAdapter? {
        return adapters.find { it.emulatorId == emulatorId }
    }

    /**
     * Registra un nuevo adaptador (para extensiones futuras).
     */
    fun registerAdapter(adapter: EmulatorAdapter) {
        if (!adapters.any { it.emulatorId == adapter.emulatorId }) {
            adapters.add(adapter)
        }
    }

    /**
     * Obtiene información de todos los emuladores para debugging.
     */
    fun getEmulatorsSummary(context: Context): String {
        val installed = getInstalledAdapters(context)
        val available = adapters

        val summary = buildString {
            append("Emuladores registrados: ${available.size}\n")
            append("Emuladores instalados: ${installed.size}\n\n")
            for (adapter in available) {
                val status = if (installed.contains(adapter)) "✓ Instalado" else "✗ No instalado"
                append("• ${adapter.displayName} [$status]\n")
            }
        }
        return summary
    }
}
