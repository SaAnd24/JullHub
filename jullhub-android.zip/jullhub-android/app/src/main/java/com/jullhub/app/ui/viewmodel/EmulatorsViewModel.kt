package com.jullhub.app.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.domain.emulator.EmulatorAdapter
import com.jullhub.app.domain.repository.EmulatorRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel para la pantalla de Emuladores.
 * Gestiona detección y listado de emuladores disponibles.
 */
class EmulatorsViewModel(
    private val emulatorRepository: EmulatorRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(EmulatorsUiState())
    val uiState: StateFlow<EmulatorsUiState> = _uiState.asStateFlow()

    /**
     * Carga los emuladores instalados.
     */
    fun loadInstalledEmulators(context: Context) {
        viewModelScope.launch {
            val installed = emulatorRepository.getInstalledAdapters(context)
            val all = emulatorRepository.getAllAdapters()
            
            _uiState.value = _uiState.value.copy(
                allEmulators = all,
                installedEmulators = installed,
                isLoading = false,
                isEmpty = installed.isEmpty()
            )
        }
    }

    /**
     * Refresca el estado de los emuladores.
     */
    fun refreshEmulators(context: Context) {
        _uiState.value = _uiState.value.copy(isLoading = true)
        loadInstalledEmulators(context)
    }

    /**
     * Obtiene información de un emulador específico.
     */
    fun getEmulatorInfo(emulatorId: String): String {
        val adapter = emulatorRepository.getAdapterById(emulatorId)
        return adapter?.displayName ?: "Desconocido"
    }
}

/**
 * Estado de UI de la pantalla de Emuladores.
 */
data class EmulatorsUiState(
    val allEmulators: List<EmulatorAdapter> = emptyList(),
    val installedEmulators: List<EmulatorAdapter> = emptyList(),
    val isLoading: Boolean = true,
    val isEmpty: Boolean = true,
    val error: String? = null
)
