package com.jullhub.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.data.persistence.PreferencesManager
import com.jullhub.app.data.repository.GameRepository
import com.jullhub.app.domain.model.GameFolder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID

/**
 * ViewModel para la pantalla de Configuración.
 * Gestiona preferencias, carpetas, emuladores y apariencia.
 */
class SettingsViewModel(
    private val preferencesManager: PreferencesManager,
    private val gameRepository: GameRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            val darkMode = preferencesManager.getDarkMode()
            val folders = gameRepository.getAllFolders()
            
            _uiState.value = _uiState.value.copy(
                darkModeEnabled = darkMode,
                configuredFolders = folders,
                isLoading = false
            )
        }
    }

    /**
     * Activa o desactiva el modo oscuro.
     */
    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            preferencesManager.setDarkMode(enabled)
            _uiState.value = _uiState.value.copy(darkModeEnabled = enabled)
        }
    }

    /**
     * Agrega una carpeta de juegos.
     */
    fun addGameFolder(folderUri: String, folderName: String) {
        viewModelScope.launch {
            try {
                preferencesManager.addGameFolder(folderUri)
                val folder = GameFolder(
                    id = UUID.randomUUID().toString(),
                    name = folderName,
                    contentUri = folderUri,
                    addedAt = LocalDateTime.now(),
                    isActive = true
                )
                gameRepository.addFolder(folder)
                loadSettings()
                _uiState.value = _uiState.value.copy(
                    successMessage = "Carpeta agregada correctamente"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al agregar carpeta: ${e.message}"
                )
            }
        }
    }

    /**
     * Elimina una carpeta configurada.
     */
    fun removeGameFolder(folderId: String, folderUri: String) {
        viewModelScope.launch {
            try {
                preferencesManager.removeGameFolder(folderUri)
                gameRepository.removeFolder(folderId)
                loadSettings()
                _uiState.value = _uiState.value.copy(
                    successMessage = "Carpeta eliminada correctamente"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al eliminar carpeta: ${e.message}"
                )
            }
        }
    }

    /**
     * Limpia los mensajes de éxito o error.
     */
    fun clearMessages() {
        _uiState.value = _uiState.value.copy(
            successMessage = null,
            errorMessage = null
        )
    }
}

/**
 * Estado de UI de la pantalla de Configuración.
 */
data class SettingsUiState(
    val darkModeEnabled: Boolean = false,
    val configuredFolders: List<GameFolder> = emptyList(),
    val isLoading: Boolean = true,
    val successMessage: String? = null,
    val errorMessage: String? = null
)
