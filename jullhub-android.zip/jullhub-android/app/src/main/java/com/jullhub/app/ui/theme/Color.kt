package com.jullhub.app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFEADDFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val Purple90 = Color(0xFFF3E5F5)
val PurpleGrey90 = Color(0xFFF1EEF6)
val Pink90 = Color(0xFFFCE4EC)

val Purple30 = Color(0xFFB3008C)
val PurpleGrey30 = Color(0xFF8B7A96)
val Pink30 = Color(0xFFC51586)

val Purple20 = Color(0xFF7D2D5D)
val PurpleGrey20 = Color(0xFF49454A)
val Pink20 = Color(0xFF8A0A51)

val Purple10 = Color(0xFF5C2542)
val PurpleGrey10 = Color(0xFF2B2930)
val Pink10 = Color(0xFF620037)

val Red40 = Color(0xFFB3261E)
val Red80 = Color(0xFFF9DEDC)
val Red90 = Color(0xFFFCEDEA)
val Red30 = Color(0xFF8C0E0F)
val Red20 = Color(0xFF601410)
val Red10 = Color(0xFF410E0B)

val Grey99 = Color(0xFFFFFBFE)
val Grey95 = Color(0xFFF7F2FA)
val Grey90 = Color(0xFFEDE7F6)
val Grey80 = Color(0xFFD0C4DB)
val Grey60 = Color(0xFF79747E)
val Grey50 = Color(0xFF6F6C77)
val Grey40 = Color(0xFF625B71)
val Grey30 = Color(0xFF49454E)
val Grey20 = Color(0xFF1D1B20)
val Grey10 = Color(0xFF0F0D13)

val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
