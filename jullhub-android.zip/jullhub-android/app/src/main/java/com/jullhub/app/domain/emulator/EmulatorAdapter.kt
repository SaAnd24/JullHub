package com.jullhub.app.domain.emulator

import android.content.Context
import android.content.Intent
import com.jullhub.app.domain.model.Game

/**
 * Interfaz base para adaptadores de emuladores.
 * 
 * Cada emulador debe implementar esta interfaz para encapsular su lógica específica:
 * - Detección de instalación
 * - Compatibilidad de plataforma
 * - Construcción del Intent
 * - Parámetros específicos del emulador
 * 
 * Ejemplos de implementaciones futuras:
 * - PPSSPP (PSP)
 * - DuckStation (PS1)
 * - NetherSX2 (PS1)
 * - Dolphin (GameCube, Wii)
 * - Vita3K (PS Vita)
 * - melonDS (NDS)
 * - DraStic (NDS)
 * - M64Plus FZ (N64)
 * - RetroArch (Multi-plataforma)
 */
interface EmulatorAdapter {

    /**
     * Identificador único del emulador.
     * Ej: "ppsspp", "duckstation", "dolphin"
     */
    val emulatorId: String

    /**
     * Nombre legible del emulador.
     */
    val displayName: String

    /**
     * Nombre del paquete de la aplicación emuladora.
     * Ej: "org.ppsspp.ppsspp"
     */
    val packageName: String

    /**
     * Comprueba si el emulador está instalado en el dispositivo.
     */
    fun isInstalled(context: Context): Boolean

    /**
     * Obtiene la versión del emulador si está instalado.
     */
    fun getVersion(context: Context): String? = null

    /**
     * Comprueba si el emulador puede ejecutar un juego específico.
     * Basado en la plataforma y otros parámetros del juego.
     */
    fun isCompatible(game: Game): Boolean

    /**
     * Construye el Intent necesario para lanzar el juego.
     * 
     * @param context Contexto de la aplicación
     * @param game Juego a lanzar
     * @return Intent para lanzar el juego, o null si no puede hacerlo
     */
    fun buildLaunchIntent(context: Context, game: Game): Intent?

    /**
     * Lanza el juego usando el Intent construido.
     * 
     * @param context Contexto de la aplicación
     * @param game Juego a lanzar
     * @return true si se inició correctamente, false en caso contrario
     */
    fun launchGame(context: Context, game: Game): Boolean {
        return try {
            val intent = buildLaunchIntent(context, game)
            if (intent != null) {
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Obtiene un mensaje de error legible si algo sale mal.
     */
    fun getLastError(): String? = null
}
