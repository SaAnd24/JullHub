package com.jullhub.app.domain.model

import java.time.LocalDateTime

/**
 * Modelo de datos que representa un juego.
 * Diseñado para soportar múltiples plataformas y emuladores.
 */
data class Game(
    val id: String = "",
    val title: String = "",
    val platform: Platform = Platform.UNKNOWN,
    val uri: String = "",
    val fileName: String = "",
    val fileExtension: String = "",
    val associatedEmulator: String? = null,
    val emulatorSpecificId: String? = null,
    val titleId: String? = null,
    val coverArtUri: String? = null,
    val isFavorite: Boolean = false,
    val lastPlayedAt: LocalDateTime? = null,
    val playCount: Int = 0,
    val playTimeMinutes: Long = 0,
    val addedAt: LocalDateTime = LocalDateTime.now()
)

/**
 * Enumeración de plataformas soportadas.
 * Diseñada para crecer con nuevas plataformas.
 */
enum class Platform(val displayName: String) {
    UNKNOWN("Desconocida"),
    PSP("PlayStation Portable"),
    PS_VITA("PlayStation Vita"),
    NDS("Nintendo DS"),
    N3DS("Nintendo 3DS"),
    N64("Nintendo 64"),
    GBA("Game Boy Advance"),
    GBC("Game Boy Color"),
    GB("Game Boy"),
    GAMECUBE("GameCube"),
    WII("Wii"),
    DREAMCAST("Dreamcast"),
    NES("NES"),
    SNES("SNES"),
    MEGA_DRIVE("Mega Drive"),
    ARCADE("Arcade"),
    PS1("PlayStation 1"),
    PS2("PlayStation 2"),
    GENERIC("Genérica")
}
