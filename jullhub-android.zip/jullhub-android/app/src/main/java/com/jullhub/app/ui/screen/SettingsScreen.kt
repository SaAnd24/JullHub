package com.jullhub.app.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullhub.app.domain.model.GameFolder
import com.jullhub.app.ui.viewmodel.SettingsViewModel

/**
 * Pantalla de Configuración.
 * Gestiona: carpetas, apariencia, emuladores, biblioteca.
 */
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onAddFolderClick: () -> Unit = {},
    onNavigateToFolders: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (uiState.isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Apariencia
                item {
                    SectionHeader("Apariencia")
                }
                item {
                    SettingItem(
                        title = "Modo oscuro",
                        subtitle = if (uiState.darkModeEnabled) "Activado" else "Desactivado"
                    ) {
                        Switch(
                            checked = uiState.darkModeEnabled,
                            onCheckedChange = { viewModel.setDarkMode(it) }
                        )
                    }
                }

                // Carpetas
                item {
                    SectionHeader("Carpetas de juegos")
                }

                if (uiState.configuredFolders.isEmpty()) {
                    item {
                        Text(
                            text = "No hay carpetas configuradas",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                } else {
                    items(uiState.configuredFolders) { folder ->
                        FolderItem(
                            folder = folder,
                            onDeleteClick = {
                                viewModel.removeGameFolder(folder.id, folder.contentUri)
                            }
                        )
                    }
                }

                item {
                    Button(
                        onClick = onAddFolderClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text("Agregar carpeta")
                    }
                }

                // Información
                item {
                    SectionHeader("Información")
                }
                item {
                    SettingItem(
                        title = "Versión de la aplicación",
                        subtitle = "0.1.0 (Fase 1)"
                    )
                }
                item {
                    SettingItem(
                        title = "Autor",
                        subtitle = "JullHub Team"
                    )
                }
            }
        }

        // Mostrar mensajes de éxito/error
        if (!uiState.successMessage.isNullOrEmpty()) {
            // Aquí se mostraría un Snackbar
        }
        if (!uiState.errorMessage.isNullOrEmpty()) {
            // Aquí se mostraría un Snackbar de error
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun SettingItem(
    title: String,
    subtitle: String = "",
    trailingContent: @Composable (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 16.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (subtitle.isNotEmpty()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (trailingContent != null) {
                trailingContent()
            }
        }
    }
}

@Composable
fun FolderItem(
    folder: GameFolder,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 16.dp)
            ) {
                Text(
                    text = folder.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = folder.contentUri.takeLast(30),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = onDeleteClick) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Eliminar carpeta",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
