package com.jullhub.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.jullhub.app.ui.screen.EmulatorsScreen
import com.jullhub.app.ui.screen.HomeScreen
import com.jullhub.app.ui.screen.LibraryScreen
import com.jullhub.app.ui.screen.SettingsScreen
import com.jullhub.app.ui.viewmodel.EmulatorsViewModel
import com.jullhub.app.ui.viewmodel.HomeViewModel
import com.jullhub.app.ui.viewmodel.LibraryViewModel
import com.jullhub.app.ui.viewmodel.SettingsViewModel

/**
 * Rutas de navegación disponibles en la aplicación.
 */
sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Library : Screen("library")
    object Emulators : Screen("emulators")
    object Settings : Screen("settings")
}

/**
 * Grafo de navegación principal de JullHub.
 */
@Composable
fun NavGraph(
    navController: NavHostController,
    homeViewModel: HomeViewModel,
    libraryViewModel: LibraryViewModel,
    emulatorsViewModel: EmulatorsViewModel,
    settingsViewModel: SettingsViewModel,
    onAddFolderClick: () -> Unit,
    onGameSelected: (String) -> Unit,
    onPlayGame: (String) -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = homeViewModel,
                onGameSelected = onGameSelected,
                onPlayGame = onPlayGame
            )
        }

        composable(Screen.Library.route) {
            LibraryScreen(
                viewModel = libraryViewModel,
                onGameSelected = onGameSelected,
                onAddFolderClick = onAddFolderClick,
                onPlayGame = onPlayGame
            )
        }

        composable(Screen.Emulators.route) {
            EmulatorsScreen(
                viewModel = emulatorsViewModel
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onAddFolderClick = onAddFolderClick,
                onNavigateToFolders = { navController.navigate(Screen.Settings.route) }
            )
        }
    }
}
