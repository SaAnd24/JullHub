package com.jullhub.app.domain.emulator

import android.content.Context
import android.content.pm.PackageManager

/**
 * Clase base abstracta que proporciona funcionalidades comunes
 * para los adaptadores de emuladores.
 */
abstract class BaseEmulatorAdapter : EmulatorAdapter {

    protected var lastError: String? = null

    /**
     * Verifica si un paquete está instalado en el dispositivo.
     */
    protected fun isPackageInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getApplicationInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Obtiene la versión de un paquete instalado.
     */
    protected fun getPackageVersion(context: Context, packageName: String): String? {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(packageName, 0)
            packageInfo.versionName
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    override fun isInstalled(context: Context): Boolean {
        return isPackageInstalled(context, packageName)
    }

    override fun getVersion(context: Context): String? {
        return getPackageVersion(context, packageName)
    }

    override fun getLastError(): String? = lastError

    protected fun setError(message: String) {
        lastError = message
    }

    protected fun clearError() {
        lastError = null
    }
}
