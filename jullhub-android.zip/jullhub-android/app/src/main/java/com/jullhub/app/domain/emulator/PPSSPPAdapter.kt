package com.jullhub.app.domain.emulator

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.jullhub.app.domain.model.Game
import com.jullhub.app.domain.model.Platform

/**
 * Adaptador para PPSSPP - Emulador de PlayStation Portable.
 * 
 * Soporta lanzamiento directo de juegos PSP.
 * Parámetro específico: URI del archivo de juego
 */
class PPSSPPAdapter : BaseEmulatorAdapter() {

    override val emulatorId: String = "ppsspp"
    override val displayName: String = "PPSSPP"
    override val packageName: String = "org.ppsspp.ppsspp"

    override fun isCompatible(game: Game): Boolean {
        return game.platform == Platform.PSP
    }

    override fun buildLaunchIntent(context: Context, game: Game): Intent? {
        if (!isInstalled(context)) {
            setError("PPSSPP no está instalado")
            return null
        }

        if (!isCompatible(game)) {
            setError("PPSSPP no es compatible con ${game.platform.displayName}")
            return null
        }

        if (game.uri.isEmpty()) {
            setError("URI del juego no configurada")
            return null
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(game.uri), "application/x-iso")
                setPackage(packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            clearError()
            intent
        } catch (e: Exception) {
            setError("Error al construir Intent: ${e.message}")
            null
        }
    }

    /**
     * Obtiene información del emulador para debugging.
     */
    fun getEmulatorInfo(context: Context): String {
        val version = getVersion(context) ?: "No instalada"
        return "PPSSPP v$version (${packageName})"
    }
}
