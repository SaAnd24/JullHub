package com.jullhub.app.domain.model

import java.time.LocalDateTime

/**
 * Representa una carpeta de juegos configurada mediante Storage Access Framework (SAF).
 * Almacena el URI persistente del SAF para acceder a la carpeta sin permisos absolutos.
 */
data class GameFolder(
    val id: String = "",
    val name: String = "",
    val contentUri: String = "",
    val addedAt: LocalDateTime = LocalDateTime.now(),
    val isActive: Boolean = true
)
