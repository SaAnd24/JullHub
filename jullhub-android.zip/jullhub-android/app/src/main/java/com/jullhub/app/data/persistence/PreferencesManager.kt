package com.jullhub.app.data.persistence

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

private const val PREFERENCES_NAME = "jullhub_preferences"

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = PREFERENCES_NAME
)

/**
 * Gestor de preferencias usando DataStore.
 * 
 * Responsable de persists:
 * - URIs de carpetas SAF
 * - Preferencias de apariencia
 * - Configuración general
 */
class PreferencesManager(private val context: Context) {

    companion object {
        private val DARK_MODE = booleanPreferencesKey("dark_mode")
        private val GAME_FOLDERS = stringSetPreferencesKey("game_folders")
        private val FOLDER_URIS = stringSetPreferencesKey("folder_uris")
    }

    /**
     * Obtiene el estado del modo oscuro como Flow.
     */
    val darkModeFlow: Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[DARK_MODE] ?: false
        }

    /**
     * Obtiene las URIs de carpetas configuradas.
     */
    val gameFolderUrisFlow: Flow<Set<String>> = context.dataStore.data
        .map { preferences ->
            preferences[FOLDER_URIS] ?: emptySet()
        }

    /**
     * Activa o desactiva el modo oscuro.
     */
    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[DARK_MODE] = enabled
        }
    }

    /**
     * Obtiene el estado actual del modo oscuro.
     */
    suspend fun getDarkMode(): Boolean {
        return context.dataStore.data.map { preferences ->
            preferences[DARK_MODE] ?: false
        }.map { it }.first()
    }

    /**
     * Añade una carpeta SAF con su URI.
     */
    suspend fun addGameFolder(folderUri: String) {
        context.dataStore.edit { preferences ->
            val currentUris = preferences[FOLDER_URIS]?.toMutableSet() ?: mutableSetOf()
            currentUris.add(folderUri)
            preferences[FOLDER_URIS] = currentUris
        }
    }

    /**
     * Elimina una carpeta SAF.
     */
    suspend fun removeGameFolder(folderUri: String) {
        context.dataStore.edit { preferences ->
            val currentUris = preferences[FOLDER_URIS]?.toMutableSet() ?: mutableSetOf()
            currentUris.remove(folderUri)
            preferences[FOLDER_URIS] = currentUris
        }
    }

    /**
     * Obtiene todas las URIs de carpetas configuradas.
     */
    suspend fun getGameFolderUris(): Set<String> {
        return context.dataStore.data.map { preferences ->
            preferences[FOLDER_URIS] ?: emptySet()
        }.first()
    }

    /**
     * Limpia todas las preferencias.
     */
    suspend fun clearAllPreferences() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    // Helper para obtener el primer valor de un Flow
    private suspend fun <T> Flow<T>.first(): T {
        var result: T? = null
        var collected = false
        collect { value ->
            result = value
            collected = true
        }
        return if (collected) result as T else throw NoSuchElementException("No element found")
    }
}
