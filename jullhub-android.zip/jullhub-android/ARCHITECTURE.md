# Arquitectura de JullHub

## Visión General

JullHub implementa una arquitectura **MVVM (Model-View-ViewModel)** con una clara separación de responsabilidades en tres capas principales:

```
┌─────────────────────────────────────┐
│         UI Layer (Compose)          │
│  ┌──────────────────────────────┐   │
│  │ Screens (Home, Library, etc) │   │
│  ├──────────────────────────────┤   │
│  │ ViewModels (State Management)│   │
│  └──────────────────────────────┘   │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      Domain Layer (Business)        │
│  ┌──────────────────────────────┐   │
│  │ Models (Game, GameFolder)    │   │
│  ├──────────────────────────────┤   │
│  │ EmulatorAdapter (Strategy)   │   │
│  ├──────────────────────────────┤   │
│  │ Repositories (Interfaces)    │   │
│  └──────────────────────────────┘   │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      Data Layer (Persistence)       │
│  ┌──────────────────────────────┐   │
│  │ GameRepository (In-Memory)   │   │
│  ├──────────────────────────────┤   │
│  │ PreferencesManager (DataStore)│  │
│  └──────────────────────────────┘   │
└─────────────────────────────────────┘
```

## Capas de la Arquitectura

### 1. UI Layer (Presentación)

#### Responsabilidades
- Mostrar datos al usuario
- Capturar interacciones del usuario
- Mantener estado de UI con ViewModels

#### Componentes

##### Screens
```
HomeScreen.kt          - Inicio: continuar jugando, recientes, favoritos
LibraryScreen.kt       - Biblioteca: búsqueda y filtros
EmulatorsScreen.kt     - Emuladores: estado de instalación
SettingsScreen.kt      - Configuración: carpetas, apariencia
```

##### ViewModels
```
HomeViewModel          - Gestión de estado de inicio
LibraryViewModel       - Gestión de búsqueda y lista
EmulatorsViewModel     - Detección de emuladores
SettingsViewModel      - Preferencias y configuración
```

##### Navigation
```
NavGraph.kt            - Definición de rutas
BottomNavBar.kt        - Navegación inferior
Screen sealed class    - Rutas disponibles
```

##### Theme
```
Theme.kt               - Configuración de tema Material 3
Color.kt               - Paleta de colores
Type.kt                - Tipografía
```

#### Flujo de Datos
```
UI Layer
   ↓
   ├─→ ViewModel.uiState (StateFlow)
   │   ↓
   │   User Interaction
   │   ↓
   │   ViewModel.function()
   │   ↓
   └─→ Domain Layer (Repository)
```

### 2. Domain Layer (Lógica de Negocio)

#### Responsabilidades
- Definir modelos de dominio
- Lógica específica de emuladores (EmulatorAdapter)
- Interfaces de repositorio

#### Componentes

##### Models
```
Game.kt
├─ id: String
├─ title: String
├─ platform: Platform
├─ uri: String (SAF)
├─ fileName: String
├─ fileExtension: String
├─ associatedEmulator: String?
├─ emulatorSpecificId: String?
├─ titleId: String? (PS Vita, etc)
├─ coverArtUri: String?
├─ isFavorite: Boolean
├─ lastPlayedAt: LocalDateTime?
├─ playCount: Int
├─ playTimeMinutes: Long
└─ addedAt: LocalDateTime

Platform (Enum)
├─ PSP, PS_VITA, NDS, N3DS, N64
├─ GBA, GBC, GB
├─ GAMECUBE, WII, DREAMCAST
└─ NES, SNES, MEGA_DRIVE, ARCADE
```

```
GameFolder.kt
├─ id: String
├─ name: String
├─ contentUri: String (SAF URI persistente)
├─ addedAt: LocalDateTime
└─ isActive: Boolean
```

##### EmulatorAdapter Pattern

```
EmulatorAdapter (Interface)
├─ emulatorId: String
├─ displayName: String
├─ packageName: String
├─ isInstalled(Context): Boolean
├─ getVersion(Context): String?
├─ isCompatible(Game): Boolean
├─ buildLaunchIntent(Context, Game): Intent?
└─ launchGame(Context, Game): Boolean

BaseEmulatorAdapter (Abstract Class)
└─ Utilidades comunes (detectar paquete, versión, errores)

PPSSPPAdapter (Implementación Ejemplo)
├─ Para juegos PSP
└─ Construye Intent con URI del juego
```

##### Repositories
```
EmulatorRepository
├─ Mantiene lista de adapters
├─ Detecta emuladores instalados
├─ Encuentra adapter compatible para juego
└─ Extensible para futuros adapters

GameRepository (Interfaz futura)
├─ Gestioanr juegos (Room en fase 2)
├─ Gestionar carpetas
└─ Búsqueda y filtros
```

### 3. Data Layer (Persistencia)

#### Responsabilidades
- Almacenar y recuperar datos
- Gestionar persistencia
- Abstraer fuentes de datos

#### Componentes

##### GameRepository
En Fase 1: **Almacenamiento en memoria** (MutableStateFlow)
En Fase 2: Será reemplazado con **Room Database**

```
Funciones
├─ getAllGames(): List<Game>
├─ getFavoriteGames(): List<Game>
├─ getRecentGames(limit): List<Game>
├─ getRecentlyAddedGames(limit): List<Game>
├─ addGame(Game)
├─ updateGame(Game)
├─ removeGame(gameId)
├─ toggleFavorite(gameId)
├─ searchGames(query): List<Game>
└─ getGamesByPlatform(platformId): List<Game>
```

##### PreferencesManager
Usa **DataStore Preferences** para persistencia segura

```
Funciones
├─ darkModeFlow: Flow<Boolean>
├─ gameFolderUrisFlow: Flow<Set<String>>
├─ setDarkMode(enabled: Boolean)
├─ getDarkMode(): Boolean
├─ addGameFolder(folderUri: String)
├─ removeGameFolder(folderUri: String)
├─ getGameFolderUris(): Set<String>
└─ clearAllPreferences()
```

## Flujo de Datos Principal

### Lanzamiento de Aplicación
```
MainActivity
├─ Inicializa Repositorios
├─ Inicializa ViewModels
├─ Configura Compose con JullHubTheme
└─ Carga NavGraph
```

### Interacción: Buscar Juego
```
1. User tipos en SearchBar (LibraryScreen)
   ↓
2. LibraryViewModel.searchGames(query)
   ↓
3. GameRepository.searchGames(query)
   ↓
4. Actualiza LibraryUiState.displayedGames
   ↓
5. LibraryScreen recompone mostrando resultados
```

### Interacción: Lanzar Juego (Futuro)
```
1. User toca botón Play (GameCard)
   ↓
2. onPlayGame(game)
   ↓
3. MainActivity.onPlayGame() busca adapter
   ↓
4. EmulatorRepository.findAdapterForGame(game)
   ↓
5. Adapter.launchGame(context, game)
   ├─ Construye Intent
   └─ Inicia actividad del emulador
   ↓
6. Juego abierto
```

### Interacción: Agregar Carpeta SAF (Futuro)
```
1. User toca "Añadir carpeta" (SettingsScreen)
   ↓
2. Abre DocumentsContract.ACTION_OPEN_DOCUMENT_TREE
   ↓
3. User selecciona carpeta
   ↓
4. onActivityResult: ResultContracts.OpenDocumentTree
   ↓
5. SettingsViewModel.addGameFolder(uri, name)
   ├─ PreferencesManager.addGameFolder(uri)
   └─ GameRepository.addFolder(GameFolder)
   ↓
6. Carpeta visible en Configuración
   ↓
7. Próximamente: Escáner de ROMs
```

## Patrón EmulatorAdapter

### Por qué existe
Los emuladores Android tienen diferentes métodos de lanzamiento:
- PPSSPP: `Intent.ACTION_VIEW` con URI
- Dolphin: Parámetros específicos en extras
- Vita3K: Requiere Title ID
- RetroArch: Sistema de cores

### Cómo extensionar

1. **Crear nueva clase heredando BaseEmulatorAdapter**
```kotlin
class DolphinAdapter : BaseEmulatorAdapter() {
    override val emulatorId = "dolphin"
    override val packageName = "org.dolphinemu.dolphinemu"
    
    override fun isCompatible(game: Game): Boolean {
        return game.platform in listOf(Platform.GAMECUBE, Platform.WII)
    }
    
    override fun buildLaunchIntent(context: Context, game: Game): Intent? {
        // Lógica específica de Dolphin
    }
}
```

2. **Registrar en EmulatorRepository**
```kotlin
fun init {
    adapters.add(DolphinAdapter())
}
```

3. **¡Listo! No requiere cambios en UI**

## Flujo de Escaneo de ROMs (Futuro - Fase 2)

```
SAF Folders
     ↓
Scanner
├─ Lee URIs persistentes del DataStore
├─ Itera carpetas con DocumentFile
└─ Detecta archivos de juegos
     ↓
Game Detection
├─ Identifica extensión (.iso, .gba, etc)
├─ Mapea a Platform
└─ Intenta detectar Title ID
     ↓
GameRepository
├─ Crea objetos Game
├─ Evita duplicados
└─ Indexa para búsqueda
     ↓
UI Actualiza
└─ Muestra nuevos juegos
```

## Preparación para Room Database (Fase 2)

Actualmente, `GameRepository` usa `MutableStateFlow` en memoria.

Para migrar a Room:
1. Definir entidades Room (@Entity)
2. Crear DAO (Data Access Object)
3. Crear AppDatabase heredando RoomDatabase
4. Reemplazar implementación en GameRepository
5. Cambiar ReturnTypes de suspend functions (Coroutines)

El resto del código **no cambiará** porque la interfaz de repositorio se mantiene igual.

## Testabilidad

### Facilidad de testing por diseño

```
✅ ViewModels probables: No dependen de Context
✅ Domain Layer puro: Lógica sin dependencias Android
✅ Repository pattern: Fácil inyectar mocks
✅ EmulatorAdapter: Fácil crear mocks
```

Ejemplo:
```kotlin
// Crear mock adapter para testing
class MockEmulatorAdapter : EmulatorAdapter {
    override val emulatorId = "mock"
    // ...
}

// Pasar a ViewModel para testing
val testViewModel = LibraryViewModel(mockRepository)
```

## Dependencias Principales

```
androidx.compose.* → UI con Compose
androidx.navigation:navigation-compose → Navegación
androidx.datastore:datastore-preferences → Persistencia
kotlinx.coroutines → Async/await
material3 → Tema Material 3
```

## Mejoras Futuras

- [ ] Inyección de dependencias (Hilt/Koin)
- [ ] Room Database
- [ ] Caché de portadas con Coil/Glide
- [ ] Paging para listas grandes
- [ ] WorkManager para escaneo en background
- [ ] Sincronización con cloud

---

**Versión**: 1.0  
**Última actualización**: Octubre 2024
