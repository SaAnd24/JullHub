# Próxima Fase (Phase 2) - Planificación

## Objetivo de Fase 2

Implementar funcionalidad de **escaneo de ROMs** y **lanzamiento de emuladores** con persistencia real en base de datos.

## Cambios Principales

### 1. Migración a Room Database

#### Cambios necesarios

**Crear archivo**: `app/src/main/java/com/jullhub/app/data/database/AppDatabase.kt`

```kotlin
@Database(entities = [GameEntity::class, GameFolderEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
    abstract fun gameFolderDao(): GameFolderDao
    
    companion object {
        @Volatile
        private var instance: AppDatabase? = null
        
        fun getInstance(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "jullhub.db"
            ).build().also { instance = it }
        }
    }
}
```

**Crear DAOs**:
- `GameDao.kt` - Consultas CRUD para juegos
- `GameFolderDao.kt` - Consultas CRUD para carpetas

**Crear Entities**:
- `GameEntity.kt` - Mapeo de `Game` para Room
- `GameFolderEntity.kt` - Mapeo de `GameFolder` para Room

#### Actualizar GameRepository

```kotlin
class GameRepository(private val gameDao: GameDao) {
    
    val games: Flow<List<Game>> = gameDao.getAllGames()
        .map { entities -> entities.map { it.toDomain() } }
    
    suspend fun addGame(game: Game) {
        gameDao.insert(game.toEntity())
    }
    
    suspend fun updateGame(game: Game) {
        gameDao.update(game.toEntity())
    }
    
    // ... resto de funciones
}
```

### 2. Implementar Storage Access Framework (SAF)

#### Cambios necesarios

**Crear archivo**: `app/src/main/java/com/jullhub/app/domain/saf/SAFManager.kt`

```kotlin
class SAFManager(private val context: Context) {
    
    fun getGameFoldersUris(preferencesManager: PreferencesManager): Set<DocumentFile> {
        val uris = preferencesManager.getGameFolderUris()
        return uris.mapNotNull { uri ->
            DocumentFile.fromTreeUri(context, Uri.parse(uri))
        }.toSet()
    }
    
    fun listGameFiles(folderUri: String, extensions: Set<String>): List<DocumentFile> {
        val folder = DocumentFile.fromTreeUri(context, Uri.parse(folderUri))
        return folder?.listFiles()?.filter { file ->
            file.isFile && file.name?.substringAfterLast(".")?.lowercase() in extensions
        } ?: emptyList()
    }
}
```

### 3. Implementar Escáner de ROMs

#### Crear archivo: `app/src/main/java/com/jullhub/app/domain/scanner/RomScanner.kt`

```kotlin
class RomScanner(
    private val safManager: SAFManager,
    private val gameRepository: GameRepository,
    private val preferencesManager: PreferencesManager
) {
    
    suspend fun scanForGames(): List<Game> = withContext(Dispatchers.IO) {
        val gameExtensions = mapOf(
            ".iso" to Platform.PSP,
            ".cso" to Platform.PSP,
            ".nds" to Platform.NDS,
            ".gba" to Platform.GBA,
            // ... más extensiones
        )
        
        val scannedGames = mutableListOf<Game>()
        
        val folders = safManager.getGameFoldersUris(preferencesManager)
        for (folder in folders) {
            val files = safManager.listGameFiles(folder.uri.toString(), gameExtensions.keys)
            
            for (file in files) {
                val ext = file.name?.substringAfterLast(".") ?: continue
                val platform = gameExtensions[".${ext.lowercase()}"] ?: continue
                
                val game = Game(
                    id = UUID.randomUUID().toString(),
                    title = file.name?.substringBeforeLast(".") ?: "Desconocido",
                    platform = platform,
                    uri = file.uri.toString(),
                    fileName = file.name ?: "",
                    fileExtension = ext,
                    addedAt = LocalDateTime.now()
                )
                
                scannedGames.add(game)
            }
        }
        
        // Guardar en BD
        scannedGames.forEach { gameRepository.addGame(it) }
        return@withContext scannedGames
    }
}
```

### 4. ViewModel para Escaneo

**Crear archivo**: `app/src/main/java/com/jullhub/app/ui/viewmodel/ScannerViewModel.kt`

```kotlin
class ScannerViewModel(
    private val romScanner: RomScanner
) : ViewModel() {
    
    private val _scanState = MutableStateFlow(ScanUiState())
    val scanState: StateFlow<ScanUiState> = _scanState.asStateFlow()
    
    fun startScan() {
        viewModelScope.launch {
            _scanState.value = _scanState.value.copy(isScanning = true)
            try {
                val games = romScanner.scanForGames()
                _scanState.value = _scanState.value.copy(
                    isScanning = false,
                    scannedCount = games.size,
                    success = true
                )
            } catch (e: Exception) {
                _scanState.value = _scanState.value.copy(
                    isScanning = false,
                    error = e.message
                )
            }
        }
    }
}
```

### 5. Implementar Lanzamiento de Juegos

#### Actualizar MainActivity

```kotlin
override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    
    // ... código existente ...
    
    setContent {
        JullHubApp(
            // ...
            onPlayGame = { game ->
                viewModel.launchGame(this@MainActivity, game)
            }
        )
    }
}

private fun launchGame(context: Context, game: Game) {
    val adapter = emulatorRepository.findAdapterForGame(context, game)
    if (adapter != null && adapter.launchGame(context, game)) {
        // Actualizar estadísticas
        game.playCount++
        game.lastPlayedAt = LocalDateTime.now()
        gameRepository.updateGame(game)
    } else {
        // Mostrar error
        showError("No se pudo lanzar el juego")
    }
}
```

## Nuevos Emuladores a Agregar

### Prioridad 1 (Fase 2)
- **DuckStation** (PS1)
- **NetherSX2** (PS1)
- **melonDS** (NDS)

### Prioridad 2 (Fase 3)
- **Dolphin** (GameCube, Wii)
- **Vita3K** (PS Vita)
- **M64Plus FZ** (N64)

### Prioridad 3 (Fase 4)
- **RetroArch** (Multi-plataforma)
- **Otros**

### Patrón para agregar

```kotlin
// Ejemplo: DuckStation
class DuckStationAdapter : BaseEmulatorAdapter() {
    override val emulatorId = "duckstation"
    override val displayName = "DuckStation"
    override val packageName = "com.github.stenzek.duckstation"
    
    override fun isCompatible(game: Game) = game.platform == Platform.PS1
    
    override fun buildLaunchIntent(context: Context, game: Game): Intent? {
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(game.uri), "application/x-cso")
            setPackage(packageName)
        }
    }
}
```

## Mejoras de UI para Fase 2

### Nuevas pantallas
- **Detalle de Juego**: Portada, plataforma, emulador, estadísticas
- **Pantalla de Escaneo**: Progreso de escaneo en tiempo real
- **Juego Lanzado**: Confirmación de lanzamiento

### Actualizaciones de pantallas existentes
- **Home**: Mostrar últimos jugados con tiempos
- **Biblioteca**: Filtro por plataforma mejorado
- **Emuladores**: Mostrar versión instalada

## Tareas Detalladas

### Sprint 1: Base de Datos
- [ ] Crear `AppDatabase.kt`
- [ ] Crear entities (Game, GameFolder)
- [ ] Crear DAOs
- [ ] Actualizar `GameRepository`
- [ ] Migrar datos en memoria a Room

### Sprint 2: SAF y Escaneo
- [ ] Implementar `SAFManager.kt`
- [ ] Implementar `RomScanner.kt`
- [ ] Crear pantalla de escaneo
- [ ] Actualizar `SettingsViewModel` con escaneo

### Sprint 3: Lanzamiento
- [ ] Implementar `launchGame()` en MainActivity
- [ ] Agregar DuckStation adapter
- [ ] Actualizar estadísticas de juego
- [ ] Pantalla de confirmación

### Sprint 4: Polish
- [ ] Agregar más adapters
- [ ] Descargar portadas
- [ ] Mejorar filtros
- [ ] Testing

## Dependencias Adicionales (build.gradle.kts)

```kotlin
// Room Database
implementation("androidx.room:room-runtime:2.6.1")
kapt("androidx.room:room-compiler:2.6.1")
implementation("androidx.room:room-ktx:2.6.1")

// WorkManager para escaneo en background
implementation("androidx.work:work-runtime-ktx:2.8.1")

// Coil para descargar portadas
implementation("io.coil-kt:coil-compose:2.5.0")

// Hilt para inyección de dependencias
implementation("com.google.dagger:hilt-android:2.48")
kapt("com.google.dagger:hilt-compiler:2.48")
```

## Cómo continuar desde aquí

1. **Revisa** `ARCHITECTURE.md` para entender estructura
2. **Ejecuta** la app actual en emulador
3. **Familiarízate** con Compose y MVVM
4. **Comienza** por migrar a Room (más fácil)
5. **Luego** agrega SAF y escaneo

## Checklist de Compilación Fase 2

- [ ] Compila sin errores
- [ ] Compila sin warnings críticos
- [ ] APK se genera correctamente
- [ ] Se instala en emulador/dispositivo
- [ ] Navegación funciona
- [ ] Base de datos crea tablas
- [ ] Escaneo detecta algunos juegos
- [ ] Al menos 2 adapters funcionan

---

**Estimación de tiempo**: Fase 2 ~ 4-6 semanas

**Próxima revisión**: Octubre 2024
