package com.jullhub.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.data.scanner.ScanState
import com.jullhub.app.data.settings.AppOrientation
import com.jullhub.app.data.settings.LibraryNavigation
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.layout.fillMaxWidth
import com.jullhub.app.data.settings.ThemeMode
import com.jullhub.app.ui.library.CollectFolderMessages
import com.jullhub.app.ui.library.FoldersViewModel
import com.jullhub.app.ui.library.ScanViewModel
import com.jullhub.app.ui.library.statusText
import com.jullhub.app.ui.library.rememberFolderPicker

@Composable
fun SettingsScreen(
    factory: ViewModelProvider.Factory,
    snackbarHostState: SnackbarHostState,
    vm: SettingsViewModel = viewModel(factory = factory),
    foldersVm: FoldersViewModel = viewModel(factory = factory),
    scanVm: ScanViewModel = viewModel(factory = factory)
) {
    val themeMode by vm.themeMode.collectAsStateWithLifecycle()
    val navigation by vm.libraryNavigation.collectAsStateWithLifecycle()
    val orientation by vm.orientation.collectAsStateWithLifecycle()
    val savedKey by vm.metadataApiKey.collectAsStateWithLifecycle()
    val folders by foldersVm.folders.collectAsStateWithLifecycle()
    val scanState by scanVm.state.collectAsStateWithLifecycle()
    val pickFolder = rememberFolderPicker { foldersVm.addFolder(it) }
    CollectFolderMessages(foldersVm, snackbarHostState)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Text(
                text = "Ajustes",
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        // Carpetas
        item { SectionTitle("Carpetas") }
        items(folders, key = { it.uri }) { folder ->
            ListItem(
                headlineContent = { Text(folder.name) },
                supportingContent = {
                    Text(
                        if (folder.hasAccess) "Acceso concedido"
                        else "Sin acceso. Elimina la carpeta y vuelve a añadirla"
                    )
                },
                leadingContent = {
                    Icon(
                        imageVector = if (folder.hasAccess) Icons.Rounded.Folder else Icons.Rounded.Warning,
                        contentDescription = null
                    )
                },
                trailingContent = {
                    IconButton(onClick = { foldersVm.removeFolder(folder.uri) }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Eliminar carpeta ${folder.name}")
                    }
                }
            )
        }
        item {
            ListItem(
                headlineContent = { Text("Añadir carpeta de juegos") },
                supportingContent = {
                    Text(
                        if (folders.isEmpty()) "Todavía no hay carpetas configuradas"
                        else "Elige otra carpeta con juegos"
                    )
                },
                leadingContent = { Icon(Icons.Rounded.Add, contentDescription = null) },
                modifier = Modifier.clickable(onClick = pickFolder)
            )
        }

        // Biblioteca
        item { SectionTitle("Biblioteca") }
        item {
            ListItem(
                headlineContent = { Text("Escanear biblioteca") },
                supportingContent = {
                    Text(
                        scanState.statusText()
                            ?: if (folders.isEmpty()) "Añade una carpeta primero"
                            else "Busca juegos nuevos en tus carpetas"
                    )
                },
                leadingContent = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                modifier = Modifier.clickable(
                    enabled = folders.isNotEmpty() && scanState != ScanState.Scanning,
                    onClick = scanVm::scan
                )
            )
        }

        item {
            ListItem(
                headlineContent = { Text("Navegación entre consolas") },
                supportingContent = { Text("Cómo cambias de consola en la Biblioteca") }
            )
        }
        items(LibraryNavigation.entries, key = { "nav_${it.name}" }) { option ->
            ListItem(
                headlineContent = { Text(option.label()) },
                leadingContent = { RadioButton(selected = navigation == option, onClick = null) },
                modifier = Modifier.selectable(
                    selected = navigation == option,
                    role = Role.RadioButton,
                    onClick = { vm.setLibraryNavigation(option) }
                )
            )
        }

        // Orientación
        item { SectionTitle("Orientación") }
        items(AppOrientation.entries, key = { "orient_${it.name}" }) { option ->
            ListItem(
                headlineContent = { Text(option.label()) },
                leadingContent = { RadioButton(selected = orientation == option, onClick = null) },
                modifier = Modifier.selectable(
                    selected = orientation == option,
                    role = Role.RadioButton,
                    onClick = { vm.setOrientation(option) }
                )
            )
        }

        // Metadata
        item { SectionTitle("Portadas e información") }
        item { MetadataSection(savedKey = savedKey, onSave = vm::saveMetadataApiKey) }

        // Emuladores
        item { SectionTitle("Emuladores") }
        item {
            ListItem(
                headlineContent = { Text("Asociación de emuladores") },
                supportingContent = { Text("Disponible próximamente") }
            )
        }

        // Apariencia
        item { SectionTitle("Apariencia") }
        items(ThemeMode.entries, key = { it.name }) { mode ->
            ListItem(
                headlineContent = { Text(mode.label()) },
                leadingContent = { RadioButton(selected = themeMode == mode, onClick = null) },
                modifier = Modifier.selectable(
                    selected = themeMode == mode,
                    role = Role.RadioButton,
                    onClick = { vm.setThemeMode(mode) }
                )
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun MetadataSection(savedKey: String, onSave: (String) -> Unit) {
    var draft by remember(savedKey) { mutableStateOf(savedKey) }
    val uri = LocalUriHandler.current
    Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "JullHub puede descargar portadas y descripciones de RAWG. Es opcional: sin clave o sin " +
                "conexión todo funciona con los datos locales. Se guarda en este dispositivo.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            label = { Text("Clave de API de RAWG") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onSave(draft) }, enabled = draft.trim() != savedKey) { Text("Guardar") }
            TextButton(onClick = { uri.openUri("https://rawg.io/apidocs") }) { Text("Conseguir una clave") }
        }
        TextButton(onClick = { uri.openUri("https://rawg.io") }) { Text("Datos e imágenes: RAWG") }
    }
}

private fun AppOrientation.label(): String = when (this) {
    AppOrientation.AUTO -> "Automática (sigue al dispositivo)"
    AppOrientation.PORTRAIT -> "Vertical"
    AppOrientation.LANDSCAPE -> "Horizontal"
}

private fun LibraryNavigation.label(): String = when (this) {
    LibraryNavigation.HORIZONTAL -> "Horizontal (deslizar izquierda/derecha)"
    LibraryNavigation.VERTICAL -> "Vertical (deslizar arriba/abajo)"
}

private fun ThemeMode.label(): String = when (this) {
    ThemeMode.SYSTEM -> "Seguir el sistema"
    ThemeMode.DARK -> "Oscuro"
    ThemeMode.LIGHT -> "Claro"
}
