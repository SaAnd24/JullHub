package com.jullhub.app.data.folders

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.documentfile.provider.DocumentFile
import com.jullhub.app.core.model.GameFolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

sealed interface AddFolderResult {
    data object Added : AddFolderResult
    data object AlreadyExists : AddFolderResult
    data object PermissionFailed : AddFolderResult
}

interface FolderRepository {
    val folders: Flow<List<GameFolder>>
    suspend fun addFolder(uri: Uri): AddFolderResult
    suspend fun removeFolder(uri: String)
}

/** Guarda las URIs `content://` de las carpetas en DataStore y mantiene sus permisos SAF. */
class DataStoreFolderRepository(
    private val context: Context,
    private val dataStore: DataStore<Preferences>,
    private val permissions: SafPermissions
) : FolderRepository {

    private val foldersKey = stringSetPreferencesKey("game_folder_uris")

    override val folders: Flow<List<GameFolder>> = dataStore.data
        .map { prefs -> (prefs[foldersKey] ?: emptySet()).map { toFolder(it) } }
        .map { list -> list.sortedBy { it.name.lowercase() } }
        .flowOn(Dispatchers.IO)

    override suspend fun addFolder(uri: Uri): AddFolderResult {
        val value = uri.toString()
        val current = dataStore.data.first()[foldersKey] ?: emptySet()
        if (value in current) return AddFolderResult.AlreadyExists
        if (!permissions.takeRead(uri)) return AddFolderResult.PermissionFailed
        dataStore.edit { prefs -> prefs[foldersKey] = (prefs[foldersKey] ?: emptySet()) + value }
        return AddFolderResult.Added
    }

    override suspend fun removeFolder(uri: String) {
        dataStore.edit { prefs -> prefs[foldersKey] = (prefs[foldersKey] ?: emptySet()) - uri }
        permissions.release(Uri.parse(uri))
    }

    private fun toFolder(value: String): GameFolder {
        val uri = Uri.parse(value)
        val name = runCatching { DocumentFile.fromTreeUri(context, uri)?.name }.getOrNull()
            ?: uri.lastPathSegment
            ?: value
        return GameFolder(uri = value, name = name, hasAccess = permissions.hasReadAccess(uri))
    }
}
