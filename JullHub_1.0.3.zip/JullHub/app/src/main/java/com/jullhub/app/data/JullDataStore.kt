package com.jullhub.app.data

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

/** Única instancia de DataStore de la app (carpetas y ajustes). */
val Context.jullDataStore by preferencesDataStore(name = "jullhub_prefs")
