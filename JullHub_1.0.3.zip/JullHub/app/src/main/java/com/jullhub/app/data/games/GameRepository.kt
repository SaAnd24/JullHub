package com.jullhub.app.data.games

import androidx.room.withTransaction
import com.jullhub.app.core.model.Game
import com.jullhub.app.data.db.GameDao
import com.jullhub.app.data.db.JullDatabase
import com.jullhub.app.data.db.toEntity
import com.jullhub.app.data.db.toGame
import com.jullhub.app.data.scanner.FolderScan
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Fuente de verdad de la biblioteca. La UI solo observa [observeGames]. */
interface GameRepository {
    fun observeGames(): Flow<List<Game>>

    /**
     * Aplica el resultado de un escaneo a la base de datos:
     * inserta los nuevos, actualiza los existentes (conservando favorito y demás datos de usuario)
     * y elimina los que ya no están en carpetas leídas por completo.
     * Los juegos de carpetas inaccesibles o leídas en parte no se eliminan.
     *
     * @param configuredFolderUris carpetas actualmente configuradas; lo que no pertenezca a ellas se descarta.
     */
    suspend fun syncScan(scans: List<FolderScan>, configuredFolderUris: Set<String>)

    /** Quita de la biblioteca los juegos de una carpeta SAF. Solo toca Room, nunca archivos. */
    suspend fun removeByFolder(folderUri: String)

    suspend fun setFavorite(gameId: String, favorite: Boolean)

    /** Tras un lanzamiento aceptado: actualiza `lastPlayedAt` y suma una ejecución. */
    suspend fun markPlayed(gameId: String, at: Long = System.currentTimeMillis())
}

/** Implementación respaldada por Room. */
class RoomGameRepository(
    private val database: JullDatabase,
    private val dao: GameDao = database.gameDao()
) : GameRepository {

    override fun observeGames(): Flow<List<Game>> =
        dao.observeAll().map { rows -> rows.map { it.toGame() } }

    override suspend fun syncScan(scans: List<FolderScan>, configuredFolderUris: Set<String>) {
        database.withTransaction {
            // Juegos de carpetas que ya no existen en la configuración (p. ej. quitadas durante el escaneo).
            dao.deleteOutsideFolders(configuredFolderUris.toList())

            for (scan in scans) {
                if (scan.folderUri !in configuredFolderUris) continue
                val existing = dao.getByFolder(scan.folderUri).associateBy { it.id }

                if (scan.complete) {
                    val found = scan.games.map { it.id }.toSet()
                    // SQLite limita las variables por consulta: se borra por lotes.
                    (existing.keys - found).chunked(DELETE_BATCH).forEach { dao.deleteByIds(it) }
                }

                val changed = scan.games.mapNotNull { game ->
                    val fresh = game.toEntity(scan.folderUri)
                    val old = existing[fresh.id]
                    // Los datos del archivo se refrescan; favorito y demás datos de usuario se conservan.
                    val merged = old?.copy(
                        title = fresh.title,
                        platform = fresh.platform,
                        uri = fresh.uri,
                        fileName = fresh.fileName,
                        extension = fresh.extension,
                        folderUri = fresh.folderUri
                    ) ?: fresh
                    merged.takeIf { it != old }
                }
                if (changed.isNotEmpty()) dao.upsertAll(changed)
            }
        }
    }

    override suspend fun removeByFolder(folderUri: String) = dao.deleteByFolder(folderUri)

    override suspend fun setFavorite(gameId: String, favorite: Boolean) = dao.setFavorite(gameId, favorite)

    override suspend fun markPlayed(gameId: String, at: Long) = dao.markPlayed(gameId, at)

    private companion object {
        const val DELETE_BATCH = 500
    }
}
