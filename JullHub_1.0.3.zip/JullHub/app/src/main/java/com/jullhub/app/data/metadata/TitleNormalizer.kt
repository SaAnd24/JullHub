package com.jullhub.app.data.metadata

import java.text.Normalizer

/**
 * Normalización de nombres de archivo para buscar y comparar títulos.
 * `Persona 5 Royal (USA).iso` -> búsqueda "Persona 5 Royal", clave "persona 5 royal".
 */
object TitleNormalizer {
    private val BRACKETS = Regex("""\s*[\(\[][^\)\]]*[\)\]]""")
    private val EXTENSION = Regex("""\.(iso|bin|cue|chd|cso|pbp|gcm|rvz|wbfs|nds|3ds|3dsx|cia|gb|gbc|gba|nes|sfc|smc|n64|z64|v64|vpk|cdi|gdi|zip|7z)$""", RegexOption.IGNORE_CASE)
    private val TRAILING_ARTICLE = Regex("""^(.*),\s*(the|a|an)$""", RegexOption.IGNORE_CASE)
    private val NON_ALNUM = Regex("""[^a-z0-9]+""")
    private val ACCENTS = Regex("""\p{InCombiningDiacriticalMarks}+""")

    /** Texto legible para enviar al proveedor. */
    fun searchQuery(raw: String): String {
        var s = raw.trim().replace(EXTENSION, "")
        s = s.replace(BRACKETS, " ").replace('_', ' ').replace(Regex("""\s+"""), " ").trim()
        TRAILING_ARTICLE.matchEntire(s)?.let { s = "${it.groupValues[2]} ${it.groupValues[1]}".trim() }
        return s
    }

    /** Clave de comparación: minúsculas, sin acentos, sin símbolos, "&" = "and" y sin artículo inicial. */
    fun key(raw: String): String {
        var s = searchQuery(raw).lowercase()
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replace(ACCENTS, "")
        s = s.replace("&", " and ").replace("'", "")
        s = s.replace(NON_ALNUM, " ").trim()
        s = s.removePrefix("the ").trim()
        return s
    }
}
