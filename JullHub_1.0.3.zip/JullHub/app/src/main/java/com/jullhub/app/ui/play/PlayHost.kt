package com.jullhub.app.ui.play

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.jullhub.app.core.model.Game

/**
 * Conecta una pantalla con [PlayViewModel]: muestra avisos en el Snackbar y el selector
 * "Abrir con" cuando hay varios emuladores válidos. Devuelve la acción "Jugar" para las tarjetas.
 */
@Composable
fun rememberPlayAction(playVm: PlayViewModel, snackbarHostState: SnackbarHostState): (Game) -> Unit {
    var chooser by remember { mutableStateOf<PlayEvent.ChooseEmulator?>(null) }

    LaunchedEffect(playVm) {
        playVm.events.collect { event ->
            when (event) {
                is PlayEvent.Message -> snackbarHostState.showSnackbar(event.text)
                is PlayEvent.ChooseEmulator -> chooser = event
            }
        }
    }

    chooser?.let { pending ->
        AlertDialog(
            onDismissRequest = { chooser = null },
            title = { Text("Abrir con") },
            text = {
                Column {
                    pending.options.forEach { option ->
                        TextButton(onClick = {
                            chooser = null
                            playVm.onPlay(pending.game, option.id)
                        }) { Text(option.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { chooser = null }) { Text("Cancelar") } }
        )
    }

    return remember(playVm) { { game: Game -> playVm.onPlay(game) } }
}
