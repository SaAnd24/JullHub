package com.jullhub.app.data.scanner

import com.jullhub.app.core.model.Platform

/**
 * Determina la plataforma de un archivo. Orden de decisión:
 * 1. Contexto de carpetas, de la más cercana al archivo a la raíz (`/PSP/Juego.iso` -> PSP).
 *    Solo vale si la plataforma de la carpeta es compatible con la extensión.
 * 2. Si la extensión pertenece a una única plataforma (`.nds`, `.vpk`...), esa.
 * 3. En cualquier otro caso (p. ej. `.iso` sin contexto) -> [Platform.UNKNOWN].
 *
 * Para reconocer más nombres de carpeta basta con ampliar [DEFAULT_ALIASES]
 * (en minúsculas, sin espacios ni símbolos).
 */
class PlatformDetector(
    private val filter: GameFileFilter,
    aliases: Map<Platform, List<String>> = DEFAULT_ALIASES
) {
    private val aliasToPlatform: Map<String, Platform> =
        aliases.flatMap { (platform, names) -> names.map { it to platform } }.toMap()

    /**
     * @param folderPath nombres de carpeta desde la raíz elegida hasta la carpeta contenedora.
     */
    fun detect(folderPath: List<String>, extension: String): Platform {
        val candidates = filter.platformsFor(extension)
        if (candidates.isEmpty()) return Platform.UNKNOWN
        for (folder in folderPath.asReversed()) {
            val platform = platformFromFolderName(folder) ?: continue
            if (platform in candidates) return platform
        }
        return candidates.singleOrNull() ?: Platform.UNKNOWN
    }

    /** Busca alias en el nombre probando combinaciones de hasta 3 palabras, las más largas primero. */
    internal fun platformFromFolderName(name: String): Platform? {
        val tokens = name.lowercase().split(NON_ALPHANUMERIC).filter { it.isNotEmpty() }
        for (size in minOf(3, tokens.size) downTo 1) {
            for (start in 0..tokens.size - size) {
                val key = tokens.subList(start, start + size).joinToString("")
                aliasToPlatform[key]?.let { return it }
            }
        }
        return null
    }

    companion object {
        private val NON_ALPHANUMERIC = Regex("[^a-z0-9]+")

        val DEFAULT_ALIASES: Map<Platform, List<String>> = mapOf(
            Platform.PS1 to listOf("ps1", "psx", "psone", "playstation", "playstation1", "sonyplaystation"),
            Platform.PS2 to listOf("ps2", "playstation2", "sonyplaystation2"),
            Platform.PSP to listOf("psp", "playstationportable"),
            Platform.PS_VITA to listOf("psvita", "vita", "playstationvita", "vita3k"),
            Platform.NDS to listOf("ds", "nds", "nintendods"),
            Platform.N3DS to listOf("3ds", "n3ds", "nintendo3ds"),
            Platform.GBA to listOf("gba", "gameboyadvance"),
            Platform.GB_GBC to listOf("gb", "gbc", "gameboy", "gameboycolor"),
            Platform.N64 to listOf("n64", "nintendo64"),
            Platform.GAMECUBE to listOf("gc", "ngc", "gcn", "gamecube", "nintendogamecube"),
            Platform.WII to listOf("wii", "nintendowii"),
            Platform.DREAMCAST to listOf("dc", "dreamcast", "segadreamcast"),
            Platform.NES to listOf("nes", "famicom", "nintendoentertainmentsystem"),
            Platform.SNES to listOf("snes", "supernintendo", "superfamicom", "supernes"),
            Platform.MEGA_DRIVE to listOf("megadrive", "genesis", "md", "segagenesis", "segamegadrive")
        )
    }
}
