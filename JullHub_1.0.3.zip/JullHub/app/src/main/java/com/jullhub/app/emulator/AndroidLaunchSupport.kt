package com.jullhub.app.emulator

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/*
 * Únicas piezas del sistema de lanzamiento que tocan clases de Android.
 */

/** Detecta paquetes con PackageManager (requiere los `<queries>` del manifest). */
object AndroidPackageResolver : PackageResolver {
    override fun firstInstalled(context: Context, packages: List<String>): String? =
        packages.firstOrNull { pkg ->
            try {
                context.packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: PackageManager.NameNotFoundException) {
                false
            }
        }
}

/** Comprueba por SAF que el documento del juego sigue existiendo y se puede consultar. */
object SafGameAccess : GameAccess {
    override fun isReadable(context: Context, uri: String): Boolean = try {
        DocumentFile.fromSingleUri(context, Uri.parse(uri))?.exists() == true
    } catch (_: Exception) {
        false
    }
}

/** Ejecuta un [LaunchRequest]. Debe llamarse desde el hilo principal. */
fun interface LaunchExecutor {
    fun execute(context: Context, request: LaunchRequest): LaunchResult
}

/** Convierte un [LaunchRequest] en un Intent explícito y lo lanza. Nunca propaga excepciones. */
class IntentLaunchExecutor : LaunchExecutor {

    override fun execute(context: Context, request: LaunchRequest): LaunchResult = try {
        val intent = Intent().apply {
            setClassName(request.packageName, request.className)
            request.action?.let { action = it }
            request.dataUri?.let { data = Uri.parse(it) }
            request.stringExtras.forEach { (key, value) -> putExtra(key, value) }
            request.stringArrayExtras.forEach { (key, value) -> putExtra(key, value.toTypedArray()) }

            // Los extras no concedían acceso por sí solos: se añade un ClipData con las URIs
            // para que Android otorgue lectura al emulador sobre los documentos SAF.
            val grants = request.grantReadUris.map { Uri.parse(it) }
            if (grants.isNotEmpty()) {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val clip = ClipData.newRawUri("game", grants.first())
                grants.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                clipData = clip
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        LaunchResult.Started
    } catch (_: ActivityNotFoundException) {
        LaunchResult.Failed("Este emulador no acepta el lanzamiento desde JullHub. Puede que su versión sea distinta.")
    } catch (_: SecurityException) {
        LaunchResult.Failed("Android rechazó el acceso al juego. Vuelve a añadir la carpeta de juegos.")
    } catch (_: Exception) {
        LaunchResult.Failed()
    }
}
