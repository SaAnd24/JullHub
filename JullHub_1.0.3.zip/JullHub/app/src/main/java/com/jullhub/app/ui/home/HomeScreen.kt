package com.jullhub.app.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.Platform
import com.jullhub.app.core.util.RelativeTime
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import com.jullhub.app.ui.components.ChamferShape
import com.jullhub.app.ui.components.LocalConsoleAccent
import com.jullhub.app.ui.components.accentColor
import com.jullhub.app.ui.components.drawCornerBrackets
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.PlatformArt
import com.jullhub.app.ui.components.PlatformCard
import com.jullhub.app.ui.components.PlatformChip
import com.jullhub.app.ui.components.RemoteImage
import com.jullhub.app.ui.components.SectionHeader
import com.jullhub.app.ui.components.consoleSelectable
import com.jullhub.app.ui.play.PlayViewModel
import com.jullhub.app.ui.play.rememberPlayAction
import com.jullhub.app.ui.theme.JullMotion
import com.jullhub.app.ui.theme.JullRadius
import com.jullhub.app.ui.theme.JullSpacing
import com.jullhub.app.ui.theme.WindowInfo
import com.jullhub.app.ui.theme.rememberWindowInfo

@Composable
fun HomeScreen(
    factory: ViewModelProvider.Factory,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit,
    snackbarHostState: SnackbarHostState,
    vm: HomeViewModel = viewModel(factory = factory),
    playVm: PlayViewModel = viewModel(factory = factory)
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val play = rememberPlayAction(playVm, snackbarHostState)
    val window = rememberWindowInfo()

    // Juego elegido en el estante (por defecto el Hero). Si deja de existir, se vuelve al Hero.
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selected = state.shelf.firstOrNull { it.id == selectedId } ?: state.hero?.entry

    // El fondo de la app se tiñe con el color de la consola del juego elegido.
    val accent = LocalConsoleAccent.current
    LaunchedEffect(selected?.game?.platform) {
        accent.color = selected?.game?.platform?.accentColor() ?: androidx.compose.ui.graphics.Color.Unspecified
    }
    DisposableEffect(Unit) { onDispose { accent.color = androidx.compose.ui.graphics.Color.Unspecified } }

    Column(Modifier.fillMaxSize()) {
        ConsoleStatusBar(gameCount = state.totalCount, modifier = Modifier.padding(horizontal = window.contentPadding))
        Box(Modifier.weight(1f)) {
            when {
                state.isLoading -> Box(Modifier.fillMaxSize())
                !state.hasGames -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        icon = Icons.Rounded.VideoLibrary,
                        title = "Tu consola está vacía",
                        body = "Añade la carpeta donde guardas tus juegos. JullHub no los copia ni los mueve.",
                        actionLabel = "Añadir carpeta de juegos",
                        onAction = onOpenLibrary
                    )
                }
                else -> {
                    val stage = selected?.let { StageData(it, HomeContent.badgeFor(it, state.hero)) }
                    if (window.isLandscape) LandscapeHome(state, stage, selected?.id, { selectedId = it.id }, window, play, onOpenLibrary, onOpenGame, onOpenPlatform)
                    else PortraitHome(state, stage, selected?.id, { selectedId = it.id }, window, play, onOpenLibrary, onOpenGame, onOpenPlatform)
                }
            }
        }
    }
}

private data class StageData(val entry: GameEntry, val badge: String)

/** Barra superior estilo consola: marca, hora y número de juegos, con una línea de acento dibujada en Canvas. */
@Composable
private fun ConsoleStatusBar(gameCount: Int, modifier: Modifier = Modifier) {
    val time by produceState(initialValue = clockText()) {
        while (true) { value = clockText(); delay(20_000) }
    }
    val accent = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier.fillMaxWidth().padding(top = JullSpacing.sm)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "JULLHUB",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = if (gameCount == 1) "1 juego" else "$gameCount juegos",
                style = MaterialTheme.typography.labelLarge,
                color = muted
            )
            Spacer(Modifier.width(JullSpacing.lg))
            Text(time, style = MaterialTheme.typography.titleMedium)
        }
        Canvas(Modifier.fillMaxWidth().height(8.dp).padding(top = 4.dp)) {
            val y = 2f
            val notch = 22f
            val path = Path().apply {
                moveTo(0f, y); lineTo(size.width * 0.18f, y); lineTo(size.width * 0.18f + notch, y + 4f)
                lineTo(size.width, y + 4f)
            }
            drawPath(path, accent.copy(alpha = 0.7f), style = Stroke(width = 2f))
            drawLine(muted.copy(alpha = 0.25f), Offset(0f, y + 4f), Offset(size.width * 0.18f, y + 4f), 1f)
        }
    }
}

private fun clockText(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))

@Composable
private fun PortraitHome(
    state: HomeUiState,
    stage: StageData?,
    selectedId: String?,
    onSelect: (GameEntry) -> Unit,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = JullSpacing.xl),
        verticalArrangement = Arrangement.spacedBy(JullSpacing.xl)
    ) {
        stage?.let { st ->
            item(key = "stage") {
                GameStage(
                    stage = st,
                    onPlay = { onPlay(st.entry.game) },
                    onDetails = { onOpenGame(st.entry) },
                    modifier = Modifier
                        .padding(horizontal = window.contentPadding)
                        .padding(top = JullSpacing.sm)
                        .fillMaxWidth()
                        .height(340.dp)
                )
            }
        }
        if (state.shelf.size > 1) {
            item(key = "shelf") { ShelfRow(state.shelf, selectedId, onSelect, window.contentPadding) }
        }
        homeSections(state, window, onPlay, onOpenLibrary, onOpenGame, onOpenPlatform)
    }
}

@Composable
private fun LandscapeHome(
    state: HomeUiState,
    stage: StageData?,
    selectedId: String?,
    onSelect: (GameEntry) -> Unit,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit
) {
    // Dashboard: escenario ancho a la izquierda (con el estante debajo), estantes a la derecha.
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = window.contentPadding, vertical = JullSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(JullSpacing.xl)
    ) {
        Column(Modifier.weight(0.9f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
            stage?.let { st ->
                GameStage(
                    stage = st,
                    onPlay = { onPlay(st.entry.game) },
                    onDetails = { onOpenGame(st.entry) },
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    wide = true
                )
            }
            if (state.shelf.size > 1) ShelfRow(state.shelf, selectedId, onSelect, 0.dp, tileWidth = 64.dp)
        }
        LazyColumn(
            modifier = Modifier.weight(1.1f).fillMaxHeight(),
            contentPadding = PaddingValues(bottom = JullSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JullSpacing.xl)
        ) {
            homeSections(state, window, onPlay, onOpenLibrary, onOpenGame, onOpenPlatform, inset = 0.dp)
        }
    }
}

/** Estante de selección rápida: pulsar un juego lo pone en el escenario. */
@Composable
private fun ShelfRow(
    entries: List<GameEntry>,
    selectedId: String?,
    onSelect: (GameEntry) -> Unit,
    inset: androidx.compose.ui.unit.Dp,
    tileWidth: androidx.compose.ui.unit.Dp = 72.dp
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = inset, vertical = JullSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(JullSpacing.sm)
    ) {
        items(entries, key = { "shelf_${it.id}" }) { entry ->
            val selected = entry.id == selectedId
            val shape = ChamferShape(10.dp)
            Box(
                Modifier.width(tileWidth).aspectRatio(3f / 4f)
                    .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
                    .consoleSelectable(shape, onClickLabel = "Elegir ${entry.displayTitle}") { onSelect(entry) }
            ) {
                RemoteImage(entry.coverUrl, null, Modifier.fillMaxSize()) {
                    PlatformArt(entry.game.platform, Modifier.fillMaxSize(), watermark = false)
                }
                if (!selected) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
            }
        }
    }
}

private fun LazyListScope.homeSections(
    state: HomeUiState,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit,
    inset: androidx.compose.ui.unit.Dp = window.contentPadding
) {
    gameRow("continue", "Continuar jugando", state.continuePlaying, window, inset, onPlay, onOpenGame)
    gameRow("recent", "Recientes", state.recent, window, inset, onPlay, onOpenGame)
    gameRow("favorites", "Favoritos", state.favorites, window, inset, onPlay, onOpenGame)
    gameRow("added", "Añadidos recientemente", state.recentlyAdded, window, inset, onPlay, onOpenGame)

    if (state.platforms.isNotEmpty()) {
        item(key = "consoles") {
            Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
                SectionHeader("Mis consolas", inset = inset)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = inset),
                    horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)
                ) {
                    items(state.platforms, key = { it.platform.name }) { entry ->
                        PlatformCard(
                            platform = entry.platform,
                            count = entry.count,
                            modifier = Modifier.width(if (window.isLandscape) 168.dp else 180.dp),
                            onClick = { onOpenPlatform(entry.platform) }
                        )
                    }
                }
            }
        }
    }
    item(key = "library") {
        FilledTonalButton(
            onClick = onOpenLibrary,
            modifier = Modifier.padding(horizontal = inset).fillMaxWidth()
        ) {
            Icon(Icons.Rounded.VideoLibrary, contentDescription = null)
            Spacer(Modifier.size(JullSpacing.sm))
            Text("Toda mi biblioteca (${state.totalCount})")
        }
    }
}

/** Fila horizontal de juegos; no se emite si está vacía (no hay secciones vacías). */
private fun LazyListScope.gameRow(
    key: String,
    title: String,
    entries: List<GameEntry>,
    window: WindowInfo,
    inset: androidx.compose.ui.unit.Dp,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenGame: (GameEntry) -> Unit
) {
    if (entries.isEmpty()) return
    item(key = key) {
        Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
            SectionHeader(title, inset = inset)
            LazyRow(
                contentPadding = PaddingValues(horizontal = inset),
                horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)
            ) {
                items(entries, key = { it.id }) { entry ->
                    GameCard(
                        entry = entry,
                        modifier = Modifier.width(window.rowCardWidth),
                        onClick = { onOpenGame(entry) },
                        onPlayClick = { onPlay(entry.game) }
                    )
                }
            }
        }
    }
}

/** Escenario de la Home: artwork a sangre en marco con esquinas cortadas, título grande y acciones. */
@Composable
private fun GameStage(
    stage: StageData,
    onPlay: () -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier,
    wide: Boolean = false
) {
    val shape = ChamferShape(28.dp)
    val scrim = MaterialTheme.colorScheme.background
    val primary = MaterialTheme.colorScheme.primary
    // Crossfade corto al cambiar de juego: transición discreta, no un efecto continuo.
    AnimatedContent(
        targetState = stage,
        contentKey = { it.entry.id },
        transitionSpec = { fadeIn(tween(JullMotion.NORMAL)) togetherWith fadeOut(tween(JullMotion.FAST)) },
        modifier = modifier.clip(shape),
        label = "stage"
    ) { current ->
        val entry = current.entry
        Box(Modifier.fillMaxSize()) {
            RemoteImage(
                url = entry.artworkUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            ) { PlatformArt(entry.game.platform, Modifier.fillMaxSize()) }
            // Degradado para que el texto siempre sea legible, con o sin artwork.
            Box(
                Modifier.fillMaxSize().background(
                    if (wide) Brush.horizontalGradient(listOf(scrim.copy(alpha = 0.92f), scrim.copy(alpha = 0.35f)))
                    else Brush.verticalGradient(listOf(Color.Transparent, scrim.copy(alpha = 0.55f), scrim.copy(alpha = 0.96f)))
                )
            )
            Canvas(Modifier.fillMaxSize()) { drawCornerBrackets(primary.copy(alpha = 0.85f)) }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(if (wide) 0.85f else 1f)
                    .padding(JullSpacing.xl),
                verticalArrangement = Arrangement.spacedBy(JullSpacing.sm)
            ) {
                Text(current.badge, style = MaterialTheme.typography.labelSmall, color = primary)
                Text(
                    entry.displayTitle,
                    style = MaterialTheme.typography.headlineLarge,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(JullSpacing.sm)) {
                    PlatformChip(entry.game.platform)
                    Text(
                        text = heroInfo(entry),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(JullSpacing.md),
                    modifier = Modifier.padding(top = JullSpacing.sm)
                ) {
                    Button(onClick = onPlay) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.size(JullSpacing.xs))
                        Text("Jugar")
                    }
                    FilledTonalButton(onClick = onDetails) { Text("Detalles") }
                }
            }
        }
    }
}

private fun heroInfo(entry: GameEntry): String {
    val g = entry.game
    val parts = buildList {
        entry.metadata?.takeIf { it.isMatched }?.genres?.firstOrNull()?.let(::add)
        g.lastPlayedAt?.let { add(RelativeTime.format(System.currentTimeMillis(), it)) }
        if (g.playCount > 0) add(if (g.playCount == 1) "1 partida" else "${g.playCount} partidas")
    }
    return parts.joinToString(" · ")
}
