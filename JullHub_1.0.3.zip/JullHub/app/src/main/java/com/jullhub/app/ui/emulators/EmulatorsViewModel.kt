package com.jullhub.app.ui.emulators

import android.content.Context
import androidx.lifecycle.ViewModel
import com.jullhub.app.core.model.Platform
import com.jullhub.app.emulator.EmulatorRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EmulatorItem(
    val id: String,
    val name: String,
    val platforms: List<Platform>,
    val installed: Boolean,
    /** `true` si JullHub tiene un método de lanzamiento verificado para este emulador. */
    val canLaunchGames: Boolean
)

class EmulatorsViewModel(
    private val registry: EmulatorRegistry,
    private val context: Context
) : ViewModel() {
    private val _items = MutableStateFlow<List<EmulatorItem>>(emptyList())
    val items: StateFlow<List<EmulatorItem>> = _items.asStateFlow()

    init { refresh() }

    /** Vuelve a comprobar qué emuladores están instalados. */
    fun refresh() {
        _items.value = registry.all().map { adapter ->
            EmulatorItem(
                id = adapter.id,
                name = adapter.displayName,
                platforms = adapter.supportedPlatforms.sortedBy { it.displayName },
                installed = adapter.isInstalled(context),
                canLaunchGames = adapter.hasLaunchMethod
            )
        }.sortedWith(compareByDescending<EmulatorItem> { it.installed }.thenBy { it.name.lowercase() })
    }
}
