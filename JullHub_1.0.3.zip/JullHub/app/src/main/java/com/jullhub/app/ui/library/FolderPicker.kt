package com.jullhub.app.ui.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember

/** ACTION_OPEN_DOCUMENT_TREE pidiendo además permiso de lectura persistente. */
class OpenGameFolder : ActivityResultContracts.OpenDocumentTree() {
    override fun createIntent(context: Context, input: Uri?): Intent =
        super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
}

/** Devuelve una función que abre el selector de carpetas del sistema. */
@Composable
fun rememberFolderPicker(onPicked: (Uri) -> Unit): () -> Unit {
    val launcher = rememberLauncherForActivityResult(OpenGameFolder()) { uri ->
        if (uri != null) onPicked(uri)
    }
    return remember(launcher) { { launcher.launch(null) } }
}

/** Muestra en un Snackbar los avisos del [FoldersViewModel]. */
@Composable
fun CollectFolderMessages(vm: FoldersViewModel, host: SnackbarHostState) {
    LaunchedEffect(vm) {
        vm.messages.collect { host.showSnackbar(it) }
    }
}
