package com.jullhub.app.emulator

import com.jullhub.app.core.model.Game

/*
 * Métodos de lanzamiento. Cada uno está respaldado por una fuente citada; lo que no se pudo
 * verificar NO está aquí (esos emuladores se registran sin spec y se reportan como no lanzables).
 */

private const val ACTION_VIEW = "android.intent.action.VIEW"
private const val ACTION_MAIN = "android.intent.action.MAIN"

private fun Game.fileExtension(): String =
    (extension ?: fileName?.substringAfterLast('.', "")).orEmpty().lowercase()

/** Base común: el juego debe tener una URI `content://` y una extensión de un solo archivo. */
abstract class ContentUriSpec(
    private val name: String,
    private val extensions: Set<String>
) : LaunchSpec {
    override fun check(game: Game): LaunchResult? {
        val uri = game.uri
        if (uri.isNullOrBlank() || !uri.startsWith("content://")) {
            return LaunchResult.InvalidGame("La URI del juego no es válida.")
        }
        val ext = game.fileExtension()
        if (ext !in extensions) {
            return LaunchResult.Unsupported(
                "$name está instalado, pero este juego (.$ext) no puede abrirse mediante lanzamiento externo."
            )
        }
        return null
    }

    protected fun uriOf(game: Game): String = checkNotNull(game.uri)
}

/**
 * PPSSPP — ACTION_VIEW + URI en `data` sobre `org.ppsspp.ppsspp.PpssppActivity`
 * (también para Gold: mismo nombre de clase, otro paquete).
 * Fuente: https://www.ppsspp.org/docs/reference/front-end-integration/ (documentación oficial).
 * `.chd` queda fuera: ES-DE documenta que no funciona con el acceso por FileProvider y no hay
 * verificación con SAF.
 */
class PpssppSpec : ContentUriSpec("PPSSPP", setOf("iso", "cso", "pbp")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "org.ppsspp.ppsspp.PpssppActivity",
        action = ACTION_VIEW,
        dataUri = uriOf(game),
        grantReadUris = listOf(uriOf(game))
    )
}

/**
 * DuckStation — extra `bootPath` (String) con la URI sobre `com.github.stenzek.duckstation.EmulationActivity`.
 * Fuentes: preset de Daijishō y notas de NeoStation (`bootPath {file.uri}`), foro de LaunchBox.
 * `.cue/.bin` quedan fuera: el cue necesita acceso a los .bin hermanos y no está verificado con SAF.
 */
class DuckStationSpec : ContentUriSpec("DuckStation", setOf("iso", "chd", "pbp")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "com.github.stenzek.duckstation.EmulationActivity",
        stringExtras = mapOf("bootPath" to uriOf(game)),
        grantReadUris = listOf(uriOf(game))
    )
}

/**
 * NetherSX2 / AetherSX2 — extra `bootPath` (String) con la URI sobre `xyz.aethersx2.android.EmulationActivity`.
 * Fuentes: foro de LaunchBox (comando adb verificado por usuarios con URI SAF) y configuración
 * de ES-DE vía EmuBridge. Mismas restricciones de formato que DuckStation.
 */
class NetherSx2Spec : ContentUriSpec("NetherSX2 / AetherSX2", setOf("iso", "chd")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "xyz.aethersx2.android.EmulationActivity",
        stringExtras = mapOf("bootPath" to uriOf(game)),
        grantReadUris = listOf(uriOf(game))
    )
}

/**
 * Dolphin — extra `AutoStartFile` (String) con la URI sobre `org.dolphinemu.dolphinemu.ui.main.MainActivity`.
 * La clase es la misma en el Dolphin oficial y en sus forks; lo que cambia es la acción:
 * - Dolphin oficial (`org.dolphinemu.dolphinemu`): `ACTION_MAIN`. Con VIEW falla (Pegasus issue #1096).
 * - Forks MMJR / Handheld: `ACTION_VIEW`.
 * Fuente: wiki de Start Arguments de Daijishō (entradas "org.dolphinemu.dolphinemu", "mmjr", "mmjr3", "handheld").
 */
open class DolphinSpec(name: String, private val action: String) :
    ContentUriSpec(name, setOf("iso", "gcm", "rvz", "wbfs")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "org.dolphinemu.dolphinemu.ui.main.MainActivity",
        action = action,
        stringExtras = mapOf("AutoStartFile" to uriOf(game)),
        grantReadUris = listOf(uriOf(game))
    )
}

/** Dolphin oficial. */
class DolphinOfficialSpec : DolphinSpec("Dolphin", ACTION_MAIN)

/** Forks Dolphin MMJR / Handheld. */
class DolphinForkSpec : DolphinSpec("Dolphin MMJR", ACTION_VIEW)

/**
 * SkyEmu (Game Boy, Game Boy Color y Game Boy Advance) — `ACTION_VIEW` + URI en `data`
 * sobre `com.sky.SkyEmu.EnhancedNativeActivity`.
 * Fuente: wiki de Start Arguments de Daijishō (entradas gb, gbc y gba, `-d {file.uri}`).
 * Es la única fuente encontrada: el README del proyecto no documenta el lanzamiento externo.
 */
class SkyEmuSpec : ContentUriSpec("SkyEmu", setOf("gb", "gbc", "gba")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "com.sky.SkyEmu.EnhancedNativeActivity",
        action = ACTION_VIEW,
        dataUri = uriOf(game),
        grantReadUris = listOf(uriOf(game))
    )
}

/**
 * melonDS — extra `uri` (String, "preferred") con la URI SAF sobre `me.magnum.melonds.ui.emulator.EmulatorActivity`.
 * Fuente: README del proyecto (sección "Integration with third-party frontends"). Importante: la
 * propia documentación indica que la ROM debe estar ya escaneada por melonDS.
 */
class MelonDsSpec : ContentUriSpec("melonDS", setOf("nds")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "me.magnum.melonds.ui.emulator.EmulatorActivity",
        stringExtras = mapOf("uri" to uriOf(game)),
        grantReadUris = listOf(uriOf(game))
    )
}

/**
 * Vita3K — extra de array `AppStartParameters` = ["-r", <TitleID>] sobre `org.vita3k.emulator.Emulator`.
 * Abre un juego YA INSTALADO en Vita3K: el `.vpk` escaneado no se usa. Sin Title ID no se lanza
 * y nunca se deduce uno.
 * Fuentes: Vita3K-Android issue #505 (comando adb) y el mantenedor de ES-DE, que lo usa con
 * `%EXTRAARRAY_AppStartParameters%=-r,<id>`.
 */
class Vita3kSpec : LaunchSpec {
    override fun check(game: Game): LaunchResult? {
        val raw = game.titleId?.trim().orEmpty()
        if (raw.isEmpty()) {
            return LaunchResult.Unsupported(
                "Vita3K abre juegos instalados mediante su Title ID (por ejemplo PCSE00546) " +
                    "y este juego no tiene uno registrado."
            )
        }
        if (!TITLE_ID.matches(raw.uppercase())) {
            return LaunchResult.InvalidGame("El Title ID «$raw» no es válido.")
        }
        return null
    }

    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "org.vita3k.emulator.Emulator",
        stringArrayExtras = mapOf(
            "AppStartParameters" to listOf("-r", checkNotNull(game.titleId).trim().uppercase())
        )
    )

    private companion object {
        val TITLE_ID = Regex("^[A-Z0-9]{9}$")
    }
}

/**
 * Citra MMJ (`org.citra.emu`) — acción VIEW + extra `GamePath` (String) con la URI sobre
 * `org.citra.emu.ui.EmulationActivity`.
 * Fuente: wiki de Start Arguments de Daijishō (entrada "org.citra.emu storage access") y su aviso
 * de que la configuración con `file.path` fallaba y debía ser `file.uri`.
 * Cautela de la propia fuente: el comportamiento varía entre versiones/forks de Citra MMJ.
 * `.cia` queda fuera: es un instalable y no hay verificación de que se pueda arrancar directamente.
 */
class CitraMmjSpec : ContentUriSpec("Citra MMJ", setOf("3ds", "3dsx")) {
    override fun request(game: Game, installedPackage: String) = LaunchRequest(
        packageName = installedPackage,
        className = "org.citra.emu.ui.EmulationActivity",
        action = ACTION_VIEW,
        stringExtras = mapOf("GamePath" to uriOf(game)),
        grantReadUris = listOf(uriOf(game))
    )
}
