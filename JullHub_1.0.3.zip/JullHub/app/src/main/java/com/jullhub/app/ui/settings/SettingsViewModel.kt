package com.jullhub.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.data.metadata.MetadataSyncManager
import com.jullhub.app.data.settings.AppOrientation
import com.jullhub.app.data.settings.LibraryNavigation
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.data.settings.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: SettingsRepository,
    private val metadataSync: MetadataSyncManager
) : ViewModel() {
    val themeMode: StateFlow<ThemeMode> = repository.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.DARK)

    val libraryNavigation: StateFlow<LibraryNavigation> = repository.libraryNavigation
        .stateIn(viewModelScope, SharingStarted.Eagerly, LibraryNavigation.HORIZONTAL)

    val orientation: StateFlow<AppOrientation> = repository.orientation
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppOrientation.AUTO)

    val metadataApiKey: StateFlow<String> = repository.metadataApiKey
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun setLibraryNavigation(navigation: LibraryNavigation) {
        viewModelScope.launch { repository.setLibraryNavigation(navigation) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setOrientation(orientation: AppOrientation) {
        viewModelScope.launch { repository.setOrientation(orientation) }
    }

    /** Guarda la clave del proveedor y lanza una pasada para completar la metadata que falte. */
    fun saveMetadataApiKey(key: String) {
        viewModelScope.launch {
            repository.setMetadataApiKey(key)
            if (key.isNotBlank()) metadataSync.syncNow()
        }
    }
}
