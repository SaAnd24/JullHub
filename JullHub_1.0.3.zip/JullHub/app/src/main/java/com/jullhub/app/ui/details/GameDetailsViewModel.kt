package com.jullhub.app.ui.details

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.data.games.GameCatalog
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.data.metadata.GameMetadataRepository
import com.jullhub.app.data.metadata.RefreshOutcome
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Estado de la consulta de metadata de esta pantalla (la UI siempre pinta antes lo que haya en caché). */
enum class MetadataFetch { IDLE, LOADING, NOT_CONFIGURED, UNAVAILABLE }

data class GameDetailsUiState(
    val isLoading: Boolean = true,
    /** `null` con `isLoading = false`: el juego ya no está en la biblioteca. */
    val entry: GameEntry? = null,
    val fetch: MetadataFetch = MetadataFetch.IDLE
)

class GameDetailsViewModel(
    private val catalog: GameCatalog,
    private val games: GameRepository,
    private val metadata: GameMetadataRepository
) : ViewModel() {
    private val gameId = MutableStateFlow<String?>(null)
    private val fetch = MutableStateFlow(MetadataFetch.IDLE)

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<GameDetailsUiState> = combine(
        gameId.flatMapLatest { id ->
            catalog.observeEntries().map { list -> id?.let { wanted -> list.firstOrNull { it.id == wanted } } }
        },
        gameId,
        fetch
    ) { entry, id, f ->
        if (id == null) GameDetailsUiState() else GameDetailsUiState(isLoading = false, entry = entry, fetch = f)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GameDetailsUiState())

    fun open(id: String) {
        if (gameId.value == id) return
        gameId.value = id
        fetch.value = MetadataFetch.IDLE
        refreshMetadata(force = false)
    }

    /** Consulta al proveedor solo si hace falta (o si se fuerza). Nunca bloquea ni rompe la pantalla. */
    fun refreshMetadata(force: Boolean) {
        val id = gameId.value ?: return
        viewModelScope.launch {
            val entry = catalog.observeEntries().first().firstOrNull { it.id == id } ?: return@launch
            fetch.value = MetadataFetch.LOADING
            fetch.value = when (metadata.refresh(entry.game, force)) {
                RefreshOutcome.Updated, RefreshOutcome.Cached -> MetadataFetch.IDLE
                RefreshOutcome.NotConfigured -> MetadataFetch.NOT_CONFIGURED
                RefreshOutcome.Unavailable -> MetadataFetch.UNAVAILABLE
            }
        }
    }

    fun onFavoriteToggle(entry: GameEntry) {
        viewModelScope.launch { games.setFavorite(entry.id, !entry.game.isFavorite) }
    }
}
