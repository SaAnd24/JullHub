package com.jullhub.app.core.model

/**
 * Juego de la biblioteca. Ningún campo es específico de un emulador concreto:
 * los datos que cada emulador necesite (URI, Title ID, core...) viajan aquí y
 * cada [com.jullhub.app.emulator.EmulatorAdapter] decide cuáles usar.
 */
data class Game(
    val id: String,
    val title: String,
    val platform: Platform,
    /** URI persistente `content://` (SAF). Nulo si el emulador lanza por identificador (p. ej. Vita3K). */
    val uri: String? = null,
    val fileName: String? = null,
    val extension: String? = null,
    /** Id del [com.jullhub.app.emulator.EmulatorAdapter] asociado, si el usuario eligió uno. */
    val emulatorId: String? = null,
    /** Identificador propio del emulador, si lo requiere. */
    val emulatorGameId: String? = null,
    val titleId: String? = null,
    val coverUri: String? = null,
    val isFavorite: Boolean = false,
    val lastPlayedAt: Long? = null,
    val playCount: Int = 0,
    val playTimeMillis: Long = 0L,
    val addedAt: Long
)
