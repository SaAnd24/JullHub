package com.jullhub.app.core.model

/** Plataformas que la biblioteca podrá manejar. Añadir una nueva solo requiere una entrada aquí. */
enum class Platform(val displayName: String) {
    PS1("PlayStation"),
    PS2("PlayStation 2"),
    PSP("PSP"),
    PS_VITA("PS Vita"),
    NDS("Nintendo DS"),
    N3DS("Nintendo 3DS"),
    N64("Nintendo 64"),
    GB_GBC("Game Boy / Color"),
    GBA("Game Boy Advance"),
    GAMECUBE("GameCube"),
    WII("Wii"),
    DREAMCAST("Dreamcast"),
    NES("NES"),
    SNES("SNES"),
    MEGA_DRIVE("Mega Drive"),
    ARCADE("Arcade / RetroArch"),
    OTHER("Otras"),
    /** El escáner no pudo determinar la consola con suficiente confianza. */
    UNKNOWN("Desconocida")
}
