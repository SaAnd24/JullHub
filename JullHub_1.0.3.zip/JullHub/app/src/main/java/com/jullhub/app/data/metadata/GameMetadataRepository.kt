package com.jullhub.app.data.metadata

import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.GameMetadata
import com.jullhub.app.core.model.MetadataStatus
import com.jullhub.app.data.db.GameMetadataDao
import com.jullhub.app.data.db.toEntity
import com.jullhub.app.data.db.toModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class RefreshOutcome {
    /** Se guardó metadata nueva (o un "sin coincidencia"). */
    Updated,
    /** Ya había datos válidos en caché; no se consultó la red. */
    Cached,
    /** Hay que configurar el proveedor (falta la clave). */
    NotConfigured,
    /** Sin red o proveedor caído: no se guardó nada, se reintentará. */
    Unavailable
}

/** Acceso a la metadata: la UI lee siempre de aquí (caché local); la red solo se usa en [refresh]. */
interface GameMetadataRepository {
    fun observeAll(): Flow<Map<String, GameMetadata>>
    suspend fun refresh(game: Game, force: Boolean = false): RefreshOutcome
    suspend fun isConfigured(): Boolean
}

class CachedGameMetadataRepository(
    private val dao: GameMetadataDao,
    private val provider: MetadataProvider,
    private val clock: () -> Long = System::currentTimeMillis
) : GameMetadataRepository {

    override fun observeAll(): Flow<Map<String, GameMetadata>> =
        dao.observeAll().map { rows -> rows.associate { it.gameId to it.toModel() } }

    override suspend fun isConfigured(): Boolean = provider.isConfigured()

    override suspend fun refresh(game: Game, force: Boolean): RefreshOutcome {
        val now = clock()
        val existing = dao.get(game.id)?.toModel()
        if (!MetadataCachePolicy.needsLookup(existing, now, force)) return RefreshOutcome.Cached
        if (!provider.isConfigured()) return RefreshOutcome.NotConfigured

        return try {
            val query = TitleNormalizer.searchQuery(game.title)
            if (query.isEmpty()) return RefreshOutcome.Cached
            val candidates = when (val found = provider.search(query, game.platform)) {
                is SearchResult.Unavailable -> return RefreshOutcome.Unavailable
                is SearchResult.Candidates -> found.items
            }
            val fresh = when (val decision = TitleMatcher.decide(query, candidates)) {
                MatchDecision.NoMatch -> empty(game, MetadataStatus.NO_MATCH, now)
                is MatchDecision.Ambiguous -> empty(game, MetadataStatus.AMBIGUOUS, now)
                is MatchDecision.Match -> when (val d = provider.details(decision.candidate)) {
                    is DetailsResult.Unavailable -> return RefreshOutcome.Unavailable
                    is DetailsResult.Found -> matched(game, d.game, now)
                }
            }
            dao.upsert(MetadataCachePolicy.keepPreviousIfMatched(existing, fresh).toEntity())
            RefreshOutcome.Updated
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Un fallo del proveedor jamás debe romper la biblioteca ni el lanzamiento.
            RefreshOutcome.Unavailable
        }
    }

    private fun empty(game: Game, status: MetadataStatus, now: Long) =
        GameMetadata(gameId = game.id, status = status, provider = provider.id, fetchedAt = now)

    private fun matched(game: Game, ext: ExternalGame, now: Long) = GameMetadata(
        gameId = game.id,
        status = MetadataStatus.MATCHED,
        provider = provider.id,
        externalId = ext.externalId,
        title = ext.title,
        alternativeTitle = ext.alternativeTitle,
        platformName = ext.platformName,
        description = ext.description,
        releaseDate = ext.releaseDate,
        developers = ext.developers,
        publishers = ext.publishers,
        genres = ext.genres,
        coverUrl = ext.coverUrl,
        artworkUrl = ext.artworkUrl,
        screenshots = ext.screenshots,
        fetchedAt = now
    )
}
