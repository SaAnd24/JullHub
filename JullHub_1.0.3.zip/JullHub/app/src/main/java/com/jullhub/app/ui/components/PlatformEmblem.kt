package com.jullhub.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullhub.app.core.model.Platform

/**
 * Representación visual de una consola: bloque de color con su sigla.
 * Es la ÚNICA pieza a cambiar cuando haya assets propios: basta con sustituir el cuerpo
 * por una imagen (`painterResource`) según la plataforma.
 */
@Composable
fun PlatformEmblem(platform: Platform, modifier: Modifier = Modifier, size: Dp = 88.dp) {
    val label = platform.shortName()
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size / 4))
            .background(platform.accentColor()),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = if (label.length > 3) (size.value * 0.22f).sp else (size.value * 0.32f).sp,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

fun Platform.shortName(): String = when (this) {
    Platform.PS1 -> "PS1"
    Platform.PS2 -> "PS2"
    Platform.PSP -> "PSP"
    Platform.PS_VITA -> "VITA"
    Platform.NDS -> "NDS"
    Platform.N3DS -> "3DS"
    Platform.N64 -> "N64"
    Platform.GB_GBC -> "GB"
    Platform.GBA -> "GBA"
    Platform.GAMECUBE -> "GC"
    Platform.WII -> "Wii"
    Platform.DREAMCAST -> "DC"
    Platform.NES -> "NES"
    Platform.SNES -> "SNES"
    Platform.MEGA_DRIVE -> "MD"
    Platform.ARCADE -> "ARC"
    Platform.OTHER -> "···"
    Platform.UNKNOWN -> "?"
}

fun Platform.accentColor(): Color = when (this) {
    Platform.PS1 -> Color(0xFF5C6BC0)
    Platform.PS2 -> Color(0xFF3949AB)
    Platform.PSP -> Color(0xFF1E88E5)
    Platform.PS_VITA -> Color(0xFF0277BD)
    Platform.NDS -> Color(0xFF546E7A)
    Platform.N3DS -> Color(0xFFD32F2F)
    Platform.N64 -> Color(0xFF2E7D32)
    Platform.GB_GBC -> Color(0xFF7CB342)
    Platform.GBA -> Color(0xFF6A1B9A)
    Platform.GAMECUBE -> Color(0xFF7E57C2)
    Platform.WII -> Color(0xFF00897B)
    Platform.DREAMCAST -> Color(0xFFEF6C00)
    Platform.NES -> Color(0xFFC62828)
    Platform.SNES -> Color(0xFF8D6E63)
    Platform.MEGA_DRIVE -> Color(0xFF283593)
    Platform.ARCADE -> Color(0xFFAD1457)
    Platform.OTHER -> Color(0xFF616161)
    Platform.UNKNOWN -> Color(0xFF757575)
}
