package com.jullhub.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.jullhub.app.core.model.GameMetadata
import com.jullhub.app.core.model.MetadataStatus
import com.jullhub.app.data.metadata.MetadataCodec

/**
 * Metadata externa en caché. Tabla aparte de `games` para no mezclar datos locales con externos:
 * un re-escaneo o un borrado de juegos nunca toca la metadata, y viceversa.
 * Las listas se guardan codificadas con [MetadataCodec].
 */
@Entity(tableName = "game_metadata")
data class GameMetadataEntity(
    @PrimaryKey val gameId: String,
    val status: String,
    val provider: String,
    val externalId: String?,
    val title: String?,
    val alternativeTitle: String?,
    val platformName: String?,
    val description: String?,
    val releaseDate: String?,
    val developers: String,
    val publishers: String,
    val genres: String,
    val coverUrl: String?,
    val artworkUrl: String?,
    val screenshots: String,
    val fetchedAt: Long
)

fun GameMetadataEntity.toModel(): GameMetadata = GameMetadata(
    gameId = gameId,
    status = MetadataStatus.entries.firstOrNull { it.name == status } ?: MetadataStatus.NO_MATCH,
    provider = provider,
    externalId = externalId,
    title = title,
    alternativeTitle = alternativeTitle,
    platformName = platformName,
    description = description,
    releaseDate = releaseDate,
    developers = MetadataCodec.decode(developers),
    publishers = MetadataCodec.decode(publishers),
    genres = MetadataCodec.decode(genres),
    coverUrl = coverUrl,
    artworkUrl = artworkUrl,
    screenshots = MetadataCodec.decode(screenshots),
    fetchedAt = fetchedAt
)

fun GameMetadata.toEntity(): GameMetadataEntity = GameMetadataEntity(
    gameId = gameId,
    status = status.name,
    provider = provider,
    externalId = externalId,
    title = title,
    alternativeTitle = alternativeTitle,
    platformName = platformName,
    description = description,
    releaseDate = releaseDate,
    developers = MetadataCodec.encode(developers),
    publishers = MetadataCodec.encode(publishers),
    genres = MetadataCodec.encode(genres),
    coverUrl = coverUrl,
    artworkUrl = artworkUrl,
    screenshots = MetadataCodec.encode(screenshots),
    fetchedAt = fetchedAt
)
