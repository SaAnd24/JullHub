package com.jullhub.app.ui.consoles

import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.PLATFORM_ORDER
import com.jullhub.app.core.model.Platform
import com.jullhub.app.ui.home.PlatformCount

/** Consolas presentes en la biblioteca, en el orden fijo de JullHub. Pura y testeable. */
object ConsolesContent {
    fun build(all: List<GameEntry>): List<PlatformCount> {
        val counts = all.groupingBy { it.game.platform }.eachCount()
        return PLATFORM_ORDER.filter { it in counts }.map { PlatformCount(it, counts.getValue(it)) }
    }
}

data class PlatformUiState(
    val isLoading: Boolean = true,
    val platform: Platform? = null,
    val total: Int = 0,
    val recent: List<GameEntry> = emptyList(),
    val favorites: List<GameEntry> = emptyList(),
    val games: List<GameEntry> = emptyList()
)

object PlatformContent {
    fun build(platform: Platform, all: List<GameEntry>): PlatformUiState {
        val mine = all.filter { it.game.platform == platform }
        return PlatformUiState(
            isLoading = false,
            platform = platform,
            total = mine.size,
            recent = mine.filter { it.game.lastPlayedAt != null }.sortedByDescending { it.game.lastPlayedAt }.take(10),
            favorites = mine.filter { it.game.isFavorite }.sortedBy { it.displayTitle.lowercase() }.take(12),
            games = mine.sortedBy { it.displayTitle.lowercase() }
        )
    }
}
