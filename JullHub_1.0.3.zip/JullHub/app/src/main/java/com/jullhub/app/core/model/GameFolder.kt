package com.jullhub.app.core.model

/** Carpeta de juegos elegida con ACTION_OPEN_DOCUMENT_TREE. */
data class GameFolder(
    /** URI `content://` del árbol, como texto. Es la clave única (evita duplicados). */
    val uri: String,
    val name: String,
    /** `false` si el permiso persistente ya no está vigente. */
    val hasAccess: Boolean
)
