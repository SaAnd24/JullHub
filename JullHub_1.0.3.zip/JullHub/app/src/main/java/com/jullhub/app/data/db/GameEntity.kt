package com.jullhub.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/**
 * Fila de Room para un [Game]. El `id` es la URI SAF del documento, estable entre escaneos.
 * Las columnas de uso/emulador ya existen para evitar migraciones cuando esas funciones lleguen.
 */
@Entity(
    tableName = "games",
    indices = [Index("folderUri"), Index("platform")]
)
data class GameEntity(
    @PrimaryKey val id: String,
    val title: String,
    /** Nombre del enum [Platform]. */
    val platform: String,
    val uri: String?,
    val fileName: String?,
    val extension: String?,
    /** URI del árbol SAF configurado al que pertenece el juego (clave en DataStore). */
    val folderUri: String,
    val isFavorite: Boolean = false,
    val addedAt: Long,
    // Reservado para fases futuras (aún sin uso).
    val emulatorId: String? = null,
    val emulatorGameId: String? = null,
    val titleId: String? = null,
    val coverUri: String? = null,
    val lastPlayedAt: Long? = null,
    val playCount: Int = 0,
    val playTimeMillis: Long = 0L
)

fun GameEntity.toGame(): Game = Game(
    id = id,
    title = title,
    platform = Platform.entries.firstOrNull { it.name == platform } ?: Platform.UNKNOWN,
    uri = uri,
    fileName = fileName,
    extension = extension,
    emulatorId = emulatorId,
    emulatorGameId = emulatorGameId,
    titleId = titleId,
    coverUri = coverUri,
    isFavorite = isFavorite,
    lastPlayedAt = lastPlayedAt,
    playCount = playCount,
    playTimeMillis = playTimeMillis,
    addedAt = addedAt
)

fun Game.toEntity(folderUri: String): GameEntity = GameEntity(
    id = id,
    title = title,
    platform = platform.name,
    uri = uri,
    fileName = fileName,
    extension = extension,
    folderUri = folderUri,
    isFavorite = isFavorite,
    addedAt = addedAt,
    emulatorId = emulatorId,
    emulatorGameId = emulatorGameId,
    titleId = titleId,
    coverUri = coverUri,
    lastPlayedAt = lastPlayedAt,
    playCount = playCount,
    playTimeMillis = playTimeMillis
)
