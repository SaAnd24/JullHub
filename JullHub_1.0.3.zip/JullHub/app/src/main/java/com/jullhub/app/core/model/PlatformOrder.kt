package com.jullhub.app.core.model

/** Orden fijo de las consolas en la Biblioteca; lo no listado va al final. */
val PLATFORM_ORDER: List<Platform> = (listOf(
    Platform.PSP, Platform.PS2, Platform.PS1, Platform.PS_VITA,
    Platform.NDS, Platform.N3DS, Platform.GAMECUBE, Platform.WII, Platform.N64,
    Platform.GBA, Platform.GB_GBC, Platform.SNES, Platform.NES,
    Platform.DREAMCAST, Platform.MEGA_DRIVE, Platform.ARCADE,
    Platform.OTHER, Platform.UNKNOWN
) + Platform.entries).distinct()
