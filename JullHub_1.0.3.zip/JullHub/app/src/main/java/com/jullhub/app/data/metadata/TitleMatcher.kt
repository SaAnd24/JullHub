package com.jullhub.app.data.metadata

sealed interface MatchDecision {
    data class Match(val candidate: MetadataCandidate) : MatchDecision
    data object NoMatch : MatchDecision
    data class Ambiguous(val candidates: List<MetadataCandidate>) : MatchDecision
}

/**
 * Política conservadora: solo se acepta un candidato cuyo título normalizado sea IGUAL al local.
 * Dos candidatos iguales -> ambiguo (no se elige). Parecidos pero distintos -> sin coincidencia.
 * Es preferible un juego sin carátula que una carátula incorrecta.
 */
object TitleMatcher {
    fun decide(localTitle: String, candidates: List<MetadataCandidate>): MatchDecision {
        val wanted = TitleNormalizer.key(localTitle)
        if (wanted.isEmpty()) return MatchDecision.NoMatch
        val exact = candidates.filter { TitleNormalizer.key(it.name) == wanted }
            .distinctBy { it.externalId }
        return when (exact.size) {
            0 -> MatchDecision.NoMatch
            1 -> MatchDecision.Match(exact.first())
            else -> MatchDecision.Ambiguous(exact)
        }
    }
}
