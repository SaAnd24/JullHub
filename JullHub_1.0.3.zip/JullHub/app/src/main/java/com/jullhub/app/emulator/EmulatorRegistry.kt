package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.Platform

/** Catálogo de adapters. Registrar un emulador nuevo = añadir su adapter a [EmulatorCatalog]. */
class EmulatorRegistry(private val adapters: List<EmulatorAdapter> = emptyList()) {
    fun all(): List<EmulatorAdapter> = adapters
    fun byId(id: String): EmulatorAdapter? = adapters.firstOrNull { it.id == id }
    fun forPlatform(platform: Platform): List<EmulatorAdapter> =
        adapters.filter { platform in it.supportedPlatforms }
    fun compatibleWith(game: Game): List<EmulatorAdapter> {
        return adapters.filter { it.supports(game) }
    }

    /** Emuladores de [platform] que están instalados ahora mismo. */
    fun installedForPlatform(context: Context, platform: Platform): List<EmulatorAdapter> =
        forPlatform(platform).filter { isInstalledSafely(context, it) }

    /** Juego -> plataforma -> emuladores compatibles instalados. Un adapter defectuoso se ignora. */
    fun installedCompatibleWith(context: Context, game: Game): List<EmulatorAdapter> =
        compatibleWith(game).filter { isInstalledSafely(context, it) }

    private fun isInstalledSafely(context: Context, adapter: EmulatorAdapter): Boolean =
        try { adapter.isInstalled(context) } catch (_: Exception) { false }
}
