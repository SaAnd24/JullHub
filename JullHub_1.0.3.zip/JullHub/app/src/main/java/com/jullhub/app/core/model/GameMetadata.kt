package com.jullhub.app.core.model

/** Resultado de buscar metadata para un juego. Solo [MATCHED] aporta datos de presentación. */
enum class MetadataStatus {
    MATCHED,
    /** El proveedor no tiene una coincidencia fiable. Se reintenta pasado un tiempo. */
    NO_MATCH,
    /** Había varias coincidencias igual de buenas: no se elige ninguna. */
    AMBIGUOUS
}

/**
 * Metadata externa de un juego. Separada a propósito de [Game] (datos locales): su ausencia
 * nunca impide detectar, mostrar ni abrir un juego.
 */
data class GameMetadata(
    val gameId: String,
    val status: MetadataStatus,
    val provider: String,
    val externalId: String? = null,
    val title: String? = null,
    val alternativeTitle: String? = null,
    val platformName: String? = null,
    val description: String? = null,
    val releaseDate: String? = null,
    val developers: List<String> = emptyList(),
    val publishers: List<String> = emptyList(),
    val genres: List<String> = emptyList(),
    val coverUrl: String? = null,
    val artworkUrl: String? = null,
    val screenshots: List<String> = emptyList(),
    val fetchedAt: Long
) {
    val isMatched: Boolean get() = status == MetadataStatus.MATCHED
}

/** Juego local + su metadata opcional. Es lo que consume la UI. */
data class GameEntry(val game: Game, val metadata: GameMetadata? = null) {
    private val meta: GameMetadata? get() = metadata?.takeIf { it.isMatched }

    val id: String get() = game.id

    /** Título del proveedor si hay coincidencia; si no, el nombre local limpio (sin "(USA)", "_", etc.). */
    val displayTitle: String
        get() = meta?.title?.takeIf { it.isNotBlank() } ?: cleanLocalTitle(game.title)

    val coverUrl: String? get() = meta?.coverUrl ?: game.coverUri
    val artworkUrl: String? get() = meta?.artworkUrl ?: meta?.coverUrl ?: game.coverUri
}

/** Limpieza visual del nombre de archivo; la lógica de búsqueda usa [com.jullhub.app.data.metadata.TitleNormalizer]. */
fun cleanLocalTitle(raw: String): String {
    val noTags = raw.replace(Regex("""\s*[\(\[][^\)\]]*[\)\]]"""), " ")
    val spaced = noTags.replace('_', ' ').replace(Regex("""\s+"""), " ").trim()
    return spaced.ifEmpty { raw.trim() }
}
