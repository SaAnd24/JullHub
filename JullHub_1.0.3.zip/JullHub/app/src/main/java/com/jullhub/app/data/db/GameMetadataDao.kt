package com.jullhub.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameMetadataDao {
    @Query("SELECT * FROM game_metadata")
    fun observeAll(): Flow<List<GameMetadataEntity>>

    @Query("SELECT * FROM game_metadata WHERE gameId = :gameId")
    suspend fun get(gameId: String): GameMetadataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: GameMetadataEntity)
}
