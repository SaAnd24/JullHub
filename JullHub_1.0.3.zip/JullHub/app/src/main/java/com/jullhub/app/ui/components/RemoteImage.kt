package com.jullhub.app.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.jullhub.app.ui.theme.JullMotion

/**
 * Imagen remota no bloqueante. El [fallback] se dibuja siempre debajo, así que hay contenido
 * mientras carga, si falla o si no hay URL. Coil decodifica al tamaño del layout (no a tamaño
 * original) y mantiene caché en memoria y disco.
 */
@Composable
fun RemoteImage(
    url: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alpha: Float = 1f,
    fallback: @Composable () -> Unit
) {
    Box(modifier) {
        fallback()
        if (!url.isNullOrBlank()) {
            val context = LocalContext.current
            val request = remember(url) {
                ImageRequest.Builder(context).data(url).crossfade(JullMotion.NORMAL).build()
            }
            AsyncImage(
                model = request,
                contentDescription = contentDescription,
                contentScale = contentScale,
                alpha = alpha,
                modifier = Modifier.matchParentSize()
            )
        }
    }
}
