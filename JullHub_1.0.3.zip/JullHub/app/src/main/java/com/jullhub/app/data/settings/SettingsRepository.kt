package com.jullhub.app.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/** Orientación de la pantalla de JullHub. */
enum class AppOrientation { AUTO, PORTRAIT, LANDSCAPE }

/** Dirección del gesto para cambiar de consola en la Biblioteca. */
enum class LibraryNavigation { HORIZONTAL, VERTICAL }

interface SettingsRepository {
    val themeMode: Flow<ThemeMode>
    suspend fun setThemeMode(mode: ThemeMode)

    val libraryNavigation: Flow<LibraryNavigation>
    suspend fun setLibraryNavigation(navigation: LibraryNavigation)

    val orientation: Flow<AppOrientation>
    suspend fun setOrientation(orientation: AppOrientation)

    /** Clave de API del proveedor de metadata, introducida por el usuario. Vacía = sin metadata. */
    val metadataApiKey: Flow<String>
    suspend fun setMetadataApiKey(key: String)
}

class DataStoreSettingsRepository(
    private val dataStore: DataStore<Preferences>
) : SettingsRepository {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val navigationKey = stringPreferencesKey("library_navigation")
    private val orientationKey = stringPreferencesKey("orientation")
    private val metadataKeyKey = stringPreferencesKey("metadata_api_key")

    override val themeMode: Flow<ThemeMode> = dataStore.data.map { prefs ->
        prefs[themeKey]?.let { saved -> ThemeMode.entries.firstOrNull { it.name == saved } }
            ?: ThemeMode.DARK
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[themeKey] = mode.name }
    }

    override val libraryNavigation: Flow<LibraryNavigation> = dataStore.data.map { prefs ->
        prefs[navigationKey]?.let { saved -> LibraryNavigation.entries.firstOrNull { it.name == saved } }
            ?: LibraryNavigation.HORIZONTAL
    }

    override suspend fun setLibraryNavigation(navigation: LibraryNavigation) {
        dataStore.edit { it[navigationKey] = navigation.name }
    }

    override val orientation: Flow<AppOrientation> = dataStore.data.map { prefs ->
        prefs[orientationKey]?.let { saved -> AppOrientation.entries.firstOrNull { it.name == saved } }
            ?: AppOrientation.AUTO
    }

    override suspend fun setOrientation(orientation: AppOrientation) {
        dataStore.edit { it[orientationKey] = orientation.name }
    }

    override val metadataApiKey: Flow<String> = dataStore.data.map { it[metadataKeyKey].orEmpty() }

    override suspend fun setMetadataApiKey(key: String) {
        dataStore.edit { it[metadataKeyKey] = key.trim() }
    }
}
