package com.jullhub.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.padding
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.scanner.PlatformDetector

/**
 * Identidad visual de una consola. Todas comparten el mismo lenguaje (degradado + trama + sigla)
 * y solo cambian color y sigla, para que se lea como una colección curada.
 * Si algún día hay artwork propio, basta con rellenar [imageRes] y [PlatformArt] lo usará.
 */
@Immutable
data class PlatformVisual(
    val platform: Platform,
    val name: String,
    val shortName: String,
    val accent: Color,
    val accentDeep: Color,
    val tagline: String,
    /** Nombres de carpeta reconocidos para esta consola (los mismos que usa el escáner). */
    val aliases: List<String>,
    val imageRes: Int? = null
)

object PlatformVisuals {
    private val cache = Platform.entries.associateWith { build(it) }

    fun of(platform: Platform): PlatformVisual = cache.getValue(platform)

    private fun build(p: Platform): PlatformVisual {
        val accent = p.accentColor()
        return PlatformVisual(
            platform = p,
            name = p.displayName,
            shortName = p.shortName(),
            accent = accent,
            accentDeep = accent.darken(0.55f),
            tagline = tagline(p),
            aliases = PlatformDetector.DEFAULT_ALIASES[p].orEmpty()
        )
    }

    private fun tagline(p: Platform): String = when (p) {
        Platform.PS1 -> "Clásicos de 32 bits"
        Platform.PS2 -> "La biblioteca más grande"
        Platform.PSP -> "Grandes juegos de bolsillo"
        Platform.PS_VITA -> "Pantalla OLED de bolsillo"
        Platform.NDS -> "Dos pantallas, mil ideas"
        Platform.N3DS -> "Profundidad en tus manos"
        Platform.N64 -> "Aventuras en 3D"
        Platform.GB_GBC -> "Portátiles de siempre"
        Platform.GBA -> "Lo mejor en 32 bits portátil"
        Platform.GAMECUBE -> "Pequeño cubo, grandes juegos"
        Platform.WII -> "Juega a tu manera"
        Platform.DREAMCAST -> "Adelantada a su tiempo"
        Platform.NES -> "Donde empezó todo"
        Platform.SNES -> "La era dorada de 16 bits"
        Platform.MEGA_DRIVE -> "Velocidad de 16 bits"
        Platform.ARCADE -> "Recreativas"
        Platform.OTHER -> "Otros sistemas"
        Platform.UNKNOWN -> "Consola sin identificar"
    }
}

private fun Color.darken(factor: Float): Color =
    Color(red * factor, green * factor, blue * factor, alpha)

/** Fondo de consola: degradado de su color, trama de círculos y sigla en marca de agua. */
@Composable
fun PlatformArt(
    platform: Platform,
    modifier: Modifier = Modifier,
    watermark: Boolean = true,
    content: @Composable () -> Unit = {}
) {
    val visual = PlatformVisuals.of(platform)
    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(visual.accent.copy(alpha = 0.85f), visual.accentDeep))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            // Líneas de velocidad diagonales + motivo de la consola, siempre con el mismo trazo.
            val line = Color.White.copy(alpha = 0.05f)
            var x = -size.height
            while (x < size.width) {
                drawLine(line, Offset(x, size.height), Offset(x + size.height, 0f), 6f)
                x += 34f
            }
            drawConsoleMotif(platform, Color.White.copy(alpha = 0.22f))
        }
        if (watermark) {
            Text(
                text = visual.shortName,
                color = Color.White.copy(alpha = 0.16f),
                fontWeight = FontWeight.Black,
                fontSize = 56.sp,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
        content()
    }
}

/** Marcador pequeño con la sigla de la consola sobre su color. */
@Composable
fun PlatformChip(platform: Platform, modifier: Modifier = Modifier) {
    val v = PlatformVisuals.of(platform)
    Box(
        modifier = modifier.background(v.accent.copy(alpha = 0.9f), MaterialTheme.shapes.small),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = v.shortName,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
