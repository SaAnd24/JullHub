package com.jullhub.app.core.util

/** "Hace 5 min", "Hace 3 h", "Ayer"... Puro y testeable (recibe `now` explícito). */
object RelativeTime {
    private const val MIN = 60_000L
    private const val HOUR = 60 * MIN
    private const val DAY = 24 * HOUR

    fun format(now: Long, then: Long): String {
        val d = now - then
        return when {
            d < MIN -> "Ahora mismo"
            d < HOUR -> "Hace ${d / MIN} min"
            d < DAY -> "Hace ${d / HOUR} h"
            d < 2 * DAY -> "Ayer"
            d < 30 * DAY -> "Hace ${d / DAY} días"
            d < 365 * DAY -> "Hace ${d / (30 * DAY)} ${if (d / (30 * DAY) == 1L) "mes" else "meses"}"
            else -> "Hace más de un año"
        }
    }
}
