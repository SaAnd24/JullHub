package com.jullhub.app.ui.consoles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.Platform
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.MutedText
import com.jullhub.app.ui.components.PlatformArt
import com.jullhub.app.ui.components.PlatformCard
import com.jullhub.app.ui.components.PlatformVisuals
import com.jullhub.app.ui.components.SectionHeader
import com.jullhub.app.ui.components.gamesCountLabel
import com.jullhub.app.ui.play.PlayViewModel
import com.jullhub.app.ui.play.rememberPlayAction
import com.jullhub.app.ui.theme.JullSpacing
import com.jullhub.app.ui.theme.rememberWindowInfo

/** Destino "Consolas": todas las consolas que hay en la biblioteca, como tarjetas con su arte. */
@Composable
fun ConsolesScreen(
    factory: ViewModelProvider.Factory,
    onOpenPlatform: (Platform) -> Unit,
    vm: ConsolesViewModel = viewModel(factory = factory)
) {
    val platforms by vm.platforms.collectAsStateWithLifecycle()
    val window = rememberWindowInfo()
    val list = platforms
    when {
        list == null -> Box(Modifier.fillMaxSize())
        list.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Rounded.SportsEsports,
                title = "Aún no hay consolas",
                body = "Las consolas aparecen cuando JullHub encuentra juegos en tus carpetas."
            )
        }
        else -> LazyVerticalGrid(
            columns = GridCells.Adaptive(if (window.isLandscape) 190.dp else 160.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(window.contentPadding),
            horizontalArrangement = Arrangement.spacedBy(JullSpacing.md),
            verticalArrangement = Arrangement.spacedBy(JullSpacing.md)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Text("Consolas", style = MaterialTheme.typography.headlineLarge)
                    MutedText("${list.size} en tu colección")
                }
            }
            items(list, key = { it.platform.name }) { entry ->
                PlatformCard(entry.platform, entry.count, onClick = { onOpenPlatform(entry.platform) })
            }
        }
    }
}

/** Página de una consola: arte, número de juegos, recientes, favoritos y su biblioteca. */
@Composable
fun PlatformScreen(
    platform: Platform,
    factory: ViewModelProvider.Factory,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    vm: PlatformViewModel = viewModel(key = "platform:${platform.name}", factory = factory),
    playVm: PlayViewModel = viewModel(factory = factory)
) {
    LaunchedEffect(platform) { vm.open(platform) }
    val state by vm.uiState.collectAsStateWithLifecycle()
    val play = rememberPlayAction(playVm, snackbarHostState)
    val window = rememberWindowInfo()
    val visual = PlatformVisuals.of(platform)

    LazyVerticalGrid(
        columns = GridCells.Adaptive(window.coverMinWidth),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = window.contentPadding, end = window.contentPadding, top = JullSpacing.sm, bottom = JullSpacing.xl),
        horizontalArrangement = Arrangement.spacedBy(JullSpacing.md),
        verticalArrangement = Arrangement.spacedBy(JullSpacing.lg)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            PlatformArt(
                platform = platform,
                modifier = Modifier.fillMaxWidth().height(if (window.isLandscape) 160.dp else 220.dp)
                    .clip(MaterialTheme.shapes.extraLarge)
            ) {
                Box(Modifier.fillMaxSize()) {
                    IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(JullSpacing.sm)) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Column(
                        modifier = Modifier.align(Alignment.BottomStart).padding(JullSpacing.xl)
                    ) {
                        Text(visual.name, style = MaterialTheme.typography.headlineLarge, color = Color.White)
                        Text(visual.tagline, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                        Text(gamesCountLabel(state.total), style = MaterialTheme.typography.labelLarge, color = Color.White)
                    }
                }
            }
        }

        if (!state.isLoading && state.total == 0) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                EmptyState(
                    icon = Icons.Rounded.SportsEsports,
                    title = "Sin juegos de ${visual.name}",
                    body = "Cuando haya juegos de esta consola en tus carpetas aparecerán aquí."
                )
            }
        } else {
            shelf("recent", "Recientes", state.recent, window.rowCardWidth, 0.dp, onOpenGame, play)
            shelf("favorites", "Favoritos", state.favorites, window.rowCardWidth, 0.dp, onOpenGame, play)
            if (state.games.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }, key = "libraryHeader") {
                    SectionHeader("Biblioteca", inset = 0.dp)
                }
                items(state.games, key = { it.id }) { entry ->
                    GameCard(
                        entry = entry,
                        showPlatform = false,
                        onClick = { onOpenGame(entry) },
                        onFavoriteClick = { vm.onFavoriteToggle(entry) },
                        onPlayClick = { play(entry.game) }
                    )
                }
            }
        }
    }
}

private fun LazyGridScope.shelf(
    key: String,
    title: String,
    entries: List<GameEntry>,
    cardWidth: androidx.compose.ui.unit.Dp,
    inset: androidx.compose.ui.unit.Dp,
    onOpenGame: (GameEntry) -> Unit,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit
) {
    if (entries.isEmpty()) return
    item(span = { GridItemSpan(maxLineSpan) }, key = key) {
        Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
            SectionHeader(title, inset = inset)
            LazyRow(
                contentPadding = PaddingValues(horizontal = inset),
                horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)
            ) {
                rowItems(entries, key = { it.id }) { entry ->
                    GameCard(
                        entry = entry,
                        modifier = Modifier.width(cardWidth),
                        showPlatform = false,
                        onClick = { onOpenGame(entry) },
                        onPlayClick = { onPlay(entry.game) }
                    )
                }
            }
        }
    }
}
