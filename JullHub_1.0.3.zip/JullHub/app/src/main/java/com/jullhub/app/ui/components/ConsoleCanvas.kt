package com.jullhub.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.takeOrElse
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.jullhub.app.core.model.Platform
import com.jullhub.app.ui.theme.JullMotion
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Lenguaje gráfico de consola de JullHub, dibujado con Canvas: esquinas cortadas, ondas de fondo
 * tipo menú de consola, motivos por familia de consola y marcos de selección con brillo.
 * Todo es vectorial (sin imágenes), barato de dibujar y no depende de recursos externos.
 */

/** Rectángulo con las esquinas superior-izquierda e inferior-derecha cortadas (aspecto de consola). */
class ChamferShape(private val cut: Dp = 14.dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { cut.toPx() }.coerceAtMost(min(size.width, size.height) / 3f)
        val p = Path().apply {
            moveTo(c, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height - c)
            lineTo(size.width - c, size.height)
            lineTo(0f, size.height)
            lineTo(0f, c)
            close()
        }
        return Outline.Generic(p)
    }
}

/** Color de acento global del fondo; la pantalla activa (p. ej. Home) lo cambia según el juego elegido. */
class ConsoleAccent {
    var color: Color by mutableStateOf(Color.Unspecified)
}

val LocalConsoleAccent = staticCompositionLocalOf { ConsoleAccent() }

/**
 * Fondo de la app: degradado teñido por el acento, tres ondas lentas y viñeta. La fase se lee dentro
 * del bloque de dibujo, así la animación solo redibuja (no recompone). Ciclo muy lento (60 s).
 */
@Composable
fun ConsoleBackdrop(modifier: Modifier = Modifier.fillMaxSize(), animate: Boolean = true) {
    val bg = MaterialTheme.colorScheme.background
    val base = LocalConsoleAccent.current.color.takeOrElse { MaterialTheme.colorScheme.primary }
    val accent by animateColorAsState(base, tween(JullMotion.SLOW * 2), label = "accent")
    val phase by rememberInfiniteTransition(label = "waves").animateFloat(
        initialValue = 0f,
        targetValue = if (animate) 1f else 0f,
        animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.verticalGradient(
                listOf(accent.copy(alpha = 0.30f).compositeOver(bg), accent.copy(alpha = 0.08f).compositeOver(bg), bg)
            )
        )
        val step = 28f
        for (i in 0 until 3) {
            val path = Path()
            val baseY = h * (0.55f + i * 0.13f)
            val amp = h * (0.035f + i * 0.012f)
            val dir = if (i % 2 == 0) 1f else -1f
            var x = 0f
            path.moveTo(0f, baseY)
            while (x <= w + step) {
                val y = baseY + amp * sin(((x / w) * (1.2f + i * 0.5f) + phase * dir) * 2f * PI.toFloat())
                path.lineTo(x, y)
                x += step
            }
            drawPath(path, Color.White.copy(alpha = 0.05f + 0.02f * (2 - i)), style = Stroke(width = 2f + i))
            path.lineTo(w, h); path.lineTo(0f, h); path.close()
            drawPath(path, accent.copy(alpha = 0.035f))
        }
        drawRect(
            Brush.radialGradient(
                listOf(Color.Transparent, bg.copy(alpha = 0.65f)),
                center = Offset(w / 2f, h * 0.4f),
                radius = maxOf(w, h) * 0.8f
            )
        )
    }
}

private enum class Family { PLAYSTATION, NINTENDO, OTHER }

private fun Platform.family(): Family = when (this) {
    Platform.PS1, Platform.PS2, Platform.PSP, Platform.PS_VITA -> Family.PLAYSTATION
    Platform.NDS, Platform.N3DS, Platform.N64, Platform.GB_GBC, Platform.GBA,
    Platform.GAMECUBE, Platform.WII, Platform.NES, Platform.SNES -> Family.NINTENDO
    else -> Family.OTHER
}

/**
 * Motivo decorativo de la consola en la esquina superior derecha: símbolos de botones PlayStation,
 * cruceta + botones Nintendo, o anillos para el resto. Mismo trazo y escala para toda la colección.
 */
fun DrawScope.drawConsoleMotif(platform: Platform, color: Color) {
    val u = min(size.width, size.height) * 0.34f
    val cx = size.width - u * 0.75f
    val cy = u * 0.75f
    val s = Stroke(width = (u * 0.07f).coerceAtLeast(1.5f))
    when (platform.family()) {
        Family.PLAYSTATION -> {
            val r = u * 0.2f
            val o = u * 0.42f
            // △ (arriba), ○ (derecha), ✕ (abajo), □ (izquierda)
            val tri = Path().apply {
                moveTo(cx, cy - o - r); lineTo(cx + r, cy - o + r * 0.7f); lineTo(cx - r, cy - o + r * 0.7f); close()
            }
            drawPath(tri, color, style = s)
            drawCircle(color, r, Offset(cx + o, cy), style = s)
            drawLine(color, Offset(cx - r, cy + o - r), Offset(cx + r, cy + o + r), s.width)
            drawLine(color, Offset(cx + r, cy + o - r), Offset(cx - r, cy + o + r), s.width)
            drawRect(color, Offset(cx - o - r, cy - r), Size(r * 2, r * 2), style = s)
        }
        Family.NINTENDO -> {
            val a = u * 0.16f
            val dx = cx - u * 0.35f
            drawLine(color, Offset(dx - a * 1.6f, cy), Offset(dx + a * 1.6f, cy), s.width * 2.4f)
            drawLine(color, Offset(dx, cy - a * 1.6f), Offset(dx, cy + a * 1.6f), s.width * 2.4f)
            drawCircle(color, a, Offset(cx + u * 0.3f, cy - a), style = s)
            drawCircle(color, a, Offset(cx + u * 0.08f, cy + a), style = s)
        }
        Family.OTHER -> {
            for (i in 1..3) drawCircle(color, u * 0.18f * i, Offset(cx, cy), style = s)
        }
    }
}

/** Líneas de esquina ("corchetes") que enmarcan un escenario; refuerzan la estética de interfaz de consola. */
fun DrawScope.drawCornerBrackets(color: Color, length: Float = 28f, width: Float = 3f, inset: Float = 10f) {
    val l = length
    val w = size.width
    val h = size.height
    drawLine(color, Offset(inset, inset + l), Offset(inset, inset), width)
    drawLine(color, Offset(inset, inset), Offset(inset + l, inset), width)
    drawLine(color, Offset(w - inset - l, h - inset), Offset(w - inset, h - inset), width)
    drawLine(color, Offset(w - inset, h - inset), Offset(w - inset, h - inset - l), width)
}
