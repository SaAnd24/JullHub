package com.jullhub.app.data.metadata

import com.jullhub.app.core.model.Game
import com.jullhub.app.data.games.GameRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex

/**
 * Rellena en segundo plano la metadata que falta. Nunca bloquea la UI: lee/escribe solo la caché
 * y consulta la red de forma secuencial, con pausa entre peticiones y un máximo por pasada.
 */
class MetadataSyncManager(
    private val games: GameRepository,
    private val metadata: GameMetadataRepository,
    private val scope: CoroutineScope,
    private val clock: () -> Long = System::currentTimeMillis
) {
    private val running = Mutex()
    private var pausedUntil = 0L

    /** Observa la biblioteca y completa lo que falte. Llamar una vez al arrancar. */
    @OptIn(FlowPreview::class)
    fun start() {
        scope.launch {
            combine(games.observeGames(), metadata.observeAll()) { g, m -> g.map { it.id }.toSet() to m.keys }
                .debounce(DEBOUNCE_MS)
                .collect { syncMissing() }
        }
    }

    /** Pasada manual (p. ej. desde Ajustes, tras guardar la clave). */
    fun syncNow() {
        pausedUntil = 0L
        scope.launch { syncMissing() }
    }

    private suspend fun syncMissing() {
        if (clock() < pausedUntil) return
        if (!running.tryLock()) return
        try {
            if (!metadata.isConfigured()) return
            val known = metadata.observeAll().first()
            val pending: List<Game> = games.observeGames().first()
                .filter { it.id !in known }
                .take(BATCH)
            for (game in pending) {
                when (metadata.refresh(game)) {
                    RefreshOutcome.Unavailable -> { pausedUntil = clock() + BACKOFF_MS; return }
                    RefreshOutcome.NotConfigured -> return
                    else -> delay(PAUSE_MS)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            pausedUntil = clock() + BACKOFF_MS
        } finally {
            running.unlock()
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 2_000L
        const val BATCH = 25
        const val PAUSE_MS = 300L
        const val BACKOFF_MS = 5 * 60 * 1000L
    }
}
