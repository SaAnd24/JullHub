package com.jullhub.app.emulator

import android.content.Context
import com.jullhub.app.core.model.Game

/** Comprueba que la URI de un juego sigue siendo accesible. */
fun interface GameAccess {
    fun isReadable(context: Context, uri: String): Boolean
}

/** Qué hacer tras planificar un lanzamiento. */
sealed interface LaunchPlan {
    /** Todo listo: ejecutar [request] con un `LaunchExecutor`. */
    data class Run(val request: LaunchRequest, val emulatorName: String) : LaunchPlan

    /** No hay nada que ejecutar: mostrar [result] (o pedir elección si es `RequiresSelection`). */
    data class Done(val result: LaunchResult) : LaunchPlan
}

/**
 * Juego → plataforma → emuladores compatibles instalados → los que pueden lanzarlo → elección
 * → [LaunchRequest]. No toca Android más allá de las consultas de los adapters, y puede
 * ejecutarse fuera del hilo principal. Un fallo en un adapter no afecta a los demás.
 */
class GameLauncher(
    private val registry: EmulatorRegistry,
    private val access: GameAccess
) {
    /** Emuladores instalados, compatibles con la consola y capaces de abrir este juego. */
    fun candidates(context: Context, game: Game): List<EmulatorAdapter> =
        registry.installedCompatibleWith(context, game).filter { safe(false) { it.canLaunch(game) } }

    /** @param emulatorId elección del usuario cuando hay varios candidatos (temporal, no se guarda). */
    fun plan(context: Context, game: Game, emulatorId: String? = null): LaunchPlan {
        val installed = registry.installedCompatibleWith(context, game)
        if (installed.isEmpty()) return LaunchPlan.Done(LaunchResult.EmulatorNotInstalled)

        val adapter: EmulatorAdapter = if (emulatorId != null) {
            installed.firstOrNull { it.id == emulatorId }
                ?: return LaunchPlan.Done(LaunchResult.EmulatorNotInstalled)
        } else {
            val launchable = installed.filter { safe(false) { it.canLaunch(game) } }
            when {
                launchable.isEmpty() -> return LaunchPlan.Done(explainRejection(context, game, installed))
                launchable.size == 1 -> launchable.first()
                else -> launchable.firstOrNull { it.id == game.emulatorId }
                    ?: return LaunchPlan.Done(
                        LaunchResult.RequiresSelection(launchable.map { EmulatorChoice(it.id, it.displayName) })
                    )
            }
        }

        val built = try {
            adapter.buildLaunchRequest(context, game)
        } catch (_: Exception) {
            return LaunchPlan.Done(LaunchResult.Failed())
        }
        return when (built) {
            is LaunchBuild.Rejected -> LaunchPlan.Done(built.result)
            is LaunchBuild.Ready -> {
                val reachable = safe(false) {
                    built.request.grantReadUris.all { access.isReadable(context, it) }
                }
                if (reachable) LaunchPlan.Run(built.request, adapter.displayName)
                else LaunchPlan.Done(LaunchResult.InvalidGame("La URI del juego ya no está disponible."))
            }
        }
    }

    /** Hay emuladores instalados pero ninguno puede con este juego: explicar por qué (el primero). */
    private fun explainRejection(context: Context, game: Game, installed: List<EmulatorAdapter>): LaunchResult {
        val first = installed.first()
        val built = try {
            first.buildLaunchRequest(context, game)
        } catch (_: Exception) {
            null
        }
        return (built as? LaunchBuild.Rejected)?.result
            ?: LaunchResult.Unsupported(
                "${first.displayName} está instalado, pero este juego no puede abrirse mediante lanzamiento externo."
            )
    }

    private inline fun <T> safe(default: T, block: () -> T): T =
        try { block() } catch (_: Exception) { default }
}
