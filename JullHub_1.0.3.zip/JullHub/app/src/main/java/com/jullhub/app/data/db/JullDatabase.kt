package com.jullhub.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Base de datos de la biblioteca. Al cambiar el esquema: subir `version` y añadir una [Migration].
 * Nunca usar migraciones destructivas: la biblioteca del usuario no se borra.
 */
@Database(entities = [GameEntity::class, GameMetadataEntity::class], version = 2, exportSchema = false)
abstract class JullDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao
    abstract fun metadataDao(): GameMetadataDao

    companion object {
        /** v1 -> v2: añade la caché de metadata. La tabla `games` no se modifica. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `game_metadata` (" +
                        "`gameId` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`provider` TEXT NOT NULL, " +
                        "`externalId` TEXT, " +
                        "`title` TEXT, " +
                        "`alternativeTitle` TEXT, " +
                        "`platformName` TEXT, " +
                        "`description` TEXT, " +
                        "`releaseDate` TEXT, " +
                        "`developers` TEXT NOT NULL, " +
                        "`publishers` TEXT NOT NULL, " +
                        "`genres` TEXT NOT NULL, " +
                        "`coverUrl` TEXT, " +
                        "`artworkUrl` TEXT, " +
                        "`screenshots` TEXT NOT NULL, " +
                        "`fetchedAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`gameId`))"
                )
            }
        }
    }
}
