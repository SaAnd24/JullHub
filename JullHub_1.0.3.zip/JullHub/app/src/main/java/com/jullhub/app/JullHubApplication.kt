package com.jullhub.app

import android.app.Application
import com.jullhub.app.di.AppContainer

class JullHubApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
