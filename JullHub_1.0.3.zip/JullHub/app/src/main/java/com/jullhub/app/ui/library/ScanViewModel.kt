package com.jullhub.app.ui.library

import androidx.lifecycle.ViewModel
import com.jullhub.app.data.scanner.ScanManager
import com.jullhub.app.data.scanner.ScanState
import kotlinx.coroutines.flow.StateFlow

/** Expone el escaneo de la biblioteca a la UI; compartido por Biblioteca y Configuración. */
class ScanViewModel(private val manager: ScanManager) : ViewModel() {
    val state: StateFlow<ScanState> = manager.state

    fun scan() {
        manager.scan()
    }
}

/** Texto de estado del escaneo, o `null` si no hay nada que mostrar. */
fun ScanState.statusText(): String? = when (this) {
    ScanState.Idle -> null
    ScanState.Scanning -> "Escaneando biblioteca..."
    is ScanState.Finished -> buildString {
        append(if (gamesFound == 1) "1 juego encontrado" else "$gamesFound juegos encontrados")
        if (failedFolders > 0) append(" · $failedFolders carpeta(s) no accesible(s)")
    }
    ScanState.Failed -> "No se pudo completar el escaneo"
}
