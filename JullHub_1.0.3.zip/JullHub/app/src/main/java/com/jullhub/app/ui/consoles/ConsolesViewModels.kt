package com.jullhub.app.ui.consoles

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.games.GameCatalog
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.ui.home.PlatformCount
import com.jullhub.app.core.model.PLATFORM_ORDER
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ConsolesViewModel(catalog: GameCatalog) : ViewModel() {
    val platforms: StateFlow<List<PlatformCount>?> = catalog.observeEntries()
        .map { ConsolesContent.build(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

class PlatformViewModel(
    private val catalog: GameCatalog,
    private val games: GameRepository
) : ViewModel() {
    private val target = MutableStateFlow<Platform?>(null)

    val uiState: StateFlow<PlatformUiState> = combine(target, catalog.observeEntries()) { p, all ->
        if (p == null) PlatformUiState() else PlatformContent.build(p, all)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlatformUiState())

    fun open(platform: Platform) { target.value = platform }

    fun onFavoriteToggle(entry: GameEntry) {
        viewModelScope.launch { games.setFavorite(entry.id, !entry.game.isFavorite) }
    }
}
