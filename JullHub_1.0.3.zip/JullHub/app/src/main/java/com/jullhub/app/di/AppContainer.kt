package com.jullhub.app.di

import android.content.Context
import androidx.room.Room
import com.jullhub.app.data.db.JullDatabase
import com.jullhub.app.data.folders.DataStoreFolderRepository
import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.folders.SafPermissions
import com.jullhub.app.data.games.RoomGameRepository
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.data.games.GameCatalog
import com.jullhub.app.data.metadata.CachedGameMetadataRepository
import com.jullhub.app.data.metadata.GameMetadataRepository
import com.jullhub.app.data.metadata.MetadataProvider
import com.jullhub.app.data.metadata.MetadataSyncManager
import com.jullhub.app.data.metadata.RawgMetadataProvider
import kotlinx.coroutines.flow.first
import com.jullhub.app.data.jullDataStore
import com.jullhub.app.data.scanner.GameScanner
import com.jullhub.app.data.scanner.ScanManager
import com.jullhub.app.data.settings.DataStoreSettingsRepository
import com.jullhub.app.data.settings.SettingsRepository
import com.jullhub.app.emulator.AndroidPackageResolver
import com.jullhub.app.emulator.EmulatorCatalog
import com.jullhub.app.emulator.IntentLaunchExecutor
import com.jullhub.app.emulator.LaunchExecutor
import com.jullhub.app.emulator.SafGameAccess
import com.jullhub.app.emulator.EmulatorRegistry
import com.jullhub.app.emulator.GameLauncher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Inyección manual de dependencias (suficiente para esta fase). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val applicationContext: Context get() = appContext

    val settingsRepository: SettingsRepository =
        DataStoreSettingsRepository(appContext.jullDataStore)

    val folderRepository: FolderRepository = DataStoreFolderRepository(
        context = appContext,
        dataStore = appContext.jullDataStore,
        permissions = SafPermissions(appContext.contentResolver)
    )

    /** Room es la fuente de verdad de la biblioteca; se abre de forma perezosa en la primera consulta. */
    private val database: JullDatabase =
        Room.databaseBuilder(appContext, JullDatabase::class.java, "jullhub.db")
            .addMigrations(JullDatabase.MIGRATION_1_2) // sin migraciones destructivas
            .build()

    val gameRepository: GameRepository = RoomGameRepository(database)

    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Proveedor de metadata (sustituible). La clave la introduce el usuario en Ajustes. */
    private val metadataProvider: MetadataProvider =
        RawgMetadataProvider(apiKey = { settingsRepository.metadataApiKey.first() })
    val metadataRepository: GameMetadataRepository =
        CachedGameMetadataRepository(database.metadataDao(), metadataProvider)
    val gameCatalog = GameCatalog(gameRepository, metadataRepository)
    val metadataSync = MetadataSyncManager(gameRepository, metadataRepository, backgroundScope).also { it.start() }

    val gameScanner = GameScanner(appContext.contentResolver)
    val scanManager = ScanManager(
        folders = folderRepository,
        scanner = gameScanner,
        games = gameRepository,
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    )

    /** Catálogo de emuladores (detección y lanzamiento); ver [EmulatorCatalog]. */
    val emulatorRegistry = EmulatorRegistry(adapters = EmulatorCatalog.adapters(AndroidPackageResolver))
    val gameLauncher = GameLauncher(emulatorRegistry, SafGameAccess)
    val launchExecutor: LaunchExecutor = IntentLaunchExecutor()
}
