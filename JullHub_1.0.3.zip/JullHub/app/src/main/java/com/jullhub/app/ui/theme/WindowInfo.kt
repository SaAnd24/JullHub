package com.jullhub.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Clases de ancho con los mismos umbrales que Material (600dp y 840dp). */
enum class WidthClass { Compact, Medium, Expanded }

@Immutable
data class WindowInfo(val widthDp: Int, val heightDp: Int) {
    val isLandscape: Boolean get() = widthDp > heightDp
    val widthClass: WidthClass
        get() = when {
            widthDp < 600 -> WidthClass.Compact
            widthDp < 840 -> WidthClass.Medium
            else -> WidthClass.Expanded
        }

    /** Ancho mínimo de una carátula en rejillas adaptativas. */
    val coverMinWidth: Dp
        get() = when (widthClass) {
            WidthClass.Compact -> if (isLandscape) 120.dp else 108.dp
            WidthClass.Medium -> 140.dp
            WidthClass.Expanded -> 164.dp
        }

    /** Ancho de las tarjetas en filas horizontales (LazyRow). */
    val rowCardWidth: Dp
        get() = when (widthClass) {
            WidthClass.Compact -> if (isLandscape) 128.dp else 120.dp
            WidthClass.Medium -> 140.dp
            WidthClass.Expanded -> 160.dp
        }

    val contentPadding: Dp get() = if (widthClass == WidthClass.Compact) JullSpacing.lg else JullSpacing.xl
}

@Composable
fun rememberWindowInfo(): WindowInfo {
    val c = LocalConfiguration.current
    return remember(c.screenWidthDp, c.screenHeightDp) { WindowInfo(c.screenWidthDp, c.screenHeightDp) }
}
