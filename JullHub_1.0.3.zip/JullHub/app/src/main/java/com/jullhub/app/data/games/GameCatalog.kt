package com.jullhub.app.data.games

import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.data.metadata.GameMetadataRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/**
 * Une juegos locales (Room `games`) con su metadata en caché (Room `game_metadata`).
 * Sin metadata, el juego aparece igual con sus datos locales.
 */
class GameCatalog(
    private val games: GameRepository,
    private val metadata: GameMetadataRepository
) {
    fun observeEntries(): Flow<List<GameEntry>> =
        combine(games.observeGames(), metadata.observeAll()) { list, meta ->
            list.map { GameEntry(it, meta[it.id]) }
        }
}
