package com.jullhub.app.data.folders

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri

/** Gestiona los permisos persistentes de lectura de SAF. */
class SafPermissions(private val resolver: ContentResolver) {

    fun takeRead(uri: Uri): Boolean = try {
        resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        true
    } catch (_: SecurityException) {
        false
    }

    fun release(uri: Uri) {
        try {
            resolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // El permiso ya no existía; nada que liberar.
        }
    }

    fun hasReadAccess(uri: Uri): Boolean =
        resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
}
