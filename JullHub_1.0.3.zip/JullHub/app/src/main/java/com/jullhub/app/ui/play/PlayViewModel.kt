package com.jullhub.app.ui.play

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.Game
import com.jullhub.app.data.games.GameRepository
import com.jullhub.app.emulator.EmulatorChoice
import com.jullhub.app.emulator.GameLauncher
import com.jullhub.app.emulator.LaunchExecutor
import com.jullhub.app.emulator.LaunchPlan
import com.jullhub.app.emulator.LaunchResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Lo que la UI debe mostrar tras pulsar "Jugar". */
sealed interface PlayEvent {
    data class Message(val text: String) : PlayEvent
    data class ChooseEmulator(val game: Game, val options: List<EmulatorChoice>) : PlayEvent
}

/**
 * Orquesta "Jugar": planifica el lanzamiento fuera del hilo principal, lo ejecuta y, si Android
 * lo acepta, registra la ejecución. La UI no conoce nada de ningún emulador.
 */
class PlayViewModel(
    private val launcher: GameLauncher,
    private val executor: LaunchExecutor,
    private val games: GameRepository,
    private val context: Context
) : ViewModel() {

    private val _events = MutableSharedFlow<PlayEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<PlayEvent> = _events.asSharedFlow()

    private var busy = false

    /** @param emulatorId elección explícita del usuario (solo cuando hay varios candidatos). */
    fun onPlay(game: Game, emulatorId: String? = null) {
        if (busy) return
        busy = true
        viewModelScope.launch {
            try {
                // La comprobación SAF hace I/O; el startActivity se queda en el hilo principal.
                val plan = withContext(Dispatchers.IO) { launcher.plan(context, game, emulatorId) }
                val result: LaunchResult = when (plan) {
                    is LaunchPlan.Run -> executor.execute(context, plan.request)
                    is LaunchPlan.Done -> plan.result
                }
                when (result) {
                    LaunchResult.Started -> {
                        games.markPlayed(game.id)
                        val name = (plan as? LaunchPlan.Run)?.emulatorName
                        _events.emit(PlayEvent.Message(startedMessage(game, name)))
                    }
                    is LaunchResult.RequiresSelection ->
                        _events.emit(PlayEvent.ChooseEmulator(game, result.options))
                    else -> _events.emit(PlayEvent.Message(userMessage(result)))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                _events.emit(PlayEvent.Message("No se pudo abrir el juego."))
            } finally {
                busy = false
            }
        }
    }
}

private fun startedMessage(game: Game, emulatorName: String?): String =
    if (emulatorName != null) "Abriendo ${game.title} con $emulatorName" else "Abriendo ${game.title}"

/** Texto apto para el usuario: sin trazas ni detalles técnicos. */
fun userMessage(result: LaunchResult): String = when (result) {
    LaunchResult.Started -> "Abriendo el juego"
    is LaunchResult.Unsupported -> result.reason
    LaunchResult.EmulatorNotInstalled -> "No hay un emulador compatible instalado."
    is LaunchResult.InvalidGame -> result.reason
    is LaunchResult.Failed -> result.message
    is LaunchResult.RequiresSelection -> "Elige un emulador para abrir el juego."
}
