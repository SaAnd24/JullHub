package com.jullhub.app.data.metadata

import com.jullhub.app.core.model.Platform

/** Candidato devuelto por una búsqueda del proveedor (aún sin detalles). */
data class MetadataCandidate(val externalId: String, val name: String)

/** Detalles de un juego según el proveedor, sin datos locales. */
data class ExternalGame(
    val externalId: String,
    val title: String?,
    val alternativeTitle: String? = null,
    val platformName: String? = null,
    val description: String? = null,
    val releaseDate: String? = null,
    val developers: List<String> = emptyList(),
    val publishers: List<String> = emptyList(),
    val genres: List<String> = emptyList(),
    val coverUrl: String? = null,
    val artworkUrl: String? = null,
    val screenshots: List<String> = emptyList()
)

sealed interface SearchResult {
    data class Candidates(val items: List<MetadataCandidate>) : SearchResult
    /** Sin red, sin clave, límite o error del proveedor. No se guarda nada: se reintentará. */
    data class Unavailable(val reason: String) : SearchResult
}

sealed interface DetailsResult {
    data class Found(val game: ExternalGame) : DetailsResult
    data class Unavailable(val reason: String) : DetailsResult
}

/**
 * Proveedor externo de metadata. El resto de la app solo conoce esta interfaz: cambiar de proveedor
 * es escribir otra implementación y registrarla en el contenedor.
 */
interface MetadataProvider {
    val id: String
    /** `false` si faltan credenciales; entonces ni se intenta consultar. */
    suspend fun isConfigured(): Boolean
    suspend fun search(title: String, platform: Platform): SearchResult
    suspend fun details(candidate: MetadataCandidate): DetailsResult
}
