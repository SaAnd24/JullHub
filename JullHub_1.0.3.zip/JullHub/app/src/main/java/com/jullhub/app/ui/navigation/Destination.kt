package com.jullhub.app.ui.navigation

import android.util.Base64
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector
import com.jullhub.app.core.model.Platform

/** Secciones principales del "sistema operativo": juegos primero, emuladores después. */
enum class Destination(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Inicio", Icons.Rounded.Home),
    Library("library", "Biblioteca", Icons.Rounded.VideoLibrary),
    Consoles("consoles", "Consolas", Icons.Rounded.SportsEsports),
    Emulators("emulators", "Emuladores", Icons.Rounded.Memory),
    Settings("settings", "Ajustes", Icons.Rounded.Settings)
}

/** Pantallas secundarias (sin barra de navegación). */
object Routes {
    const val GAME_ARG = "gameId"
    const val PLATFORM_ARG = "platform"
    const val GAME = "game/{$GAME_ARG}"
    const val PLATFORM = "platform/{$PLATFORM_ARG}"

    /**
     * El id de un juego es una URI `content://` con `%`, `/` y `:`. Se pasa en Base64 URL-safe para
     * que ninguna capa de la navegación lo (de)codifique de más.
     */
    fun game(id: String): String =
        "game/" + Base64.encodeToString(id.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    fun decodeGameId(arg: String): String =
        String(Base64.decode(arg, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8)

    fun platform(platform: Platform): String = "platform/${platform.name}"

    fun isDetail(route: String?): Boolean = route != null && (route.startsWith("game/") || route.startsWith("platform/"))
}
