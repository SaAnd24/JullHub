package com.jullhub.app.data.metadata

/** Listas de texto en una sola columna de Room (separador de unidad ASCII, no aparece en nombres ni URLs). */
object MetadataCodec {
    private const val SEP = '\u001F'
    fun encode(items: List<String>): String = items.filter { it.isNotBlank() }.joinToString(SEP.toString())
    fun decode(value: String): List<String> = if (value.isEmpty()) emptyList() else value.split(SEP).filter { it.isNotBlank() }
}

/** Convierte el HTML básico de las descripciones en texto plano. */
object HtmlText {
    fun strip(html: String?): String? {
        if (html.isNullOrBlank()) return null
        val s = html
            .replace(Regex("""(?i)<\s*br\s*/?>"""), "\n")
            .replace(Regex("""(?i)</\s*p\s*>"""), "\n\n")
            .replace(Regex("""<[^>]+>"""), "")
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
            .replace(Regex("""\n{3,}"""), "\n\n")
            .trim()
        return s.ifEmpty { null }
    }
}
