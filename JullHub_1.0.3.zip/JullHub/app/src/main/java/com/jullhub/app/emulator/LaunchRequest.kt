package com.jullhub.app.emulator

/**
 * Descripción pura (sin clases de Android) de cómo abrir un juego en un emulador.
 * Cada adapter la construye; [IntentLaunchExecutor] es el único que la convierte en un Intent.
 * Así la lógica de cada emulador se puede probar sin dispositivo.
 */
data class LaunchRequest(
    val packageName: String,
    /** Nombre completo de la clase de la Activity (no abreviado). */
    val className: String,
    val action: String? = null,
    /** Valor de `Intent.data`, si el emulador lo usa. */
    val dataUri: String? = null,
    val stringExtras: Map<String, String> = emptyMap(),
    val stringArrayExtras: Map<String, List<String>> = emptyMap(),
    /** URIs `content://` a las que el emulador necesita acceso de lectura (se conceden en el Intent). */
    val grantReadUris: List<String> = emptyList()
)

/** Emulador entre los que el usuario puede elegir. */
data class EmulatorChoice(val id: String, val name: String)

internal const val DEFAULT_LAUNCH_FAILURE = "No se pudo abrir el juego."

/** Resultado explícito de un intento de lanzamiento. Un lanzamiento no soportado es un estado válido, no una excepción. */
sealed interface LaunchResult {
    /** Android aceptó el lanzamiento. */
    data object Started : LaunchResult

    /** El emulador (o el formato del juego) no tiene un método de lanzamiento verificado. */
    data class Unsupported(val reason: String) : LaunchResult

    /** No hay ningún emulador compatible instalado (o el elegido ya no lo está). */
    data object EmulatorNotInstalled : LaunchResult

    /** Al juego le falta algo imprescindible (URI válida, Title ID...). */
    data class InvalidGame(val reason: String) : LaunchResult

    /** Android o el emulador rechazaron el lanzamiento. [message] es apto para mostrar al usuario. */
    data class Failed(val message: String = DEFAULT_LAUNCH_FAILURE) : LaunchResult

    /** Hay varios emuladores válidos: el usuario debe elegir. */
    data class RequiresSelection(val options: List<EmulatorChoice>) : LaunchResult
}

/** Resultado de pedir a un adapter que prepare el lanzamiento. */
sealed interface LaunchBuild {
    data class Ready(val request: LaunchRequest) : LaunchBuild
    data class Rejected(val result: LaunchResult) : LaunchBuild
}
