package com.jullhub.app.data.metadata

import com.jullhub.app.core.model.Platform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Proveedor RAWG (https://rawg.io/apidocs).
 *
 * Verificado en la documentación/fuentes consultadas:
 *  - Autenticación: clave de API en el parámetro `key` de cada petición.
 *  - `GET https://api.rawg.io/api/games?search=...&page_size=N` y `GET https://api.rawg.io/api/games/{id}`.
 *  - Cabecera User-Agent con el nombre de la app; atribución visible a RAWG con enlace.
 *  - Campos del juego: name, released, description, developers, publishers, genres, background_image.
 *
 * NO verificado contra la documentación oficial (su página de docs no es legible sin navegador);
 * por eso se tratan como opcionales y cualquier fallo se ignora sin afectar al resto:
 *  - forma `results[]` de la lista paginada y `name` dentro de developers/publishers/genres;
 *  - `GET /games/{id}/screenshots` con `results[].image` (ruta deducida del nombre de operación del SDK).
 *
 * RAWG no ofrece carátulas verticales: `coverUrl` y `artworkUrl` usan `background_image` (apaisada).
 * La clave la introduce el usuario en Ajustes; nunca se incrusta en el código.
 */
class RawgMetadataProvider(
    private val apiKey: suspend () -> String?
) : MetadataProvider {

    override val id: String = "rawg"

    override suspend fun isConfigured(): Boolean = !apiKey().isNullOrBlank()

    override suspend fun search(title: String, platform: Platform): SearchResult {
        val key = apiKey()?.trim().orEmpty()
        if (key.isEmpty()) return SearchResult.Unavailable("Falta la clave de RAWG")
        return try {
            val url = "$BASE/games?key=${enc(key)}&search=${enc(title)}&page_size=$PAGE_SIZE"
            val results = JSONObject(get(url)).optJSONArray("results") ?: JSONArray()
            val items = buildList {
                for (i in 0 until results.length()) {
                    val o = results.optJSONObject(i) ?: continue
                    val id = o.opt("id")?.toString().orEmpty()
                    val name = o.optString("name")
                    if (id.isNotEmpty() && name.isNotEmpty()) add(MetadataCandidate(id, name))
                }
            }
            SearchResult.Candidates(items)
        } catch (e: IOException) {
            SearchResult.Unavailable("Sin conexión o proveedor no disponible")
        } catch (e: org.json.JSONException) {
            SearchResult.Unavailable("Respuesta no válida del proveedor")
        }
    }

    override suspend fun details(candidate: MetadataCandidate): DetailsResult {
        val key = apiKey()?.trim().orEmpty()
        if (key.isEmpty()) return DetailsResult.Unavailable("Falta la clave de RAWG")
        return try {
            val o = JSONObject(get("$BASE/games/${enc(candidate.externalId)}?key=${enc(key)}"))
            val image = o.optString("background_image").takeIf { it.isNotBlank() && it != "null" }
            DetailsResult.Found(
                ExternalGame(
                    externalId = candidate.externalId,
                    title = o.optString("name").ifBlank { candidate.name },
                    description = HtmlText.strip(o.optString("description")),
                    releaseDate = o.optString("released").takeIf { it.isNotBlank() && it != "null" },
                    developers = names(o.optJSONArray("developers")),
                    publishers = names(o.optJSONArray("publishers")),
                    genres = names(o.optJSONArray("genres")),
                    coverUrl = image,
                    artworkUrl = image,
                    screenshots = screenshots(candidate.externalId, key)
                )
            )
        } catch (e: IOException) {
            DetailsResult.Unavailable("Sin conexión o proveedor no disponible")
        } catch (e: org.json.JSONException) {
            DetailsResult.Unavailable("Respuesta no válida del proveedor")
        }
    }

    /** Opcional: si la ruta o la forma no coinciden, simplemente no hay capturas. */
    private suspend fun screenshots(externalId: String, key: String): List<String> = try {
        val arr = JSONObject(get("$BASE/games/${enc(externalId)}/screenshots?key=${enc(key)}"))
            .optJSONArray("results") ?: JSONArray()
        buildList {
            for (i in 0 until minOf(arr.length(), MAX_SCREENSHOTS)) {
                arr.optJSONObject(i)?.optString("image")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun names(arr: JSONArray?): List<String> = buildList {
        if (arr == null) return@buildList
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("name")?.takeIf { it.isNotBlank() }?.let(::add)
    }

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = TIMEOUT_MS
            conn.readTimeout = TIMEOUT_MS
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private companion object {
        const val BASE = "https://api.rawg.io/api"
        const val USER_AGENT = "JullHub/1.0 (Android personal game launcher)"
        const val PAGE_SIZE = 10
        const val MAX_SCREENSHOTS = 8
        const val TIMEOUT_MS = 10_000
    }
}
