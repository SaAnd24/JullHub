package com.jullhub.app.ui

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import com.jullhub.app.ui.components.ConsoleAccent
import com.jullhub.app.ui.components.ConsoleBackdrop
import com.jullhub.app.ui.components.LocalConsoleAccent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.settings.AppOrientation
import com.jullhub.app.data.settings.ThemeMode
import com.jullhub.app.ui.consoles.ConsolesScreen
import com.jullhub.app.ui.consoles.PlatformScreen
import com.jullhub.app.ui.details.GameDetailsScreen
import com.jullhub.app.ui.emulators.EmulatorsScreen
import com.jullhub.app.ui.home.HomeScreen
import com.jullhub.app.ui.library.LibraryScreen
import com.jullhub.app.ui.navigation.Destination
import com.jullhub.app.ui.navigation.Routes
import com.jullhub.app.ui.settings.SettingsScreen
import com.jullhub.app.ui.settings.SettingsViewModel
import com.jullhub.app.ui.theme.JullHubTheme
import com.jullhub.app.ui.theme.JullMotion
import com.jullhub.app.ui.theme.rememberWindowInfo

@Composable
fun JullHubApp() {
    val factory = rememberViewModelFactory()
    val settingsVm: SettingsViewModel = viewModel(factory = factory)
    val themeMode by settingsVm.themeMode.collectAsStateWithLifecycle()
    val orientation by settingsVm.orientation.collectAsStateWithLifecycle()
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    // Orientación elegida en Ajustes (Automática por defecto: sigue al sensor del dispositivo).
    val activity = LocalContext.current.findActivity()
    LaunchedEffect(orientation, activity) {
        activity?.requestedOrientation = when (orientation) {
            AppOrientation.AUTO -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            AppOrientation.PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            AppOrientation.LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    val consoleAccent = remember { ConsoleAccent() }
    JullHubTheme(darkTheme = dark) {
      CompositionLocalProvider(LocalConsoleAccent provides consoleAccent) {
        // Fondo de consola dibujado con Canvas detrás de todo; las pantallas son transparentes.
        Box(Modifier.fillMaxSize()) {
        ConsoleBackdrop()
        val navController = rememberNavController()
        val snackbarHostState = remember { SnackbarHostState() }
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = backStackEntry?.destination
        val window = rememberWindowInfo()
        val showChrome = !Routes.isDetail(currentDestination?.route)

        fun navigateTo(destination: Destination) {
            navController.navigate(destination.route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
        fun isSelected(destination: Destination) =
            currentDestination?.hierarchy?.any { it.route == destination.route } == true

        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                // Vertical: navegación táctil inferior.
                if (showChrome && !window.isLandscape) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.92f)) {
                        Destination.entries.forEach { destination ->
                            NavigationBarItem(
                                selected = isSelected(destination),
                                onClick = { navigateTo(destination) },
                                icon = { Icon(destination.icon, contentDescription = null) },
                                label = { Text(destination.label) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Row(Modifier.padding(padding)) {
                // Horizontal: riel lateral compacto, como el menú de una consola.
                if (showChrome && window.isLandscape) {
                    NavigationRail(containerColor = Color.Transparent) {
                        Destination.entries.forEach { destination ->
                            NavigationRailItem(
                                selected = isSelected(destination),
                                onClick = { navigateTo(destination) },
                                icon = { Icon(destination.icon, contentDescription = null) },
                                label = { Text(destination.label) }
                            )
                        }
                    }
                }
                NavHost(
                    navController = navController,
                    startDestination = Destination.Home.route,
                    modifier = Modifier.weight(1f),
                    enterTransition = { fadeIn(tween(JullMotion.NORMAL)) },
                    exitTransition = { fadeOut(tween(JullMotion.FAST)) },
                    popEnterTransition = { fadeIn(tween(JullMotion.NORMAL)) },
                    popExitTransition = { fadeOut(tween(JullMotion.FAST)) }
                ) {
                    val openGame = { id: String -> navController.navigate(Routes.game(id)) }
                    val openPlatform = { p: Platform -> navController.navigate(Routes.platform(p)) }

                    composable(Destination.Home.route) {
                        HomeScreen(
                            factory = factory,
                            onOpenLibrary = { navigateTo(Destination.Library) },
                            onOpenGame = { openGame(it.id) },
                            onOpenPlatform = openPlatform,
                            snackbarHostState = snackbarHostState
                        )
                    }
                    composable(Destination.Library.route) {
                        LibraryScreen(factory, snackbarHostState, onOpenGame = { openGame(it.id) })
                    }
                    composable(Destination.Consoles.route) {
                        ConsolesScreen(factory, onOpenPlatform = openPlatform)
                    }
                    composable(Destination.Emulators.route) {
                        EmulatorsScreen(factory)
                    }
                    composable(Destination.Settings.route) {
                        SettingsScreen(factory, snackbarHostState)
                    }
                    composable(
                        route = Routes.GAME,
                        arguments = listOf(navArgument(Routes.GAME_ARG) { type = NavType.StringType })
                    ) { entry ->
                        val id = entry.arguments?.getString(Routes.GAME_ARG)
                            ?.let { runCatching { Routes.decodeGameId(it) }.getOrNull() }
                        if (id != null) {
                            GameDetailsScreen(id, factory, snackbarHostState, onBack = { navController.popBackStack() })
                        }
                    }
                    composable(
                        route = Routes.PLATFORM,
                        arguments = listOf(navArgument(Routes.PLATFORM_ARG) { type = NavType.StringType })
                    ) { entry ->
                        val platform = entry.arguments?.getString(Routes.PLATFORM_ARG)
                            ?.let { name -> Platform.entries.firstOrNull { it.name == name } }
                        if (platform != null) {
                            PlatformScreen(
                                platform = platform,
                                factory = factory,
                                snackbarHostState = snackbarHostState,
                                onBack = { navController.popBackStack() },
                                onOpenGame = { openGame(it.id) }
                            )
                        }
                    }
                }
            }
        }
        }
      }
    }
}

private fun android.content.Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
