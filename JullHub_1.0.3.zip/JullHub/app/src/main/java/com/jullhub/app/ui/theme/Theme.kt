package com.jullhub.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

// Identidad: tinta índigo profunda con violeta suave como acento principal.
// Si quieres alinearla con la app de música, basta con ajustar estos valores.
private val DarkColors = darkColorScheme(
    primary = Color(0xFFBFB0FF),
    onPrimary = Color(0xFF2A1B63),
    primaryContainer = Color(0xFF3F2F85),
    onPrimaryContainer = Color(0xFFE4DDFF),
    secondary = Color(0xFF6FE0CB),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF0F4F46),
    onSecondaryContainer = Color(0xFFB3F5E9),
    tertiary = Color(0xFFFF9DB0),
    onTertiary = Color(0xFF5B1228),
    background = Color(0xFF0C0A15),
    onBackground = Color(0xFFE8E3F5),
    surface = Color(0xFF0C0A15),
    onSurface = Color(0xFFE8E3F5),
    surfaceVariant = Color(0xFF2B2640),
    onSurfaceVariant = Color(0xFFC8C1DD),
    outline = Color(0xFF928BA8),
    outlineVariant = Color(0xFF3A3452),
    surfaceContainerLowest = Color(0xFF08060F),
    surfaceContainerLow = Color(0xFF131020),
    surfaceContainer = Color(0xFF181427),
    surfaceContainerHigh = Color(0xFF282340),
    surfaceContainerHighest = Color(0xFF332D4D)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5A47B8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE4DDFF),
    onPrimaryContainer = Color(0xFF190B52),
    secondary = Color(0xFF006B5E),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFB3F5E9),
    onSecondaryContainer = Color(0xFF00201B),
    tertiary = Color(0xFFA13A55),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFCF8FF),
    onBackground = Color(0xFF1C1A27),
    surface = Color(0xFFFCF8FF),
    onSurface = Color(0xFF1C1A27),
    surfaceVariant = Color(0xFFE6E0F5),
    onSurfaceVariant = Color(0xFF48445A),
    outline = Color(0xFF79748C),
    outlineVariant = Color(0xFFCAC4DB),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF6F1FF),
    surfaceContainer = Color(0xFFF0EAFB),
    surfaceContainerHigh = Color(0xFFEAE4F5),
    surfaceContainerHighest = Color(0xFFE4DEF0)
)

private val JullShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun JullHubTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
            controller.isAppearanceLightNavigationBars = !darkTheme
        }
    }
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = JullTypography,
        shapes = JullShapes,
        content = content
    )
}
