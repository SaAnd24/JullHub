package com.jullhub.app.data.scanner

import com.jullhub.app.core.model.Platform

/**
 * Decide qué archivos son juegos y a qué plataformas puede pertenecer cada extensión.
 *
 * Para soportar un formato nuevo basta con añadir su extensión a la plataforma
 * correspondiente en [platformExtensions] (o una plataforma nueva con sus extensiones).
 */
class GameFileFilter(
    platformExtensions: Map<Platform, Set<String>> = DEFAULT_EXTENSIONS
) {
    /** extensión (minúsculas, sin punto) -> plataformas que la usan. */
    private val byExtension: Map<String, Set<Platform>> = buildMap<String, MutableSet<Platform>> {
        platformExtensions.forEach { (platform, extensions) ->
            extensions.forEach { ext -> getOrPut(ext.lowercase()) { linkedSetOf() }.add(platform) }
        }
    }

    fun isGameFile(extension: String): Boolean = extension.lowercase() in byExtension

    /** Plataformas posibles para la extensión; vacío si no es un formato conocido. */
    fun platformsFor(extension: String): Set<Platform> = byExtension[extension.lowercase()].orEmpty()

    /**
     * Archivos auxiliares que no son un juego por sí mismos y evitan duplicados:
     * - `Juego.bin` junto a `Juego.cue` (también `Juego (Track 1).bin`).
     * - Pistas `.bin` que acompañan a un `.gdi` de Dreamcast.
     */
    fun isCompanionFile(fileName: String, extension: String, siblingsLowercase: Set<String>): Boolean {
        if (!extension.equals("bin", ignoreCase = true)) return false
        if (siblingsLowercase.any { it.endsWith(".gdi") }) return true
        val base = fileName.dropLast(extension.length + 1).lowercase()
        if ("$base.cue" in siblingsLowercase) return true
        val trackBase = TRACK_SUFFIX.matchEntire(base)?.groupValues?.get(1)
        return trackBase != null && "$trackBase.cue" in siblingsLowercase
    }

    companion object {
        private val TRACK_SUFFIX = Regex("""^(.*?)\s*\(track\s*\d+\)$""")

        val DEFAULT_EXTENSIONS: Map<Platform, Set<String>> = mapOf(
            Platform.PS1 to setOf("iso", "bin", "cue", "chd", "pbp"),
            Platform.PS2 to setOf("iso", "bin", "cue", "chd"),
            Platform.PSP to setOf("iso", "cso", "pbp", "chd"),
            Platform.PS_VITA to setOf("vpk"),
            Platform.NDS to setOf("nds"),
            Platform.N3DS to setOf("3ds", "3dsx", "cia"),
            Platform.GB_GBC to setOf("gb", "gbc"),
            Platform.GBA to setOf("gba"),
            Platform.NES to setOf("nes"),
            Platform.SNES to setOf("sfc", "smc"),
            Platform.N64 to setOf("n64", "z64", "v64"),
            Platform.GAMECUBE to setOf("iso", "gcm", "rvz"),
            Platform.WII to setOf("iso", "wbfs", "rvz"),
            Platform.DREAMCAST to setOf("cdi", "gdi", "chd")
        )
    }
}
