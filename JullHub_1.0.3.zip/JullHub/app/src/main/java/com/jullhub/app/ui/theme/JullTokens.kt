package com.jullhub.app.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.ui.unit.dp

/** Tokens de diseño de JullHub: un único sitio para espaciado, radios y movimiento. */
object JullSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

object JullRadius {
    val card = 14.dp
    val hero = 24.dp
    val chip = 999.dp
}

/** Movimiento: corto, suave y consistente. Nada de efectos pesados continuos. */
object JullMotion {
    const val FAST = 140
    const val NORMAL = 240
    const val SLOW = 360
    val Emphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    /** Ampliación al recibir foco o pulsación. */
    const val FOCUS_SCALE = 1.06f
}
