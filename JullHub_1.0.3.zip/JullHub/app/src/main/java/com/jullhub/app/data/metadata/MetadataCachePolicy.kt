package com.jullhub.app.data.metadata

import com.jullhub.app.core.model.GameMetadata
import com.jullhub.app.core.model.MetadataStatus

/** Cuándo hay que consultar al proveedor. La UI nunca decide esto: siempre lee la caché. */
object MetadataCachePolicy {
    const val RETRY_AFTER_MILLIS: Long = 7L * 24 * 60 * 60 * 1000

    fun needsLookup(existing: GameMetadata?, now: Long, force: Boolean = false): Boolean = when {
        existing == null -> true
        force -> true
        existing.status == MetadataStatus.MATCHED -> false
        else -> now - existing.fetchedAt >= RETRY_AFTER_MILLIS
    }

    /**
     * Resultado a guardar tras una consulta que NO encontró coincidencia fiable.
     * Si ya había metadata válida (p. ej. refresco manual), se conserva la anterior.
     */
    fun keepPreviousIfMatched(existing: GameMetadata?, fresh: GameMetadata): GameMetadata =
        if (existing != null && existing.isMatched && !fresh.isMatched) existing else fresh
}
