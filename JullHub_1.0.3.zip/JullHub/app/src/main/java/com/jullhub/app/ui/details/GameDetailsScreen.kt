package com.jullhub.app.ui.details

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.util.RelativeTime
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.MutedText
import com.jullhub.app.ui.components.PlatformArt
import com.jullhub.app.ui.components.PlatformChip
import com.jullhub.app.ui.components.RemoteImage
import com.jullhub.app.ui.play.PlayViewModel
import com.jullhub.app.ui.play.rememberPlayAction
import com.jullhub.app.ui.theme.JullMotion
import com.jullhub.app.ui.theme.JullRadius
import com.jullhub.app.ui.theme.JullSpacing
import com.jullhub.app.ui.theme.rememberWindowInfo

/**
 * Página del juego. El lanzamiento reutiliza [PlayViewModel]: aquí no hay lógica de emuladores.
 * Sin metadata se muestra igual el contenido local, con "Información adicional no disponible".
 */
@Composable
fun GameDetailsScreen(
    gameId: String,
    factory: ViewModelProvider.Factory,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    vm: GameDetailsViewModel = viewModel(key = "game:$gameId", factory = factory),
    playVm: PlayViewModel = viewModel(factory = factory)
) {
    LaunchedEffect(gameId) { vm.open(gameId) }
    val state by vm.uiState.collectAsStateWithLifecycle()
    val play = rememberPlayAction(playVm, snackbarHostState)
    val entry = state.entry

    when {
        state.isLoading -> Box(Modifier.fillMaxSize())
        entry == null -> Box(Modifier.fillMaxSize()) {
            BackButton(onBack, Modifier.align(Alignment.TopStart))
            EmptyState(
                icon = Icons.Rounded.PlayArrow,
                title = "Este juego ya no está en tu biblioteca",
                body = "Puede que se haya eliminado la carpeta o el archivo. Vuelve a escanear para actualizar.",
                modifier = Modifier.align(Alignment.Center)
            )
        }
        else -> DetailsContent(
            entry = entry,
            fetch = state.fetch,
            onBack = onBack,
            onPlay = { play(entry.game) },
            onFavorite = { vm.onFavoriteToggle(entry) },
            onRetry = { vm.refreshMetadata(force = true) }
        )
    }
}

@Composable
private fun BackButton(onBack: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(onClick = onBack, modifier = modifier.padding(JullSpacing.sm)) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Volver")
    }
}

@Composable
private fun DetailsContent(
    entry: GameEntry,
    fetch: MetadataFetch,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onRetry: () -> Unit
) {
    val window = rememberWindowInfo()
    val bg = MaterialTheme.colorScheme.background
    Box(Modifier.fillMaxSize()) {
        // Fondo: artwork atenuado con degradado. La lectura manda: nunca se pinta a plena intensidad.
        RemoteImage(
            url = entry.artworkUrl,
            contentDescription = null,
            modifier = Modifier.fillMaxWidth().height(if (window.isLandscape) 260.dp else 340.dp),
            alpha = 0.55f
        ) { Box(Modifier.fillMaxSize()) }
        Box(
            Modifier.fillMaxWidth().height(if (window.isLandscape) 260.dp else 340.dp).background(
                Brush.verticalGradient(listOf(bg.copy(alpha = 0.35f), bg))
            )
        )

        if (window.isLandscape) {
            Row(
                Modifier.fillMaxSize().padding(horizontal = window.contentPadding),
                horizontalArrangement = Arrangement.spacedBy(JullSpacing.xl)
            ) {
                Column(
                    Modifier.width(210.dp).fillMaxSize().verticalScroll(rememberScrollState()).padding(top = JullSpacing.xxl),
                    verticalArrangement = Arrangement.spacedBy(JullSpacing.md)
                ) {
                    Cover(entry, Modifier.fillMaxWidth())
                    Actions(entry, onPlay, onFavorite)
                }
                Column(
                    Modifier.weight(1f).fillMaxSize().verticalScroll(rememberScrollState())
                        .padding(top = JullSpacing.xxl, bottom = JullSpacing.xl),
                    verticalArrangement = Arrangement.spacedBy(JullSpacing.lg)
                ) {
                    Info(entry, fetch, onRetry)
                }
            }
            BackButton(onBack, Modifier.align(Alignment.TopStart))
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = window.contentPadding).padding(top = 56.dp, bottom = JullSpacing.xl),
                verticalArrangement = Arrangement.spacedBy(JullSpacing.lg)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(JullSpacing.lg), verticalAlignment = Alignment.Bottom) {
                    Cover(entry, Modifier.width(128.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(JullSpacing.sm)) { Header(entry) }
                }
                Actions(entry, onPlay, onFavorite)
                Info(entry, fetch, onRetry, showHeader = false)
            }
            BackButton(onBack, Modifier.align(Alignment.TopStart))
        }
    }
}

@Composable
private fun Cover(entry: GameEntry, modifier: Modifier = Modifier) {
    RemoteImage(
        url = entry.coverUrl,
        contentDescription = "Portada de ${entry.displayTitle}",
        modifier = modifier.aspectRatio(3f / 4f).clip(RoundedCornerShape(JullRadius.card))
    ) {
        PlatformArt(entry.game.platform, Modifier.fillMaxSize(), watermark = false) {
            Text(entry.displayTitle.take(1).uppercase(), style = MaterialTheme.typography.displaySmall, color = Color.White)
        }
    }
}

@Composable
private fun Header(entry: GameEntry) {
    Text(entry.displayTitle, style = MaterialTheme.typography.headlineMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
    Row(horizontalArrangement = Arrangement.spacedBy(JullSpacing.sm), verticalAlignment = Alignment.CenterVertically) {
        PlatformChip(entry.game.platform)
        Text(entry.game.platform.displayName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Actions(entry: GameEntry, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Button(onClick = onPlay, modifier = Modifier.fillMaxWidth().height(52.dp)) {
        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
        Spacer(Modifier.size(JullSpacing.sm))
        Text("JUGAR", style = MaterialTheme.typography.titleMedium)
    }
    OutlinedButton(onClick = onFavorite, modifier = Modifier.fillMaxWidth()) {
        Icon(
            if (entry.game.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            contentDescription = null,
            tint = if (entry.game.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.size(JullSpacing.sm))
        Text(if (entry.game.isFavorite) "En favoritos" else "Añadir a favoritos")
    }
}

@Composable
private fun Info(entry: GameEntry, fetch: MetadataFetch, onRetry: () -> Unit, showHeader: Boolean = true) {
    val meta = entry.metadata?.takeIf { it.isMatched }
    if (showHeader) Header(entry)

    // La metadata aparece con un fundido discreto cuando llega.
    AnimatedVisibility(visible = meta != null, enter = fadeIn(tween(JullMotion.NORMAL))) {
        if (meta != null) Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.lg)) {
            FactsRow(
                "Género" to meta.genres.joinToString(", "),
                "Lanzamiento" to meta.releaseDate.orEmpty(),
                "Desarrollador" to meta.developers.joinToString(", "),
                "Publisher" to meta.publishers.joinToString(", ")
            )
            meta.description?.let { ExpandableText(it) }
            if (meta.screenshots.isNotEmpty()) {
                Text("Capturas", style = MaterialTheme.typography.titleMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
                    items(meta.screenshots, key = { it }) { url ->
                        RemoteImage(
                            url = url,
                            contentDescription = "Captura de ${entry.displayTitle}",
                            modifier = Modifier.width(240.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(JullRadius.card))
                        ) { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh)) }
                    }
                }
            }
        }
    }

    if (meta == null) MetadataNotice(fetch, onRetry)

    HorizontalDivider()
    LocalInfo(entry)

    if (meta != null) {
        val uri = LocalUriHandler.current
        TextButton(onClick = { uri.openUri("https://rawg.io") }) { Text("Datos e imágenes: RAWG") }
    }
}

/** Mensaje claro y sin tecnicismos cuando no hay metadata. El juego sigue siendo jugable. */
@Composable
private fun MetadataNotice(fetch: MetadataFetch, onRetry: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.sm)) {
        when (fetch) {
            MetadataFetch.LOADING -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(JullSpacing.sm)) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                MutedText("Buscando información del juego...")
            }
            MetadataFetch.NOT_CONFIGURED -> {
                Text("Información adicional no disponible", style = MaterialTheme.typography.titleMedium)
                MutedText("Añade tu clave de RAWG en Ajustes para obtener portadas y descripciones.")
            }
            MetadataFetch.UNAVAILABLE -> {
                Text("Información adicional no disponible", style = MaterialTheme.typography.titleMedium)
                MutedText("No se pudo consultar el proveedor ahora mismo. Puedes jugar igualmente.")
                TextButton(onClick = onRetry) { Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.size(6.dp)); Text("Reintentar") }
            }
            MetadataFetch.IDLE -> {
                Text("Información adicional no disponible", style = MaterialTheme.typography.titleMedium)
                MutedText("No se encontró una coincidencia fiable para este juego.")
                TextButton(onClick = onRetry) { Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.size(6.dp)); Text("Buscar de nuevo") }
            }
        }
    }
}

@Composable
private fun FactsRow(vararg facts: Pair<String, String>) {
    val shown = facts.filter { it.second.isNotBlank() }
    if (shown.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.sm)) {
        shown.forEach { (label, value) ->
            Row {
                Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(112.dp))
                Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ExpandableText(text: String) {
    var expanded by remember(text) { mutableStateOf(false) }
    Column {
        Text(text, style = MaterialTheme.typography.bodyLarge, maxLines = if (expanded) Int.MAX_VALUE else 6, overflow = TextOverflow.Ellipsis)
        if (text.length > 280) TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Ver menos" else "Ver más") }
    }
}

@Composable
private fun LocalInfo(entry: GameEntry) {
    val g = entry.game
    Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.xs)) {
        Text("En tu biblioteca", style = MaterialTheme.typography.titleMedium)
        g.fileName?.let { MutedText("Archivo: $it") }
        MutedText(
            g.lastPlayedAt?.let { "Última vez: ${RelativeTime.format(System.currentTimeMillis(), it)}" } ?: "Aún no lo has jugado"
        )
        if (g.playCount > 0) MutedText(if (g.playCount == 1) "1 partida" else "${g.playCount} partidas")
    }
}
