package com.jullhub.app.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.Platform
import com.jullhub.app.core.util.RelativeTime
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.PlatformArt
import com.jullhub.app.ui.components.PlatformCard
import com.jullhub.app.ui.components.PlatformChip
import com.jullhub.app.ui.components.RemoteImage
import com.jullhub.app.ui.components.SectionHeader
import com.jullhub.app.ui.components.consoleSelectable
import com.jullhub.app.ui.play.PlayViewModel
import com.jullhub.app.ui.play.rememberPlayAction
import com.jullhub.app.ui.theme.JullMotion
import com.jullhub.app.ui.theme.JullRadius
import com.jullhub.app.ui.theme.JullSpacing
import com.jullhub.app.ui.theme.WindowInfo
import com.jullhub.app.ui.theme.rememberWindowInfo

@Composable
fun HomeScreen(
    factory: ViewModelProvider.Factory,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit,
    snackbarHostState: SnackbarHostState,
    vm: HomeViewModel = viewModel(factory = factory),
    playVm: PlayViewModel = viewModel(factory = factory)
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val play = rememberPlayAction(playVm, snackbarHostState)
    val window = rememberWindowInfo()

    when {
        state.isLoading -> Box(Modifier.fillMaxSize())
        !state.hasGames -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Rounded.VideoLibrary,
                title = "Tu consola está vacía",
                body = "Añade la carpeta donde guardas tus juegos. JullHub no los copia ni los mueve.",
                actionLabel = "Añadir carpeta de juegos",
                onAction = onOpenLibrary
            )
        }
        window.isLandscape -> LandscapeHome(state, window, play, onOpenLibrary, onOpenGame, onOpenPlatform)
        else -> PortraitHome(state, window, play, onOpenLibrary, onOpenGame, onOpenPlatform)
    }
}

@Composable
private fun PortraitHome(
    state: HomeUiState,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = JullSpacing.xl),
        verticalArrangement = Arrangement.spacedBy(JullSpacing.xl)
    ) {
        state.hero?.let { hero ->
            item(key = "hero") {
                HeroBanner(
                    hero = hero,
                    onPlay = { onPlay(hero.entry.game) },
                    onDetails = { onOpenGame(hero.entry) },
                    modifier = Modifier
                        .padding(horizontal = window.contentPadding)
                        .padding(top = JullSpacing.sm)
                        .fillMaxWidth()
                        .height(360.dp)
                )
            }
        }
        homeSections(state, window, onPlay, onOpenLibrary, onOpenGame, onOpenPlatform)
    }
}

@Composable
private fun LandscapeHome(
    state: HomeUiState,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit
) {
    // Dashboard: Hero ancho a la izquierda, estantes a la derecha. No es el portrait estirado.
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = window.contentPadding, vertical = JullSpacing.sm),
        horizontalArrangement = Arrangement.spacedBy(JullSpacing.xl)
    ) {
        state.hero?.let { hero ->
            HeroBanner(
                hero = hero,
                onPlay = { onPlay(hero.entry.game) },
                onDetails = { onOpenGame(hero.entry) },
                modifier = Modifier.weight(0.9f).fillMaxHeight(),
                wide = true
            )
        }
        LazyColumn(
            modifier = Modifier.weight(1.1f).fillMaxHeight(),
            contentPadding = PaddingValues(bottom = JullSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(JullSpacing.xl)
        ) {
            homeSections(state, window, onPlay, onOpenLibrary, onOpenGame, onOpenPlatform, inset = 0.dp)
        }
    }
}

private fun LazyListScope.homeSections(
    state: HomeUiState,
    window: WindowInfo,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenGame: (GameEntry) -> Unit,
    onOpenPlatform: (Platform) -> Unit,
    inset: androidx.compose.ui.unit.Dp = window.contentPadding
) {
    gameRow("continue", "Continuar jugando", state.continuePlaying, window, inset, onPlay, onOpenGame)
    gameRow("recent", "Recientes", state.recent, window, inset, onPlay, onOpenGame)
    gameRow("favorites", "Favoritos", state.favorites, window, inset, onPlay, onOpenGame)
    gameRow("added", "Añadidos recientemente", state.recentlyAdded, window, inset, onPlay, onOpenGame)

    if (state.platforms.isNotEmpty()) {
        item(key = "consoles") {
            Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
                SectionHeader("Mis consolas", inset = inset)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = inset),
                    horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)
                ) {
                    items(state.platforms, key = { it.platform.name }) { entry ->
                        PlatformCard(
                            platform = entry.platform,
                            count = entry.count,
                            modifier = Modifier.width(if (window.isLandscape) 168.dp else 180.dp),
                            onClick = { onOpenPlatform(entry.platform) }
                        )
                    }
                }
            }
        }
    }
    item(key = "library") {
        FilledTonalButton(
            onClick = onOpenLibrary,
            modifier = Modifier.padding(horizontal = inset).fillMaxWidth()
        ) {
            Icon(Icons.Rounded.VideoLibrary, contentDescription = null)
            Spacer(Modifier.size(JullSpacing.sm))
            Text("Toda mi biblioteca (${state.totalCount})")
        }
    }
}

/** Fila horizontal de juegos; no se emite si está vacía (no hay secciones vacías). */
private fun LazyListScope.gameRow(
    key: String,
    title: String,
    entries: List<GameEntry>,
    window: WindowInfo,
    inset: androidx.compose.ui.unit.Dp,
    onPlay: (com.jullhub.app.core.model.Game) -> Unit,
    onOpenGame: (GameEntry) -> Unit
) {
    if (entries.isEmpty()) return
    item(key = key) {
        Column(verticalArrangement = Arrangement.spacedBy(JullSpacing.md)) {
            SectionHeader(title, inset = inset)
            LazyRow(
                contentPadding = PaddingValues(horizontal = inset),
                horizontalArrangement = Arrangement.spacedBy(JullSpacing.md)
            ) {
                items(entries, key = { it.id }) { entry ->
                    GameCard(
                        entry = entry,
                        modifier = Modifier.width(window.rowCardWidth),
                        onClick = { onOpenGame(entry) },
                        onPlayClick = { onPlay(entry.game) }
                    )
                }
            }
        }
    }
}

/** Elemento dominante de la Home: artwork a sangre, título grande y acciones "Jugar" / "Detalles". */
@Composable
private fun HeroBanner(
    hero: Hero,
    onPlay: () -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier,
    wide: Boolean = false
) {
    val shape = RoundedCornerShape(JullRadius.hero)
    val scrim = MaterialTheme.colorScheme.background
    // Crossfade corto al cambiar de juego (p. ej. tras jugar): transición discreta, no un efecto continuo.
    AnimatedContent(
        targetState = hero,
        contentKey = { it.entry.id },
        transitionSpec = { fadeIn(tween(JullMotion.NORMAL)) togetherWith fadeOut(tween(JullMotion.FAST)) },
        modifier = modifier.clip(shape),
        label = "hero"
    ) { current ->
        val entry = current.entry
        Box(Modifier.fillMaxSize()) {
            RemoteImage(
                url = entry.artworkUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize()
            ) { PlatformArt(entry.game.platform, Modifier.fillMaxSize()) }
            // Degradado para que el texto siempre sea legible, con o sin artwork.
            Box(
                Modifier.fillMaxSize().background(
                    if (wide) Brush.horizontalGradient(listOf(scrim.copy(alpha = 0.92f), scrim.copy(alpha = 0.35f)))
                    else Brush.verticalGradient(listOf(Color.Transparent, scrim.copy(alpha = 0.55f), scrim.copy(alpha = 0.96f)))
                )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(if (wide) 0.85f else 1f)
                    .padding(JullSpacing.xl),
                verticalArrangement = Arrangement.spacedBy(JullSpacing.sm)
            ) {
                Text(
                    current.reason.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    entry.displayTitle,
                    style = MaterialTheme.typography.headlineLarge,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(JullSpacing.sm)) {
                    PlatformChip(entry.game.platform)
                    Text(
                        text = heroInfo(entry),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(JullSpacing.md),
                    modifier = Modifier.padding(top = JullSpacing.sm)
                ) {
                    Button(onClick = onPlay) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.size(JullSpacing.xs))
                        Text("Jugar")
                    }
                    FilledTonalButton(onClick = onDetails) { Text("Detalles") }
                }
            }
        }
    }
}

private fun heroInfo(entry: GameEntry): String {
    val g = entry.game
    val parts = buildList {
        entry.metadata?.takeIf { it.isMatched }?.genres?.firstOrNull()?.let(::add)
        g.lastPlayedAt?.let { add(RelativeTime.format(System.currentTimeMillis(), it)) }
        if (g.playCount > 0) add(if (g.playCount == 1) "1 partida" else "${g.playCount} partidas")
    }
    return parts.joinToString(" · ")
}
