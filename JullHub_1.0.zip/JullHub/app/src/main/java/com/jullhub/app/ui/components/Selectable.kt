package com.jullhub.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.jullhub.app.ui.theme.JullMotion

/**
 * Estado de selección de JullHub: al recibir foco (mando, teclado) o pulsación (táctil) el elemento
 * se amplía, gana elevación y un borde luminoso. Usa `clickable`, que ya es enfocable, por lo que la
 * navegación futura por mando/teclado funciona sin rehacer la UI.
 * La animación se lee dentro de `graphicsLayer`: no provoca recomposiciones.
 */
@Composable
fun Modifier.consoleSelectable(
    shape: Shape,
    onClickLabel: String? = null,
    onClick: () -> Unit
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (focused || pressed) JullMotion.FOCUS_SCALE else 1f,
        tween(JullMotion.FAST), label = "selectScale"
    )
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(JullMotion.FAST), label = "selectGlow")
    val primary = MaterialTheme.colorScheme.primary
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
            shadowElevation = glow * 24f
            this.shape = shape
            clip = false
        }
        .border(2.dp, primary.copy(alpha = glow), shape)
        .clip(shape)
        .clickable(
            interactionSource = interaction,
            indication = LocalIndication.current,
            onClickLabel = onClickLabel,
            onClick = onClick
        )
}
