package com.jullhub.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.ui.theme.JullRadius
import com.jullhub.app.ui.theme.JullSpacing

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    /** Margen lateral; debe coincidir con el `contentPadding` de la fila que acompaña. */
    inset: androidx.compose.ui.unit.Dp = JullSpacing.lg
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = inset),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (actionLabel != null && onAction != null) TextButton(onClick = onAction) { Text(actionLabel) }
    }
}

@Composable
fun MutedText(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
    )
}

/**
 * Tarjeta de juego: la portada manda. Sin metadata muestra el arte de la consola con la inicial del
 * título, así que un juego sin carátula sigue viéndose bien y se abre igual.
 */
@Composable
fun GameCard(
    entry: GameEntry,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    /** Si se indica, muestra el corazón de favorito. */
    onFavoriteClick: (() -> Unit)? = null,
    /** Si se indica, muestra el botón "Jugar". */
    onPlayClick: (() -> Unit)? = null,
    showPlatform: Boolean = true
) {
    val game = entry.game
    val shape = RoundedCornerShape14
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
                .consoleSelectable(shape, onClickLabel = "Abrir detalles de ${entry.displayTitle}", onClick = onClick)
        ) {
            RemoteImage(
                url = entry.coverUrl,
                contentDescription = null,
                modifier = Modifier.matchParentSize()
            ) {
                PlatformArt(game.platform, Modifier.fillMaxSize(), watermark = false) {
                    Text(
                        text = entry.displayTitle.take(1).uppercase(),
                        style = MaterialTheme.typography.displaySmall,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.9f)
                    )
                }
            }
            if (onPlayClick != null) {
                FilledTonalIconButton(
                    onClick = onPlayClick,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(40.dp)
                ) { Icon(Icons.Rounded.PlayArrow, contentDescription = "Jugar ${entry.displayTitle}") }
            }
            if (onFavoriteClick != null) {
                IconButton(onClick = onFavoriteClick, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(
                        imageVector = if (game.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (game.isFavorite) "Quitar de favoritos" else "Marcar como favorito",
                        tint = if (game.isFavorite) MaterialTheme.colorScheme.primary
                        else androidx.compose.ui.graphics.Color.White
                    )
                }
            } else if (game.isFavorite) {
                Icon(
                    Icons.Rounded.Favorite,
                    contentDescription = "Favorito",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(18.dp)
                )
            }
        }
        Spacer(Modifier.height(JullSpacing.sm))
        Text(
            text = entry.displayTitle,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (showPlatform) MutedText(game.platform.displayName)
    }
}

private val RoundedCornerShape14 = androidx.compose.foundation.shape.RoundedCornerShape(JullRadius.card)

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(48.dp)
        )
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        MutedText(body, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp))
        if (actionLabel != null && onAction != null) {
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Tarjeta horizontal de consola con su arte y el número de juegos. */
@Composable
fun PlatformCard(
    platform: com.jullhub.app.core.model.Platform,
    count: Int,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val visual = PlatformVisuals.of(platform)
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(JullRadius.card)
    val label = "${visual.name}, ${gamesCountLabel(count)}"
    PlatformArt(
        platform = platform,
        modifier = modifier
            .aspectRatio(16f / 10f)
            .semantics { contentDescription = label }
            .consoleSelectable(shape, onClickLabel = "Abrir ${visual.name}", onClick = onClick)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(JullSpacing.md),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(visual.name, style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(gamesCountLabel(count), style = MaterialTheme.typography.labelLarge, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f))
        }
    }
}

fun gamesCountLabel(count: Int): String = if (count == 1) "1 juego" else "$count juegos"
