package com.jullhub.app.ui.home

import com.jullhub.app.core.model.GameEntry
import com.jullhub.app.core.model.Platform

enum class HeroReason(val label: String) {
    LAST_PLAYED("CONTINUAR JUGANDO"),
    FAVORITE("TU FAVORITO"),
    RECENTLY_ADDED("AÑADIDO RECIENTEMENTE")
}

data class Hero(val entry: GameEntry, val reason: HeroReason)

data class PlatformCount(val platform: Platform, val count: Int)

data class HomeUiState(
    val isLoading: Boolean = true,
    val hasGames: Boolean = false,
    val hero: Hero? = null,
    val continuePlaying: List<GameEntry> = emptyList(),
    val recent: List<GameEntry> = emptyList(),
    val favorites: List<GameEntry> = emptyList(),
    val recentlyAdded: List<GameEntry> = emptyList(),
    val platforms: List<PlatformCount> = emptyList(),
    val totalCount: Int = 0
)

/**
 * Selección de contenido de la Home. Solo usa datos locales: lastPlayed, favoritos, playCount y
 * fecha de incorporación. Sin IA ni servicios externos. Pura y testeable.
 */
object HomeContent {
    private const val CONTINUE_MAX = 8
    private const val ROW_MAX = 12

    fun build(all: List<GameEntry>): HomeUiState {
        val played = all.filter { it.game.lastPlayedAt != null }.sortedByDescending { it.game.lastPlayedAt }
        val favorites = all.filter { it.game.isFavorite }
            .sortedWith(compareByDescending<GameEntry> { it.game.playCount }.thenByDescending { it.game.addedAt })
        val added = all.sortedByDescending { it.game.addedAt }

        val hero = when {
            played.isNotEmpty() -> Hero(played.first(), HeroReason.LAST_PLAYED)
            favorites.isNotEmpty() -> Hero(favorites.first(), HeroReason.FAVORITE)
            added.isNotEmpty() -> Hero(added.first(), HeroReason.RECENTLY_ADDED)
            else -> null
        }

        // El Hero ya es el último jugado: "Continuar" muestra el resto; "Recientes" lo anterior.
        val rest = if (hero?.reason == HeroReason.LAST_PLAYED) played.drop(1) else played
        return HomeUiState(
            isLoading = false,
            hasGames = all.isNotEmpty(),
            hero = hero,
            continuePlaying = rest.take(CONTINUE_MAX),
            recent = rest.drop(CONTINUE_MAX).take(ROW_MAX),
            favorites = favorites.take(ROW_MAX),
            recentlyAdded = added.take(ROW_MAX),
            platforms = all.groupingBy { it.game.platform }.eachCount()
                .map { PlatformCount(it.key, it.value) }
                .sortedBy { it.platform.displayName },
            totalCount = all.size
        )
    }
}
