# JullHub

Launcher y gestor de juegos para Android (Kotlin, Jetpack Compose, Material 3). **No es un emulador.**
Estado: v0.5.1 (lanzamiento de juegos en emuladores; añade Game Boy/GBC/GBA y Dolphin MMJR). Sin metadata, portadas ni estadísticas.

## Abrir y compilar
1. Android Studio (Ladybug 2024.2 o superior) → *Open* → carpeta `JullHub`.
2. Esperar el *Gradle sync* (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, JDK 17).
3. Ejecutar la configuración `app`. minSdk 26, targetSdk 35.

## Arquitectura (`app/src/main/java/com/jullhub/app`)
- `core/model` — `Game`, `Platform`, `GameFolder`.
- `emulator` — `EmulatorAdapter`, `BaseEmulatorAdapter`, `EmulatorRegistry`, `GameLauncher`.
  Añadir un emulador = crear su adapter y registrarlo en `di/AppContainer.kt`.
- `data` — DataStore, `FolderRepository` (SAF + permisos persistentes), `SettingsRepository`, `GameRepository` (Room).
- `data/db` — Room: `JullDatabase`, `GameDao`, `GameEntity` (+ conversiones `Game ↔ GameEntity`).
- `data/scanner` — `GameScanner` (recorrido SAF), `PlatformDetector` (carpetas -> plataforma), `GameFileFilter` (extensiones), `ScanManager` (orquesta el escaneo).
- `di` — `AppContainer` (inyección manual).
- `ui` — tema, componentes, navegación y pantallas (Inicio, Biblioteca, Emuladores, Configuración).

## Escáner (v0.2)
Flujo implementado: Carpetas SAF → `GameScanner` → `Game` → Biblioteca.
- Ampliar formatos: `GameFileFilter.DEFAULT_EXTENSIONS`. Ampliar nombres de carpeta: `PlatformDetector.DEFAULT_ALIASES`.
- La plataforma se decide por el contexto de carpetas; si no hay confianza suficiente, `Platform.UNKNOWN`.
- Los juegos se guardan en Room (`jullhub.db`): no hace falta re-escanear al abrir la app. El escaneo solo detecta cambios (altas, bajas, cambios).
- Identidad: el `id` del juego es la URI SAF del documento, así que re-escanear nunca duplica.
- Carpetas inaccesibles o leídas en parte: sus juegos no se borran de Room.
- Favoritos: corazón en la tarjeta de la Biblioteca, persistido en Room.

## Biblioteca por consolas y emuladores (v0.4)
- La Biblioteca navega por consolas con juegos (swipe horizontal o vertical, ajustable en Configuración → Biblioteca → Navegación, guardado en DataStore). Todos/Favoritos/Recientes son accesos secundarios.
- `PlatformEmblem` (ui/components) es la representación visual de cada consola; sustituirla por assets propios solo requiere cambiar ese componente.
- `emulator/EmulatorCatalog.kt` lista los emuladores (id, nombre, paquetes, plataformas). Añadir uno = nueva entrada + sus paquetes en `<queries>` del manifest (necesario en Android 11+).
- `EmulatorRegistry.installedCompatibleWith(context, game)`: juego → plataforma → emuladores compatibles instalados. En 0.4 solo se detecta; no se lanza nada.

## Lanzamiento de juegos (v0.5)
Flujo: `Game → Platform → emuladores compatibles instalados → los que pueden lanzarlo → (elección) → LaunchRequest → Intent → emulador`.
- `emulator/LaunchRequest.kt`: tipos puros (`LaunchRequest`, `LaunchResult`, `LaunchBuild`). `EmulatorAdapter.canLaunch(game)` y `buildLaunchRequest(context, game)`.
- `emulator/LaunchSpecs.kt`: un método de lanzamiento por emulador, **cada uno con su fuente citada**. Sin método verificado = sin spec = no se intenta lanzar.
- `emulator/GameLauncher.kt`: `plan(...)` decide emulador (automático si hay uno, `RequiresSelection` si hay varios) y comprueba que la URI SAF siga disponible.
- `emulator/AndroidLaunchSupport.kt`: lo único que toca Android (detección de paquetes, comprobación SAF, `IntentLaunchExecutor`).
- UI: `ui/play/PlayViewModel` + `rememberPlayAction`; la UI nunca conoce un emulador. Tras un lanzamiento aceptado se actualizan `lastPlayedAt` y `playCount` en Room.
- Los juegos se pasan siempre como URI `content://` con concesión de lectura (flag + `ClipData`). No hay rutas absolutas ni copias de ROMs.

| Emulador | Método | Fuente |
|---|---|---|
| PPSSPP | `ACTION_VIEW` + URI en `data`, `org.ppsspp.ppsspp.PpssppActivity` | ppsspp.org (docs oficiales) |
| DuckStation | extra `bootPath`=URI, `...duckstation.EmulationActivity` | Daijishō, NeoStation, LaunchBox |
| NetherSX2/AetherSX2 | extra `bootPath`=URI, `xyz.aethersx2.android.EmulationActivity` | LaunchBox, ES-DE/EmuBridge |
| Dolphin | `ACTION_MAIN` + extra `AutoStartFile`=URI, `.ui.main.MainActivity` | Daijishō (con VIEW falla: Pegasus #1096) |
| Dolphin MMJR / Handheld | `ACTION_VIEW` + extra `AutoStartFile`=URI, misma `MainActivity` | Daijishō |
| SkyEmu (GB/GBC/GBA) | `ACTION_VIEW` + URI en `data`, `com.sky.SkyEmu.EnhancedNativeActivity` | Daijishō (única fuente) |
| melonDS | extra `uri`, `me.magnum.melonds.ui.emulator.EmulatorActivity` | README del proyecto (la ROM debe estar escaneada en melonDS) |
| Citra MMJ | `ACTION_VIEW` + extra `GamePath`=URI, `org.citra.emu.ui.EmulationActivity` | Daijishō (varía entre versiones/forks) |
| Vita3K | extra array `AppStartParameters`=[`-r`, TitleID], `org.vita3k.emulator.Emulator` | Vita3K-Android #505, ES-DE |
Sin método verificado (solo detección): DraStic, Azahar, M64Plus FZ, Flycast, Redream, RetroArch, Pizza Boy (pide ruta, no URI), My Boy!/My OldBoy! (fallos en Android 13), GBA.emu/GBC.emu/Snes9x EX+/NES.emu (solo `.zip` y fallos de lanzamiento según su mantenedor).
SNES y NES: sin emulador con lanzamiento verificado por URI.

Flujo futuro: Carpetas SAF → Escáner → Juegos → Plataforma → Emulador → EmulatorAdapter → Intent → Juego iniciado.

## Notas
- Sin `MANAGE_EXTERNAL_STORAGE`; solo `ACTION_OPEN_DOCUMENT_TREE` con permiso de lectura persistente.
- `gradlew` no se incluye; Android Studio descarga Gradle según `gradle/wrapper/gradle-wrapper.properties`.

## 0.5.2
- Corrección Dolphin: un `.rvz`/`.gcm`/`.wbfs` en una carpeta sin nombre de consola (plataforma "Desconocida") ahora se ofrece a Dolphin (GameCube y Wii). `.iso` ambiguo sigue sin adivinarse.

## 1.0 — Consola personal
- **Home**: Hero (último jugado → favorito → último añadido), Continuar, Recientes, Favoritos, Añadidos, Mis consolas y acceso a la Biblioteca. Composición propia en vertical y en horizontal (dashboard).
- **Biblioteca**: grid de carátulas, filtro por consola (solo las presentes), búsqueda, modos Todos/Consolas/Favoritos/Recientes (se conserva el pager de consolas y su ajuste).
- **Consolas**: pantalla de consolas y página por consola (arte, recientes, favoritos, biblioteca).
- **Detalle de juego**: portada, fondo atenuado, metadata, capturas, favorito, datos locales y **JUGAR** (reutiliza `PlayViewModel`; no hay lógica de emuladores en la UI).
- **Navegación**: barra inferior en vertical, riel lateral en horizontal. Ajustes → Orientación (Automática/Vertical/Horizontal) en el DataStore existente.
- **Sistema visual**: `ui/theme/JullTokens.kt` (espaciado, radios, movimiento), `WindowInfo.kt` (clases de ancho), `ui/components/` (`GameCard`, `PlatformVisual`/`PlatformArt`, `RemoteImage`, `consoleSelectable`).

### Metadata (opcional, offline first)
- Proveedor: **RAWG** (`RawgMetadataProvider`), detrás de `MetadataProvider`; sustituible.
- Autenticación: clave de API del usuario (Ajustes → Portadas e información). No hay claves en el código.
- Caché: tabla Room `game_metadata` (migración 1→2, sin migraciones destructivas). La UI solo lee la caché; la red solo se usa en segundo plano (`MetadataSyncManager`) o al reintentar en el detalle.
- Emparejado conservador: solo coincidencia exacta del título normalizado; ambigüedad o duda → "sin metadata". Un refresco sin coincidencia no sobrescribe metadata válida.
- Limitaciones: RAWG no ofrece carátulas verticales (se recorta `background_image`); capturas y la forma de `results[]` no se pudieron verificar contra la documentación oficial (ver código); sin filtro por plataforma; sin artwork propio de consolas (arte generado, listo para `imageRes`).
- Atribución: enlace "Datos e imágenes: RAWG" en Detalle y Ajustes.
