package com.jullhub.app.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jullhub.app.data.scanner.ScanState
import com.jullhub.app.ui.components.EmptyState
import com.jullhub.app.ui.components.GameCard
import com.jullhub.app.ui.components.MutedText

@Composable
fun LibraryScreen(
    factory: ViewModelProvider.Factory,
    snackbarHostState: SnackbarHostState,
    vm: LibraryViewModel = viewModel(factory = factory),
    foldersVm: FoldersViewModel = viewModel(factory = factory),
    scanVm: ScanViewModel = viewModel(factory = factory)
) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val folders by foldersVm.folders.collectAsStateWithLifecycle()
    val scanState by scanVm.state.collectAsStateWithLifecycle()
    val scanning = scanState is ScanState.Scanning
    val pickFolder = rememberFolderPicker { foldersVm.addFolder(it) }
    CollectFolderMessages(foldersVm, snackbarHostState)

    val hasGames = state.totalCount > 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Text("Biblioteca", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = query,
            onValueChange = vm::onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            enabled = hasGames,
            singleLine = true,
            placeholder = { Text("Buscar juegos") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) }
        )

        if (hasGames) {
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item(key = "all") {
                    FilterChip(
                        selected = state.platformFilter == null,
                        onClick = { vm.onPlatformSelected(null) },
                        label = { Text("Todas") }
                    )
                }
                items(state.availablePlatforms, key = { it.name }) { platform ->
                    FilterChip(
                        selected = state.platformFilter == platform,
                        onClick = { vm.onPlatformSelected(platform) },
                        label = { Text(platform.displayName) }
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        FilledTonalButton(onClick = pickFolder, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Add, contentDescription = null)
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text("Añadir carpeta de juegos")
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = scanVm::scan,
            enabled = folders.isNotEmpty() && !scanning,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (scanning) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Icon(Icons.Rounded.Refresh, contentDescription = null)
            }
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text(if (scanning) "Escaneando biblioteca..." else "Escanear biblioteca")
        }
        if (scanning) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        } else {
            scanState.statusText()?.let { MutedText(it, modifier = Modifier.padding(top = 8.dp)) }
        }
        Spacer(Modifier.height(12.dp))

        if (!hasGames) {
            EmptyState(
                icon = Icons.Rounded.VideoLibrary,
                title = "Tu biblioteca está vacía",
                body = when {
                    folders.isEmpty() ->
                        "Añade una carpeta con tus juegos para empezar. JullHub no los copia ni los mueve."
                    scanning ->
                        "Buscando juegos en tus carpetas..."
                    scanState is ScanState.Finished ->
                        "No se encontraron juegos compatibles en tus carpetas. Revisa su contenido y vuelve a escanear."
                    else ->
                        "Tienes ${folders.size} carpeta(s) guardada(s). Pulsa «Escanear biblioteca» para buscar tus juegos."
                }
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(130.dp),
                contentPadding = PaddingValues(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(state.games, key = { it.id }) { game -> GameCard(game) }
            }
        }
    }
}
