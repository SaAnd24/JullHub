package com.jullhub.app.data.scanner

import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.games.GameRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface ScanState {
    data object Idle : ScanState
    data object Scanning : ScanState
    data class Finished(val gamesFound: Int, val failedFolders: Int) : ScanState
    data object Failed : ScanState
}

/**
 * Orquesta "Carpetas -> Scanner -> Biblioteca". Vive en el [AppContainer][com.jullhub.app.di.AppContainer]
 * con su propio scope, así un escaneo en curso sobrevive al cambiar de pantalla.
 */
class ScanManager(
    private val folders: FolderRepository,
    private val scanner: GameScanner,
    private val games: GameRepository,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow<ScanState>(ScanState.Idle)
    val state: StateFlow<ScanState> = _state.asStateFlow()

    /** Inicia un escaneo; se ignora si ya hay uno en curso. Llamar desde el hilo principal. */
    fun scan() {
        if (_state.value is ScanState.Scanning) return
        _state.value = ScanState.Scanning
        scope.launch {
            _state.value = try {
                val result = scanner.scan(folders.folders.first())
                games.replaceWithScan(result.games)
                ScanState.Finished(result.games.size, result.failedFolders)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                ScanState.Failed
            }
        }
    }
}
