package com.jullhub.app.ui.library

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.GameFolder
import com.jullhub.app.core.model.Platform
import com.jullhub.app.data.folders.AddFolderResult
import com.jullhub.app.data.folders.FolderRepository
import com.jullhub.app.data.games.GameRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val games: List<Game> = emptyList(),
    val totalCount: Int = 0,
    val platformFilter: Platform? = null,
    val availablePlatforms: List<Platform> = emptyList()
)

class LibraryViewModel(games: GameRepository) : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private val platform = MutableStateFlow<Platform?>(null)

    val uiState: StateFlow<LibraryUiState> = combine(games.observeGames(), _query, platform) { all, q, p ->
        val term = q.trim()
        LibraryUiState(
            games = all
                .filter { (p == null || it.platform == p) && it.title.contains(term, ignoreCase = true) }
                .sortedBy { it.title.lowercase() },
            totalCount = all.size,
            platformFilter = p,
            availablePlatforms = all.map { it.platform }.distinct().sortedBy { it.displayName }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    fun onQueryChange(value: String) { _query.value = value }
    fun onPlatformSelected(value: Platform?) { platform.value = value }
}

/** Gestión de carpetas SAF; compartido por Biblioteca y Configuración. */
class FoldersViewModel(
    private val repository: FolderRepository,
    private val games: GameRepository
) : ViewModel() {
    val folders: StateFlow<List<GameFolder>> = repository.folders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    fun addFolder(uri: Uri) {
        viewModelScope.launch {
            val text = when (repository.addFolder(uri)) {
                AddFolderResult.Added -> "Carpeta añadida"
                AddFolderResult.AlreadyExists -> "Esa carpeta ya está configurada"
                AddFolderResult.PermissionFailed -> "No se pudo guardar el permiso de acceso a la carpeta"
            }
            _messages.emit(text)
        }
    }

    fun removeFolder(uri: String) {
        viewModelScope.launch {
            // Solo se elimina la referencia: ningún archivo del usuario se toca.
            repository.removeFolder(uri)
            games.removeByFolder(uri)
            _messages.emit("Carpeta eliminada de JullHub. Tus archivos no se han tocado")
        }
    }
}
