package com.jullhub.app.data.scanner

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import com.jullhub.app.core.model.Game
import com.jullhub.app.core.model.GameFolder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Resultado de un escaneo completo. */
data class ScanResult(
    val games: List<Game>,
    /** Carpetas que no se pudieron leer (sin permiso o error de acceso). */
    val failedFolders: Int
)

/**
 * Recorre carpetas SAF (y subcarpetas) y crea un [Game] por cada archivo de juego.
 * No toca la UI ni los emuladores, y nunca modifica ni borra archivos del usuario.
 *
 * El listado usa consultas SAF por directorio (`DocumentsContract`), mucho más rápidas
 * que `DocumentFile.listFiles()` en bibliotecas grandes. Las URIs generadas son
 * `content://` derivadas del árbol, con el permiso persistente ya concedido.
 */
class GameScanner(
    private val resolver: ContentResolver,
    private val filter: GameFileFilter = GameFileFilter(),
    private val detector: PlatformDetector = PlatformDetector(filter)
) {
    private data class Entry(val documentId: String, val name: String, val isDirectory: Boolean)

    suspend fun scan(folders: List<GameFolder>): ScanResult = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        // La URI del documento es el identificador: evita duplicados si un archivo se ve dos veces.
        val found = LinkedHashMap<String, Game>()
        var failed = 0

        for (folder in folders) {
            if (!folder.hasAccess) {
                failed++
                continue
            }
            try {
                val treeUri = Uri.parse(folder.uri)
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                val listed = walk(treeUri, rootId, listOf(folder.name), 0, found, now)
                if (!listed) failed++
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                failed++
            }
        }
        ScanResult(games = found.values.toList(), failedFolders = failed)
    }

    /** @return `false` si no se pudo listar el directorio. */
    private suspend fun walk(
        treeUri: Uri,
        directoryId: String,
        path: List<String>,
        depth: Int,
        out: MutableMap<String, Game>,
        now: Long
    ): Boolean {
        val children = listChildren(treeUri, directoryId) ?: return false
        val siblings = children.filter { !it.isDirectory }.map { it.name.lowercase() }.toSet()

        for (child in children) {
            currentCoroutineContext().ensureActive()
            if (child.isDirectory) {
                if (depth < MAX_DEPTH && !child.name.startsWith(".")) {
                    // Un subdirectorio ilegible se ignora; no invalida el resto del escaneo.
                    walk(treeUri, child.documentId, path + child.name, depth + 1, out, now)
                }
                continue
            }
            val extension = child.name.substringAfterLast('.', "").lowercase()
            if (extension.isEmpty() || !filter.isGameFile(extension)) continue
            if (filter.isCompanionFile(child.name, extension, siblings)) continue

            val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, child.documentId).toString()
            out.getOrPut(uri) {
                Game(
                    id = uri,
                    title = child.name.dropLast(extension.length + 1),
                    platform = detector.detect(path, extension),
                    uri = uri,
                    fileName = child.name,
                    extension = extension,
                    addedAt = now
                )
            }
        }
        return true
    }

    private fun listChildren(treeUri: Uri, parentId: String): List<Entry>? {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val projection = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE
        )
        val cursor = runCatching { resolver.query(childrenUri, projection, null, null, null) }
            .getOrNull() ?: return null
        return cursor.use { c ->
            val entries = ArrayList<Entry>()
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                entries += Entry(id, name, c.getString(2) == Document.MIME_TYPE_DIR)
            }
            entries
        }
    }

    private companion object {
        /** Protección frente a jerarquías enormes o enlaces cíclicos. */
        const val MAX_DEPTH = 12
    }
}
