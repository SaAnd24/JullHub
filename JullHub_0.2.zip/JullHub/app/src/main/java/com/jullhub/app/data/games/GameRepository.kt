package com.jullhub.app.data.games

import com.jullhub.app.core.model.Game
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Fuente de juegos. La implementación persistente con Room llegará en una fase posterior. */
interface GameRepository {
    fun observeGames(): Flow<List<Game>>

    /** Sustituye la biblioteca por el resultado de un escaneo, conservando los datos de usuario de juegos ya conocidos. */
    fun replaceWithScan(scanned: List<Game>)

    /** Quita de la biblioteca los juegos que pertenecen a una carpeta SAF (no toca ningún archivo). */
    fun removeByFolder(folderUri: String)
}

/** Implementación en memoria: la biblioteca se rellena con el escáner y se pierde al cerrar la app. */
class InMemoryGameRepository : GameRepository {
    private val games = MutableStateFlow<List<Game>>(emptyList())

    override fun observeGames(): Flow<List<Game>> = games.asStateFlow()

    override fun replaceWithScan(scanned: List<Game>) {
        games.update { current ->
            val known = current.associateBy { it.id }
            scanned.map { found ->
                val old = known[found.id]
                // Datos del archivo siempre frescos; favoritos, emulador, etc. se conservan.
                old?.copy(
                    title = found.title,
                    platform = found.platform,
                    uri = found.uri,
                    fileName = found.fileName,
                    extension = found.extension
                ) ?: found
            }
        }
    }

    override fun removeByFolder(folderUri: String) {
        // Los documentos de un árbol tienen la forma "<árbol>/document/<id>".
        val prefix = "$folderUri/document/"
        games.update { list -> list.filterNot { it.uri?.startsWith(prefix) == true } }
    }
}
